# 多维 Grid 等价展平

## 初始代码

```cpp
dim3 block(BX, BY);
dim3 grid(ceil_div(N, BX), ceil_div(M, BY), B);
kernel<<<grid, block, 0, stream>>>(x, y, B, M, N);
```

kernel 使用 `blockIdx.x/y/z` 映射 N/M/B。

## 一维展平候选

```cpp
long long gx = ceil_div(N, BX);
long long gy = ceil_div(M, BY);
long long gz = B;
long long logical = gx * gy * gz;
```

kernel 恢复：

```cpp
for (long long linear = blockIdx.x;
     linear < logical;
     linear += gridDim.x) {
  long long bx = linear % gx;
  long long q = linear / gx;
  long long by = q % gy;
  long long bz = q / gy;
  // 使用 bx/by/bz 恢复原 tile。
}
```

## 校验

- 乘法在 64-bit 完成。
- `grid.x` 转 unsigned 前检查平台上限；超限用 grid-stride cap。
- 恢复顺序必须与原 grid 线性化约定一致。
- 所有原 mask 和 stride 不变。
- 循环中 barrier 必须 block-uniform。
- flatten 可能增加 div/mod；若 NCU 没有收益应回退。
