# EnvConfig：Linux / RTX 3090 CUDA C/C++ 环境验证

## 职责

EnvConfig 在任何 CUDA 源码生成、编译、运行或性能测量之前执行。它负责收集本地环境事实，验证 `nvcc`、host compiler、CUDA Runtime 和目标 GPU，运行一个真实 CUDA C smoke test，并在必要时复用当前 Job 的 Worker。它不安装软件、不修改驱动，也不生成业务 kernel。

## 输入与输出

输入：

| 字段 | 必需 | 含义 |
|---|---:|---|
| `output_dir` | 是 | 主流程输出目录 |
| `workdir` | 是 | 当前仓库或任务绝对路径 |
| `worker_device_type` | 否 | Worker 设备标签；默认 `rtx3090` |

输出目录固定为 `{output_dir}/EnvConfig/`：

| 文件 | 内容 |
|---|---|
| `runtime_info.txt` | 本地或最终选中 Worker 的原始 stdout/stderr，包含命令和退出码 |
| `config.md` | 下游读取的规范化环境配置与结论 |

## 目标门禁

目标环境必须同时满足：

1. 执行后端是 Linux，共享探针返回 `operating_system=Linux`。
2. `nvidia-smi` 可见设备名称精确匹配 NVIDIA GeForce RTX 3090。
3. 设备 Compute Capability 为 `8.6`，且 CUDA Runtime 报告 82 个 SM。
4. `nvcc` 与 Linux host compiler 可用，能够编译 `-arch=sm_86` 的 CUDA C++17 源码。
5. 编译器和 CUDA Runtime 可以链接并启动真实 `__global__` kernel。
6. smoke test 的 host/device 结果一致，且所有 CUDA API 与 launch 检查通过。

仅有驱动或仅能运行 `nvidia-smi` 不算可用；仅有 Toolkit 但没有目标 GPU 也不算可用。其它 GPU 上成功只能作为 portability 信息，不能把 `execution_backend` 标为目标平台已验证。

## 本地验证步骤

### 1. 创建输出目录

确保 `{output_dir}/EnvConfig` 存在。记录当前时间、工作目录、PATH 中命中的工具，但不得修改 PATH 或系统配置。

### 2. 采集设备和工具链

按顺序运行：

```bash
python3 .claude/skills/share/cuda-c/runtime/get_device_info.py
```

保留完整 stdout、stderr 和退出码。结果至少应包含：

- GPU index、name、UUID、总显存、driver version
- Compute Capability
- `nvcc` 路径与版本
- CUDA Runtime/driver version
- host compiler 与版本
- `CUDA_VISIBLE_DEVICES`
- 是否为精确 RTX 3090 / CC 8.6 匹配

不得根据产品宣传值覆盖运行时返回的信息。若工具输出字段缺失，在 `config.md` 中写 `N/A` 并保留原因。

### 3. 编译并运行共享 smoke test

```bash
python3 .claude/skills/share/cuda-c/runtime/test_env_code.py
```

共享脚本必须实际生成或使用 CUDA C++ vector-add 源码，调用 `nvcc` 编译并启动 kernel，而不是只执行设备查询。验证以下内容：

- 环境 smoke 构建固定包含 `-std=c++17 -O2 -lineinfo -arch=sm_86`；它只验证工具链和真实 launch，不是算子性能基线
- 不默认启用 `--use_fast_math`
- `cudaMalloc`、H2D、kernel launch、同步、D2H 与释放均检查返回值
- `cudaGetLastError()` 检查 launch
- 非整 block 长度得到正确结果
- 可执行文件退出码为 0

### 4. 本地判定

只有采集脚本和 smoke test 都返回 0 时：

```text
execution_backend=local
target_validation=passed
```

任一失败时，不要尝试安装 Toolkit、切换系统编译器或改变驱动。记录失败后进入 Worker 兜底。

## Worker 兜底

仅在本地门禁失败且当前 Job 提供 Worker 调度服务时使用。必须通过统一提交脚本，不得手写 HTTP 请求：

```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
  --task-type custom \
  --workdir <workdir绝对路径> \
  --device-type rtx3090 \
  --timeout-sec 600 \
  --command "python3 .claude/skills/share/cuda-c/runtime/get_device_info.py && python3 .claude/skills/share/cuda-c/runtime/test_env_code.py"
```

约束：

- 命令前台同步运行，等待提交脚本返回。
- 一次只提交一个 Task；禁止后台或并行环境检测。
- 不在 Worker 中安装、升级、卸载依赖，不修改驱动、系统 CUDA 或全局环境。
- `--workdir` 必须是 Worker 可见的绝对路径。
- `--timeout-sec` 是 lease 后运行时限；不要用本地短超时提前杀死排队任务。

Worker 提交脚本退出码：

| 退出码 | 分类 | 处理 |
|---:|---|---|
| 0 | 环境检测成功 | `execution_backend=worker` |
| 1 | 命令或 smoke test 失败 | 保存日志并判为目标环境不可用 |
| 2 | 输入/服务/日志基础设施错误 | 保存错误，不归因于 CUDA 源码 |
| 3 | Task 取消 | 保存状态，不继续动态阶段 |

Worker 成功时，把脚本打印的原始日志和 `task_output_dir` 写入 `runtime_info.txt`。下游所有编译、准确性和性能命令必须继续通过同一 Worker 入口，不能又回到本地执行。

## `config.md` 固定格式

```markdown
# CUDA C/C++ Environment

## Decision
- execution_backend: local | worker | unavailable
- target_validation: passed | failed | unavailable
- target: NVIDIA GeForce RTX 3090
- compute_capability: 8.6 | N/A
- worker_device_type: rtx3090 | N/A

## GPU
- name: ...
- uuid: ...
- memory_total_mib: ...
- driver_version: ...
- cuda_visible_devices: ...

## Toolchain
- nvcc_path: ...
- nvcc_version: ...
- cuda_toolkit_version: ...
- cuda_runtime_version: ...
- host_compiler: ...
- host_compiler_version: ...
- default_arch: sm_86
- default_flags: -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86
- validation_flags: -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 -Xptxas=-v
- performance_flags: -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 -Xptxas=-v
- fast_math_default: false

## Smoke test
- compile_pass: true | false | unavailable
- launch_pass: true | false | unavailable
- accuracy_pass: true | false | unavailable
- tested_elements: ...
- max_abs_error: ...
- command: ...
- exit_code: ...

## Provenance
- runtime_info: EnvConfig/runtime_info.txt
- task_output_dir: ... | N/A
- limitations: ...
```

字段名保持不变，便于下游机器读取。不能收集到的字段写 `N/A（原因）`，不删除字段。

## `runtime_info.txt` 记录格式

每条命令按以下块追加，不覆盖之前的失败日志：

```text
=== command ===
<完整命令>
=== backend ===
local | worker
=== exit_code ===
<整数>
=== stdout ===
<原文>
=== stderr ===
<原文>
```

如果本地失败后 Worker 成功，文件必须同时保留本地失败和 Worker 成功两组记录，`config.md` 的最终结论使用 Worker 环境。

## 下游执行合同

`execution_backend=local` 时，下游可直接执行：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 input.cu -o input
./input
```

`execution_backend=worker` 时，下游必须执行：

```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
  --task-type compile \
  --workdir <绝对路径> \
  --timeout-sec 600 \
  --command "nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 input.cu -o input"
```

然后再用单独、串行的 `accuracy` 或 `performance` Task 运行可执行文件。除非调用方把编译和运行有意放在同一条 shell 命令中，否则不得把 compile Task 的成功解释为 runtime 成功。

`execution_backend=unavailable` 时，只允许：

- 需求分析
- 源码生成
- 静态评审
- Markdown/JSON/文件结构验证

禁止声称以下结论：

- nvcc 编译通过
- kernel launch 通过
- accuracy 通过
- Compute Sanitizer 通过
- RTX 3090 性能或带宽

## 常见失败分类

| 现象 | 分类 | 记录方式 |
|---|---|---|
| 找不到 `nvidia-smi` | 驱动/容器可见性 | 原始 stderr；尝试 Worker |
| 找不到 `nvcc` | Toolkit 不可用 | 命中的 PATH；尝试 Worker |
| GPU 名称不是 RTX 3090 | 目标设备不匹配 | 保留真实名称；尝试 Worker |
| CC 不是 8.6 | 目标架构不匹配 | 保留真实 CC；尝试 Worker |
| host compiler 不受 nvcc 支持 | 工具链失败 | 保存完整 nvcc 错误 |
| 编译成功但 launch 失败 | Runtime/driver/device 失败 | 保存 CUDA error name/string |
| 结果错误 | smoke-test 正确性失败 | 保存首个错误 index 与差异 |
| Worker 无法提交 | 基础设施错误 | `execution_backend=unavailable` |

## 完成检查表

- [ ] 已运行本地设备/工具链采集并保留退出码。
- [ ] 已运行真实 CUDA C++ smoke test并保留构建命令。
- [ ] 本地失败时已按规则尝试一次 Worker，或说明 Worker 不可用原因。
- [ ] 已写入 `runtime_info.txt`，未覆盖早期失败日志。
- [ ] 已写入字段完整的 `config.md`。
- [ ] 默认 flags 为 `-std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86`。
- [ ] `fast_math_default` 为 `false`。
- [ ] 动态能力结论与真实退出码一致。
