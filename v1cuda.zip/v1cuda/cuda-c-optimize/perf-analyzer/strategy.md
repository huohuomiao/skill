# CUDA C/C++ Kernel 性能分析

## 职责

对一个已通过 correctness 与 safety 门禁的 CUDA binary 中的指定 kernel 运行 Nsight Compute，保存原始报告、CSV、结构化摘要和可执行的优化建议。分析结果只用于选择下一项候选，不等于性能提升证据。

## 输入

| 参数 | 说明 |
| --- | --- |
| `input_file` | 完整 `.cu` 文件 |
| `output_dir` | 当前深度优化迭代目录 |
| `kernel_name` | 必须明确指定的 kernel 名或正则 |
| `program_args` | binary 的测试/benchmark 参数 |

执行前读取：

- 最近的 `EnvConfig/config.md`
- `.claude/skills/share/cuda-c/references/platform-rules.md`
- `.claude/skills/share/cuda-c/perf-analyzer/analyzer.sh`
- 当前输入的 correctness 和 benchmark 入口

## 前置门禁

1. execution backend 已确认。
2. 目标设备严格为 RTX 3090 / CC 8.6。
3. 输入代码用默认基线 flags 可编译，且 correctness 通过。
4. kernel 名明确；禁止让 NCU 捕获第一个随机 framework 或 runtime kernel。
5. 输入和 replay 可重复。含 atomic、原地更新、随机状态或跨 launch 依赖时，必须提供每次 replay 的 reset，或改用 application replay。
6. NCU 不可用时记录 `not_available`，不得从普通计时臆测硬件瓶颈。

## 编译

使用与 baseline 相同的命令，并确保含：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  -Xptxas=-v input.cu -o input
```

保存编译命令、nvcc/host compiler 版本和 ptxas 资源输出。不得为 NCU 分析偷偷改变优化级别或加入 fast math。

## 采集

在真实 RTX 3090 后端运行共享采集器，示意：

```bash
NCU_KERNEL_NAME='regex:.*target_kernel.*' \
  bash .claude/skills/share/cuda-c/perf-analyzer/analyzer.sh \
  <output_dir> <absolute_binary_path> [program arguments...]
```

共享脚本必须以 binary 为执行目标，并至少采集：

- `LaunchStats`
- `Occupancy`
- `SpeedOfLight`
- `MemoryWorkloadAnalysis`

保留：

```text
kernel.ncu-rep
kernel.ncu.csv
kernel.ncu.summary.txt
kernel.ncu.summary.json
device_info.json
perf_analysis.json
compile.stdout.txt
compile.stderr.txt
```

不要删除原始 `.ncu-rep`；摘要阈值只是 triage。

采集完成后，使用摘要中的精确 demangled kernel 名生成单一策略路由：

```bash
python3 .claude/skills/cuda-c-optimize/perf-analyzer/scripts/analyzer_rep.py \
  <output_dir>/kernel.ncu.summary.json \
  --kernel-name '<exact kernel name from summary>' \
  --json-out <output_dir>/perf_analysis.json \
  --markdown-out <output_dir>/perf_analysis.md
```

共享采集器会在 NCU 之前严格运行 Linux / RTX 3090 探针，并把 `device_info.json` 中的身份写入 NCU 摘要；身份不完整时路由脚本必须失败，没有绕过参数。`perf_analysis.json` 与 `perf_analysis.md` 必须原样携带该环境身份。

## 解析顺序

### 1. Launch 与资源

记录 grid、block、register/thread、static/dynamic shared memory、waves/SM、理论和实际 occupancy、spill。判断限制因素时同时看 registers、shared memory、warps、resident blocks，不能只看一个百分比。

### 2. 访存

检查 DRAM/SM throughput、global load/store efficiency、sector 数、L1/L2 命中、地址连续性和 replay。只有明确的 stride 或 transaction 证据才建议 coalescing/vector/shared staging。

### 3. 指令与执行

检查 eligible/issued warps、stall 原因、整数地址计算、分支分歧、barrier、atomic 和特殊函数吞吐。单个高比例 stall 不自动等于根因，需结合 source correlation、grid 大小与资源。

### 4. Tail 与并行度

结合 waves/SM、grid/block、kernel duration 判断小 grid、尾波或单 block 过重。普通 kernel 不可简单把 grid 裁到 SM 数；persistent 候选必须有 grid-stride 完整覆盖。

## 建议路由

| 证据 | 允许建议 | 禁止推断 |
| --- | --- | --- |
| 非合并访问、sector 过多 | `retiling` 或 `index-computation-simplify` | 只凭源码看到二维索引就断定 |
| register/shared 限制 residency | `config-tuner` | 无条件增大 block 或强制 maxrregcount |
| 归约同步/atomic 热点 | `reduce-opt` | 无语义证明就改 atomic 次序 |
| 小 grid、尾波、负载不均 | `modify-grid` | 普通 grid 直接裁到 SM 数 |
| 数学函数吞吐为主 | `libdevice-opt` | 默认启用 fast math |
| 整数/浮点除法热点 | `div-to-mul` | 机械替换整数除法 |

每轮最多选择一个策略。报告没有足够证据时输出“无建议”，终止深度优化，不为了继续循环制造建议。

## 输出报告

按 `references/report_template.md` 生成：

```text
{output_dir}/perf_analysis.md
```

报告必须包含环境身份、编译命令、kernel 精确匹配方式、原始产物路径、资源/吞吐/访存证据、一个或零个建议以及不确定性。

## 约束

- NCU 数据不是最终 benchmark；keep/revert 仍由相同 CUDA Event harness 决定。
- NCU replay 可改变含副作用 kernel 的行为；必须声明 replay mode 和 reset。
- 不比较不同 flags、输入、stream、功耗状态或不同 GPU 的报告。
- 未获得真实 NCU 数据时所有指标为 `N/A`。
