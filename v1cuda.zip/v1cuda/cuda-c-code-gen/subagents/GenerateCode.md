# GenerateCode

## 任务

严格根据 `step4_code_spec.json` 生成 `{output_dir}/KernelGen/step5_kernel_code.cu`。文件必须是单一、完整的 CUDA C++17 translation unit，包含 kernel、device helper、host launcher 和错误辅助；下一阶段在同一文件基础上补齐 reference/test/benchmark。

## 输入

- `step4_code_spec.json`
- `step1_base_info.json`
- `step2_block_mapping.json`
- `step3_axis_fusion.json`
- `requirement.md`

若 spec 的 `ready_for_code` 不为 true 或 `unresolved` 非空，停止，不生成猜测代码。

## 输出合同

`step5_kernel_code.cu` 必须：

- 使用 UTF-8 文本。
- 可由 C++17 CUDA 编译器解析。
- 不含 Markdown fence、TODO、伪代码、省略号或占位表达式。
- 不引用项目私有 header，除非 requirement 明确提供并在 spec 中列出。
- 不包含 Python、JIT、动态代码生成或其它语言 wrapper。
- 默认不依赖 `--use_fast_math`。
- 保持 wrapper ABI 与 spec 完全一致。

## 文件布局

按以下顺序组织，方便 code-review 与后续优化：

```cpp
// 1. Standard/CUDA includes
// 2. Error helpers and small host helpers
// 3. Device helpers
// 4. __global__ kernels
// 5. Public host launchers/wrappers
// 6. Marker comment where GenTestCode appends reference/test/main
```

建议末尾标记：

```cpp
// === CUDA_C_TEST_HARNESS_BEGIN ===
```

GenTestCode 应替换或在标记后追加测试，不复制第二份 kernel。

## Headers

只包含实际使用的 header。常用组合：

```cpp
#include <cuda_runtime.h>

#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <limits>
```

使用 half/bfloat16 时分别加入：

```cpp
#include <cuda_fp16.h>
#include <cuda_bf16.h>
```

不要用 `using namespace std;`。device/host 兼容函数要确认限定符，不要在 device code 中调用 host-only 标准库函数。

## CUDA 错误辅助

业务 wrapper 应返回 `cudaError_t`，不在库函数中 `std::exit`。测试 harness 可用 fail-fast 宏。kernel 文件阶段可提供 host helper：

```cpp
inline const char* cuda_error_name(cudaError_t status) {
    return cudaGetErrorName(status);
}

inline bool report_cuda_error(cudaError_t status, const char* expression,
                              const char* file, int line) {
    if (status == cudaSuccess) {
        return true;
    }
    std::fprintf(stderr, "CUDA error at %s:%d: %s -> %s (%s)\n",
                 file, line, expression, cudaGetErrorName(status),
                 cudaGetErrorString(status));
    return false;
}
```

GenTestCode 可以定义：

```cpp
#define CUDA_CHECK(expr) \
    do { \
        const cudaError_t status_ = (expr); \
        if (!report_cuda_error(status_, #expr, __FILE__, __LINE__)) return false; \
    } while (0)
```

宏的 return 类型必须适配使用位置；不要在 `main`、bool helper 和 `cudaError_t` wrapper 中复用一个返回类型错误的宏。

## Kernel 生成

### 签名

保持 spec 参数顺序。仅在 aliasing 合同支持时添加 `__restrict__`：

```cpp
__global__ void affine_relu_kernel(
    const float* __restrict__ x,
    float* __restrict__ y,
    std::int64_t n,
    float a,
    float b) {
    // ...
}
```

不要把 runtime shape 声明为 template 常量，除非 spec 明确要求多版本 dispatch 并提供所有实例。

### 索引

避免先用 32-bit 乘法再 cast：

```cpp
// 正确：先扩宽操作数
const std::int64_t i =
    static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;

// 错误：32-bit 乘法可能先溢出
const std::int64_t i = blockIdx.x * blockDim.x + threadIdx.x;
```

二维 offset 同理：

```cpp
const std::int64_t offset = row * stride0 + col * stride1;
```

确保 row/stride 已是 64-bit。

### Bounds

所有可能超域的线程必须在任何 global/shared access 前保护：

```cpp
if (i < n) {
    const float value = x[i];
    y[i] = value;
}
```

包含 block barrier 时，不能在 barrier 前对部分线程 return。应 predicated load → barrier → predicated store。

### Shared memory

按 spec 精确声明。静态二维 tile：

```cpp
__shared__ float tile[kTile][kTile + 1];
```

动态 buffer：

```cpp
extern __shared__ unsigned char shared_raw[];
float* values = reinterpret_cast<float*>(shared_raw + values_offset);
```

offset 必须按 `alignof(T)` 对齐并与 host bytes 公式一致。不要通过错误 cast 造成 misalignment。

### Warp intrinsics

使用 `_sync` 版本并遵守 spec mask：

```cpp
const unsigned mask = __ballot_sync(0xffffffffu, valid);
if (valid) {
    value += __shfl_down_sync(mask, value, offset);
}
```

注意：某 lane 从 mask 中排除后，不能要求其它 lane 从该源 lane shuffle 得到定义值。对 partial warp reduction，常用做法是让所有存在的 lanes 定义 accumulator（无效元素取 identity），并确保调用点的 active lanes 与 mask 一致。

### Atomics

仅使用 spec 指定的原子 API/type；不通过非原子 load/store 模拟。若初始化由 host `cudaMemsetAsync` 完成，wrapper 或测试顺序要和 stream 一致。

## Host launcher

wrapper 骨架：

```cpp
cudaError_t launch_affine_relu(
    const float* x,
    float* y,
    std::int64_t n,
    float a,
    float b,
    cudaStream_t stream) {
    if (n < 0) {
        return cudaErrorInvalidValue;
    }
    if (n == 0) {
        return cudaSuccess;
    }
    if (x == nullptr || y == nullptr) {
        return cudaErrorInvalidDevicePointer;
    }

    constexpr unsigned kThreads = 256;
    const std::uint64_t blocks64 =
        (static_cast<std::uint64_t>(n) + kThreads - 1) / kThreads;
    if (blocks64 > std::numeric_limits<unsigned>::max()) {
        return cudaErrorInvalidConfiguration;
    }

    affine_relu_kernel<<<static_cast<unsigned>(blocks64), kThreads, 0, stream>>>(
        x, y, n, a, b);
    return cudaGetLastError();
}
```

若平台真实 grid.x 限制小于 `UINT_MAX`，应使用 spec 的 grid-stride cap 或运行时属性检查。不能只检查 C++ 类型上限。

### 异步语义

- wrapper 默认不调用 `cudaDeviceSynchronize()`。
- 使用 `cudaMemcpyAsync`、event 或多 kernel 时全部在传入 stream 上按序。
- 临时 device allocation 如不可避免，优先要求调用者提供 workspace；不要在每次 launch 内隐藏昂贵同步。
- wrapper 返回 launch/API 状态。异步执行错误由调用者同步时获得；测试 harness 必须检查。

## 数值语义

按 spec 选择运算。不要为“看起来更快”自行替换：

- `/` → reciprocal multiply
- `expf` → `__expf`
- 分步 `a*x+b` → `fmaf`
- float reduction → half reduction
- double → float

这些可能改变舍入、特殊值或范围。任何 fast 候选属于 optimize，除非 requirement 明确许可且 spec 已固定。

## 多 kernel wrapper

若算子需要多个 kernel：

1. 所有 launch 使用同一传入 stream。
2. kernel 之间依赖由 stream 顺序保证，通常无需 host synchronize。
3. 中间 buffer 的所有权、大小和生命周期明确。
4. 每次 launch 后执行 `cudaGetLastError()`；遇错立即返回。
5. benchmark 覆盖整个 wrapper device work。

初始实现优先简单可靠；若单 kernel 需要非法 grid-wide barrier，应合法拆分。

## 示例：逐元素 kernel + wrapper

```cpp
#include <cuda_runtime.h>

#include <cstdint>
#include <limits>

__global__ void square_kernel(const float* x, float* y, std::int64_t n) {
    const std::int64_t i =
        static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i < n) {
        y[i] = x[i] * x[i];
    }
}

cudaError_t launch_square(const float* x, float* y, std::int64_t n,
                          cudaStream_t stream) {
    if (n < 0) return cudaErrorInvalidValue;
    if (n == 0) return cudaSuccess;
    if (x == nullptr || y == nullptr) return cudaErrorInvalidDevicePointer;
    constexpr unsigned threads = 256;
    const std::uint64_t blocks =
        (static_cast<std::uint64_t>(n) + threads - 1) / threads;
    if (blocks > std::numeric_limits<unsigned>::max()) {
        return cudaErrorInvalidConfiguration;
    }
    square_kernel<<<static_cast<unsigned>(blocks), threads, 0, stream>>>(x, y, n);
    return cudaGetLastError();
}

// === CUDA_C_TEST_HARNESS_BEGIN ===
```

这是结构示例；真实代码必须遵循 spec 的名字、类型、grid 限制和 aliasing。

## 参考示例路由

仅按当前 pattern 读取：

- `examples/generate_code_axis_fusion.md`
- `examples/generate_code_matrix_transpose.md`
- `examples/generate_code_reduce_sum.md`
- `examples/generate_code_transpose_elementwise.md`

示例必须整体理解，不能只复制 kernel 而遗漏 wrapper 错误处理或边界路径。

## 静态自检

生成后阅读完整 `.cu` 并检查：

### 结构

- [ ] include 完整且无项目私有缺失依赖。
- [ ] 所有声明/定义/调用签名一致。
- [ ] 每个 kernel 有 host launch 路径。
- [ ] 文件末尾有测试 harness 标记。

### CUDA

- [ ] 全局索引在乘法前扩为 64-bit。
- [ ] 所有 memory access 在范围内。
- [ ] block/grid/shared bytes 与 spec 一致。
- [ ] 所有 barrier 可由相同参与集合到达。
- [ ] warp masks 合法。
- [ ] wrapper 检查参数、空输入和 launch error。
- [ ] wrapper 不隐藏无要求的全设备同步。

### 数值

- [ ] dtype/accumulation/output 转换一致。
- [ ] 没有默认 fast intrinsic/fast-math。
- [ ] NaN/Inf/identity 与 contract 一致。
- [ ] atomic/并行 reduction 的确定性与 spec 一致。

### 文本

禁止出现：

```text
TODO
TBD
...
pseudocode
implement here
```

注释里的数学省略号也应改为明确说明，避免残留扫描误判。

## 失败处理

- spec 参数不一致：返回 GenerateSpec，不自行选一套。
- 无法用合法 CUDA C++ 表达：报告具体 API/同步/资源问题，返回设计阶段。
- 需要未提供外部依赖：返回 Extractor/用户，不伪造 header。
- 向量对齐无依据：生成 scalar baseline。
- shared memory 超限：返回 AxisFusion 重选 tile，不截断数组。
- barrier 分歧：重构控制流，不删除必要同步。

本阶段不运行 nvcc；真实构建和修复由 GenTestCode 后的 `cuda-c-code-review` 完成。
