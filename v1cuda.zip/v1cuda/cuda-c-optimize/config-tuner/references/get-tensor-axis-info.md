# CUDA Kernel Tensor 轴信息提取

本参考用于 `config-tuner` 和 `gen-autotune-config`。目标是从 `.cu` 源码、launch 和实际测试规格中恢复“数据轴—线程轴—地址—配置参数”关系，而不是按变量名猜 block/tile。

## 返回格式

```json
{
  "kernel_name": "target_kernel",
  "test_cases": [
    {
      "shape": {"B": 32, "M": 1024, "N": 2048},
      "dtype": "float",
      "strides": {"x": ["M*N", "N", "1"]},
      "alignment_bytes": {"x": 256},
      "weight": 1.0
    }
  ],
  "launch": {
    "grid": ["ceil_div(N, BX)", "ceil_div(M, BY)", "B"],
    "block": ["BX", "BY", "1"],
    "dynamic_shared_bytes": "shared_expr",
    "stream": "stream"
  },
  "tunable": {
    "BX": {"kind": "block_x", "current": 32},
    "BY": {"kind": "block_y", "current": 8},
    "ITEMS": {"kind": "items_per_thread", "current": 1},
    "VEC": {"kind": "vector_width", "current": 1},
    "UNROLL": {"kind": "unroll", "current": 1}
  },
  "axes": [
    {
      "name": "N",
      "extent": "N",
      "stride": 1,
      "mapping": "blockIdx.x*BX+threadIdx.x",
      "role": "parallel_contiguous"
    },
    {
      "name": "M",
      "extent": "M",
      "stride": "N",
      "mapping": "blockIdx.y*BY+threadIdx.y",
      "role": "parallel"
    }
  ],
  "memory": {
    "transactions": [],
    "reuse": [],
    "vectorization": {
      "eligible": false,
      "proof": []
    }
  },
  "reduction": null,
  "resources": {
    "registers_per_thread": null,
    "static_shared_bytes": null,
    "dynamic_shared_bytes": null,
    "spill_bytes": null,
    "source": "static_only"
  }
}
```

无法证明的字段为 null。

## Step 1：展开 Launch

追踪 host 变量直到 `dim3`：

```cpp
constexpr int BX = 32;
constexpr int BY = 8;
dim3 block(BX, BY);
dim3 grid((N + BX - 1) / BX, (M + BY - 1) / BY, B);
kernel<<<grid, block, shared_bytes, stream>>>(x, y, B, M, N);
```

记录：

- grid/block 三维表达式。
- dynamic shared 表达式。
- stream。
- 模板参数、宏和 runtime 参数。
- 每 block 总线程数。
- 不同 shape 是否走不同 launch 分支。

如果 kernel 通过 `cudaLaunchKernel` 调用，按 `dim3 gridDim`、`dim3 blockDim` 和参数数组恢复同样信息。

## Step 2：展开数据索引

示例：

```cpp
int n = blockIdx.x * blockDim.x + threadIdx.x;
int m = blockIdx.y * blockDim.y + threadIdx.y;
long long offset = ((long long)b * M + m) * N + n;
```

展开为：

```text
offset = b*(M*N) + m*N + n
```

轴表：

| 轴 | extent | stride | 并行来源 | role |
| --- | --- | --- | --- | --- |
| B | B | M*N | blockIdx.z | grid parallel |
| M | M | N | blockIdx.y/threadIdx.y | parallel |
| N | N | 1 | blockIdx.x/threadIdx.x | parallel contiguous |

连续性由实际 stride 确定，不由 N 是最后一个逻辑轴自动确定。

## Step 3：识别每线程工作量

模式：

```cpp
for (int item = 0; item < ITEMS; ++item) {
  long long n = base + (long long)item * blockDim.x;
  if (n < N) { ... }
}
```

记录：

- ITEMS 是否模板常量。
- 相邻线程在同一 item 的地址差。
- 每线程 load/store 数。
- loop 是否 unroll。
- register live values 随 ITEMS 的可能增长。

不要把循环次数直接当作 vector width；标量多元素和单条 vector memory operation 是不同候选。

## Step 4：Vector 对齐证据

vectorization 只有在证据链完整时为 eligible：

1. allocation 对齐。
2. pointer slice offset 对齐。
3. axis stride 为 1。
4. vector 不跨逻辑行/对象边界。
5. 尾部 fallback。
6. alias/restrict 语义合法。
7. vector type 的大小与元素 dtype 匹配。

记录证据来源，例如 runtime alignment assert、API contract、base allocation 或静态 offset。没有证据时 false。

## Step 5：Shared memory

提取：

- `__shared__ T tile[...]`
- `extern __shared__ T smem[]`
- 数组维度、padding 和索引。
- producer/consumer thread 映射。
- barrier 次数和控制流。
- host dynamic shared bytes。

计算静态表达式只作为初筛。实际字节和 register/spill 从相同 flags 的 ptxas/NCU 读取。

## Step 6：归约

示例：

```cpp
float acc = 0.0f;
for (int k = threadIdx.x; k < K; k += blockDim.x)
  acc += x[row * K + k];
```

记录：

- K 是 reduce axis。
- block.x 影响并行 partial 数。
- 每线程迭代数约为 ceil(K/block.x)。
- 后续是 warp shuffle、shared tree、atomic 或第二 kernel。
- block 改变时 shared size、active mask、atomic count 是否变化。
- 浮点次序和确定性风险。

## Step 7：实际测试分布

从 harness 获取所有测试 case，而不是选择第一个：

```text
shape, dtype, stride, alignment, seed, stream, weight
```

若用户提供多 shape，配置搜索目标必须预先定义：

- 单 shape 最优。
- 加权几何/算术目标。
- worst-case guardrail。
- shape dispatch。

不得测完后临时更换评分口径。

## Step 8：候选边界

候选必须从共享平台规则和当前资源产生。常见维度：

- block.x/y/z
- tile M/N/K
- items/thread
- vector width
- unroll
- shared staging / padding
- dynamic shared bytes
- grid-stride cap

生成前过滤：

- threads/block 超限。
- grid 维超限。
- shared bytes 明显超限。
- vector alignment 未证明。
- tile 无法覆盖或 mask 缺失。
- reduction active mask 不合法。
- 估计 register 风险过高；最终仍看 ptxas。
- 使用目标架构不支持的能力。

## 示例 1：一维 Elementwise

```cpp
template<int BLOCK, int ITEMS>
__global__ void scale(const float* x, float* y, long long n, float alpha) {
  long long base =
      ((long long)blockIdx.x * ITEMS) * BLOCK + threadIdx.x;
#pragma unroll
  for (int j = 0; j < ITEMS; ++j) {
    long long i = base + (long long)j * BLOCK;
    if (i < n) y[i] = x[i] * alpha;
  }
}
```

可调：BLOCK、ITEMS；VEC 只有对齐得到证明时。grid 随 `BLOCK*ITEMS` 改变。小 n 需防止并行度不足。

## 示例 2：二维 Elementwise

```cpp
template<int BX, int BY>
__global__ void add2d(const float* a, const float* b, float* c, int M, int N) {
  int n = blockIdx.x * BX + threadIdx.x;
  int m = blockIdx.y * BY + threadIdx.y;
  if (m < M && n < N) {
    long long i = (long long)m * N + n;
    c[i] = a[i] + b[i];
  }
}
```

让 x 对应 N 的 stride-1。候选必须满足 BX*BY 合法。BX/BY 改变 block shape、grid、warp 排列和尾部利用率。

## 示例 3：行归约

```cpp
template<int BLOCK>
__global__ void row_sum(const float* x, float* y, int rows, int cols) {
  int row = blockIdx.x;
  float acc = 0.0f;
  for (int col = threadIdx.x; col < cols; col += BLOCK)
    acc += x[(long long)row * cols + col];
  float value = block_reduce_sum<BLOCK>(acc);
  if (threadIdx.x == 0) y[row] = value;
}
```

BLOCK 同时影响循环次数、shuffle/shared 结构和浮点次序。候选要覆盖 BLOCK<32/非 32 倍数的 active mask，或直接过滤这些配置。

## 示例 4：Shared Tile

```cpp
template<int TM, int TN>
__global__ void tile_kernel(...) {
  __shared__ float tile[TM][TN + 1];
  // cooperative load
  __syncthreads();
  // reuse
}
```

TM/TN 影响 threads、shared bytes、registers、reuse 和边界。不能只按 tile 面积选择。

## 输出校验

- 所有目标 kernel 唯一。
- 三维 launch 结构完整。
- 数据轴、stride、thread 映射一致。
- tunable 参数与源码真实符号对应。
- 多组测试没有遗漏。
- 对齐、归约和 shared 风险明确。
- ptxas/NCU 数值注明来源。
- JSON 可解析。

## 深入分析：地址与 Warp 交易

### Warp 内地址增量

对 warp 中 lane `l`，写出地址：

```text
A(l) = base + f(blockIdx, warp, lane=l, loop)
Δ(l) = A(l+1) - A(l)
```

若 `Δ(l)==sizeof(T)` 且地址合法、对齐，则是连续候选。若 `Δ` 是 stride、广播为 0 或随 lane 非线性，记录真实模式。不能仅看源码中出现 `threadIdx.x` 就判定合并。

### 多个访问的冲突

一个线程映射可能让输出 store 连续，却让第二输入 gather。配置选择需列出每个主访问：

| pointer | operation | lane delta bytes | reuse | alignment | expected pattern |
| --- | --- | ---: | --- | --- | --- |
| x | load | 4 | none | proven/unknown | contiguous |
| bias | load | 0/4/stride | broadcast/cache | unknown | broadcast/strided |
| y | store | 4 | none | proven/unknown | contiguous |

优先级由实际 bytes 和 NCU transaction 证据决定，不为一个低流量输入牺牲主输出。

### Vector 地址证明示例

```cpp
const float* row_ptr = x + (long long)row * stride;
```

即使 `x` 基址 256-byte 对齐，`row_ptr` 只有在 `stride*sizeof(float)` 是 vector alignment 的倍数时才保持对齐。对 `float4`，需证明：

```text
x alignment >= 16
(row * stride * 4) mod 16 == 0 for every row
column offset mod 4 == 0
```

无法证明时生成 runtime aligned fast path + scalar fallback，或不搜索 VEC>1。

## 深入分析：Thread 线性化

CUDA 的线性 thread id：

```cpp
int linear_tid = threadIdx.x +
                 blockDim.x * (threadIdx.y + blockDim.y * threadIdx.z);
```

warp 由连续 `linear_tid` 组成。因此二维 block 中：

- 若 blockDim.x>=32，warp 通常先沿 x。
- 若 blockDim.x<32，warp 跨多个 y 行。
- `threadIdx.y` 相同不一定代表一个 warp group。

调整 `(BX,BY)` 时要重新计算 warp 跨越关系，特别是 per-row shuffle reduction。若一行线程数小于 32，多个 row 可能共享一个 warp，shuffle mask 和 lane group 需显式分区，不能使用整个 warp 的简单 reduce。

## 深入分析：Grid 覆盖

配置改变 work-per-block 后验证：

```text
logical work = product(output extents)
work/block   = threads/block * items/thread * vector width
grid         = ceil_div(logical work, work/block)
```

二维/三维情况逐轴计算。以下情况需单独证明：

- 多输出/多 tensor 的 extent 不相同。
- 广播轴不产生重复写。
- in-place 算子读写顺序。
- grid-stride loop 的 stride 使用实际 gridDim/blockDim。
- persistent cap 后仍覆盖所有 logical tiles。
- `dim3` 转换前没有 64→32 bit 截断。

## 深入分析：Shared Memory

### 静态 shared

```cpp
template<int TM, int TN>
__global__ void k(...) {
  __shared__ float tile[TM][TN + 1];
}
```

静态表达式约为 `TM*(TN+1)*sizeof(float)`，但实际资源以 ptxas 为准，编译器可能有多个 shared 对象和 alignment padding。

### 动态 shared

```cpp
extern __shared__ unsigned char storage[];
float* values = reinterpret_cast<float*>(storage);
```

追踪 host 的第三 launch 参数，并检查子区域对齐：

```text
values bytes + partial bytes + padding
```

若不同类型共享同一 storage，应使用显式 alignment offset，不能简单首尾相接。

### Bank 模式

shared bank conflict 候选由 lane 的 shared word index推导。典型 tile padding `+1` 不是普适规则；数据类型、访问方向、vector width 和 bank width均会影响。最终以 NCU shared transaction/conflict 指标为证据。

## 深入分析：Register 与 Live Range

源码只能识别风险：

- 大 per-thread accumulator array。
- 多个同时存活 tile。
- 高 unroll。
- 多路径值合流。
- vector 分量长期存活。
- Welford/argmax pair state。

真实 `registers/thread` 和 spill 从 ptxas/NCU读取。配置记录中保存：

```json
{
  "config": "...",
  "registers_per_thread": 64,
  "spill_store_bytes": 0,
  "spill_load_bytes": 0,
  "source": "ptxas"
}
```

示例数值不可复制为目标结论。register 少不自动更快；必须与 ILP、occupancy 和耗时一起判断。

## 深入分析：Reduction Group

二维 block 可能并行多个独立 reduction group：

```cpp
int group = threadIdx.y;
int lane_in_group = threadIdx.x;
```

若 `blockDim.x==32`，每 group 恰为一个 warp；若不是，则可能出现：

- group 跨 warp。
- 一个 warp 含多个 group。
- partial warp。

结构化输出增加：

```json
{
  "reduction_group": {
    "threads_per_group": "BX",
    "groups_per_block": "BY",
    "warp_aligned": true,
    "shuffle_mask_rule": "one full warp per group",
    "shared_partition": "partial[group][warp]"
  }
}
```

候选若改变 BX/BY，必须重新计算此字段。

## 深入分析：Atomic 与 Reset

发现 atomic 时记录：

- function/operator/dtype。
- target pointer/index。
- 每 output 的预计 atomic 数。
- 初始化位置与 stream。
- benchmark repeat 是否 reset。
- 返回旧值是否使用。
- determinism 要求。

配置增大 grid 可能增加 atomic contention；不能只看更多 block 带来的并行度。

## 深入分析：多 Kernel Pipeline

如果 wrapper 含多个 kernel：

```text
preprocess → partial → final → postprocess
```

分别生成 kernel_info，并添加依赖图：

```json
{
  "pipeline": [
    {"kernel": "partial", "reads": ["x"], "writes": ["workspace"]},
    {"kernel": "final", "reads": ["workspace"], "writes": ["out"]}
  ]
}
```

配置改变 partial grid 时，workspace size 和 final 输入同步变化。性能口径必须包含必要 pipeline，不能只调最短 kernel 后声称端到端提升。

## 深入分析：Host Wrapper

host wrapper 是配置契约的一部分，需检查：

- device/stream 参数是否来自调用方。
- `cudaSetDevice` 是否必要且正确。
- `cudaGetLastError` 和同步边界。
- workspace allocation 是否进入计时。
- shape dispatch。
- alignment fast path/fallback。
- occupancy API 是否与当前 template instance 一致。
- dynamic shared opt-in 返回值。

配置冻结后 wrapper 必须仍能处理全部合法输入。

## 深入分析：测试与评分

每个测试 case 记录权重和 guardrail：

```json
{
  "name": "large_contiguous",
  "shape": {"M": 4096, "N": 4096},
  "dtype": "float",
  "stride": [4096, 1],
  "weight": 0.5,
  "must_not_regress": true
}
```

权重必须来自用户或在搜索前声明。没有用户权重时，稳健策略是所有关键 case no-regression，再以等权聚合选择。不能只选获胜配置最有利的 shape。

## 常见提取错误

1. 把逻辑 `N` 轴默认当成 stride-1，而未读取实际 stride。
2. 忽略 blockDim.y/z，错误计算 threads/block 和 warp。
3. 把 grid 数量当成 SM 数。
4. 把循环次数当成 vector width。
5. 未追踪 host dynamic shared bytes。
6. 看到 `float4` 就认为地址对齐。
7. 只分析第一个测试 shape。
8. 把 ptxas 多 kernel 的资源归给目标 kernel。
9. 改 BLOCK 后不更新 shared 数组或 shuffle mask。
10. 对 atomic kernel benchmark 忘记 reset。

任何上述不确定性应在 JSON 中明确呈现，阻止危险候选进入搜索。
