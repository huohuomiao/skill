# 多维轴 Flatten 分析例子

## 示例代码

```cpp
#include <cuda_runtime.h>
#include <cstdint>

__global__ void add_bias_3d(
    const float* __restrict__ x,
    const float* __restrict__ bias,
    float* __restrict__ y,
    int B, int M, int N) {
  long long linear =
      (long long)blockIdx.x * blockDim.x + threadIdx.x;
  long long total = (long long)B * M * N;
  if (linear >= total) return;

  int n = (int)(linear % N);
  int m = (int)((linear / N) % M);
  int b = (int)(linear / ((long long)M * N));
  y[linear] = x[linear] + bias[n];
}

void launch_add_bias(
    const float* x, const float* bias, float* y,
    int B, int M, int N, cudaStream_t stream) {
  constexpr int BLOCK = 256;
  long long total = (long long)B * M * N;
  dim3 block(BLOCK);
  dim3 grid((unsigned)((total + BLOCK - 1) / BLOCK));
  add_bias_3d<<<grid, block, 0, stream>>>(x, bias, y, B, M, N);
}
```

## Step 1：目标 kernel 与接口

- kernel：`add_bias_3d`
- pointers：`x`、`bias`、`y`
- extents：B、M、N
- launch：普通一维 grid，block=256
- dynamic shared memory：0
- stream：调用方传入

`total` 使用 64-bit，避免 `B*M*N` 在计算 grid 或地址前发生 32-bit 溢出。

## Step 2：轴映射

```text
linear = blockIdx.x * blockDim.x + threadIdx.x
n      = linear % N
m      = (linear / N) % M
b      = linear / (M*N)
```

| 轴 | extent | 来源 | 类型 |
| --- | --- | --- | --- |
| flattened BMN | B*M*N | blockIdx.x + threadIdx.x | grid/thread parallel |
| N | N | linear % N | recovered |
| M | M | (linear/N) % M | recovered |
| B | B | linear/(M*N) | recovered |

每个线程处理一个输出元素，无循环，无归约。

## Step 3：地址

```text
x index    = linear
bias index = n
y index    = linear
```

假设 `x` 和 `y` 是 row-major contiguous，则同一 warp 的 linear 连续，global load/store 合并。bias 访问在每个 N 周期重复，是否命中 cache 需要实测。

## Step 4：候选与风险

可尝试的候选：

1. 在指针对齐、`total` 尾部和 N 边界均得到证明时，用向量类型一次处理 2/4 个连续元素。
2. 若整数 div/mod 在 N 非常数时成为 NCU 热点，评估 reciprocal/magic-number 变换或改变 launch 的二维映射。
3. 若 N 较小，二维 grid 让 `blockIdx.y` 表示外部行，线程只处理 N，可能减少 div/mod。

必须保持：

- linear 访问的 row-major 语义。
- bias 仅按 N 轴广播。
- 非整 block 尾部边界。
- 64-bit total 和外层地址安全。

不能仅因二维写法“更直观”就保留；需要相同 RTX 3090 benchmark 证明无回退。

## 结构化输出

```json
{
  "kernel_name": "add_bias_3d",
  "launch": {
    "grid_expr": ["ceil_div(B*M*N, 256)", "1", "1"],
    "block_expr": ["256", "1", "1"],
    "dynamic_shared_bytes": "0"
  },
  "axes": [
    {"name": "linear", "extent": "B*M*N", "source": "blockIdx.x*blockDim.x+threadIdx.x"},
    {"name": "n", "extent": "N", "source": "linear%N"},
    {"name": "m", "extent": "M", "source": "(linear/N)%M"},
    {"name": "b", "extent": "B", "source": "linear/(M*N)"}
  ],
  "memory": {
    "x": "linear",
    "bias": "n",
    "y": "linear",
    "coalesced_dimension": "linear",
    "alignment_proven": false
  },
  "control": {
    "loops": [],
    "barriers": [],
    "atomics": []
  },
  "reduction": {"present": false}
}
```
