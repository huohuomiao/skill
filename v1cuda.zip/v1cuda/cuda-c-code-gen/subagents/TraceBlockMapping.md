# TraceBlockMapping

## 任务

为逻辑输出域设计 CUDA block/thread 映射，并写入 `step2_block_mapping.json`。必须以 `blockIdx`、`threadIdx`、`blockDim`、`gridDim` 表达覆盖关系，证明输出无遗漏、无意外重叠，并处理非整 block、空输入和大索引。

## 输入

- `step1_base_info.json`
- `requirement.md`
- `.claude/skills/share/cuda-c/references/platform-rules.md`

如果 `ready_for_mapping=false`，停止并返回 blocking questions，不得设计映射。

## 设计原则

1. correctness 优先于 occupancy 或简短代码。
2. 连续逻辑元素优先映射到同一 warp 的相邻 lane，以形成合并访问。
3. mapping 的 launch 公式由 host 计算，kernel 内使用 CUDA builtins 还原逻辑坐标。
4. 每个 load/store 均能追溯到逻辑坐标和 bounds predicate。
5. 默认使用普通 coverage grid；只有明确目的和后续性能验证时才选择 grid-stride/persistent 形式。
6. 不在本阶段声称某个 block size 最优。可以提出小型候选集合，初始 baseline 选保守合法值。

## 1D 映射

标准逐元素覆盖：

```cpp
const std::int64_t i =
    static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
if (i < n) {
    y[i] = f(x[i]);
}
```

host launch：

```cpp
const int threads = 256;
const std::uint64_t blocks64 =
    (static_cast<std::uint64_t>(n) + threads - 1) / threads;
dim3 block(threads);
dim3 grid(static_cast<unsigned int>(blocks64));
```

在 cast 到 `unsigned int` 前必须检查 grid 上限；具体平台限制从共享规则读取。`n==0` 时 wrapper 直接成功返回，不发出 `grid.x==0` 的非法 launch。

大域或有复用目的时可选择 grid-stride：

```cpp
std::int64_t i = static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
const std::int64_t step = static_cast<std::int64_t>(blockDim.x) * gridDim.x;
for (; i < n; i += step) {
    y[i] = f(x[i]);
}
```

必须说明 grid cap 的依据以及循环是否改变 cache/latency 行为。不要因为 RTX 3090 有固定 SM 数就直接把 grid 固定为 SM 数；这属于后续性能候选。

## 2D 映射

对连续 row-major `[M,N]`，通常让 `threadIdx.x` 沿 N：

```cpp
const std::int64_t col =
    static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
const std::int64_t row =
    static_cast<std::int64_t>(blockIdx.y) * blockDim.y + threadIdx.y;
if (row < m && col < n) {
    const std::int64_t offset = row * n + col;
    y[offset] = f(x[offset]);
}
```

host：

```cpp
dim3 block(32, 8);
dim3 grid(ceil_div_u64(n, block.x), ceil_div_u64(m, block.y));
```

`block.x * block.y` 必须满足设备 thread/block 限制。若 stride 表明另一轴连续，映射应跟随真实 stride，而非机械采用 row-major。

## 3D 与扁平化

优先考虑将多个外层维度扁平化为 1D/2D grid，减少 grid 维度限制和反解复杂度：

```cpp
const std::uint64_t outer =
    static_cast<std::uint64_t>(blockIdx.y) * blockDim.y + threadIdx.y;
const std::uint64_t b = outer / m;
const std::uint64_t row = outer - b * m;
```

需要证明 `B*M` 不溢出所用类型，并在 host 计算前检查。只有当 z 维语义清晰且 grid.z 合法时使用 `blockIdx.z`。

## Reduction 映射

对每个输出 row 一个 block 的 baseline：

```text
blockIdx.x -> output row
threadIdx.x -> reduction elements k = lane + q * blockDim.x
每线程 local accumulator
block 内 reduction
thread 0 写唯一输出
```

必须明确：

- block 数与输出元素数关系。
- reduction extent 是否可能为 0。
- local accumulation dtype。
- warp shuffle 的 active mask 和 width。
- 跨 warp 临时值的 shared-memory 布局。
- `__syncthreads()` 是否由所有活跃 block 线程到达。
- 最终只有一个线程写输出，或 atomic 的必要性。

不能把需要全 grid 同步的算法直接写成单 kernel，除非使用已明确的 cooperative launch 并验证设备/launch 支持；baseline 优先拆为多个 kernel 或改写映射。

## Transpose 映射

二维 transpose 的 baseline 可使用 shared-memory tile：

```text
blockIdx.x/y -> input tile
threadIdx.x -> contiguous input column
threadIdx.y -> tile row strip
load input tile to shared memory
uniform barrier
swap block coordinates
store contiguous output columns
```

shared tile 通常需要 padding 避免 bank conflict，例如第二维 `TILE_DIM + 1`。具体 tile/block 值只是候选，必须满足 shared memory 与 thread/block 限制，并在 spec 中落定。

## Gather、scatter 与 atomic

- gather：输出元素通常唯一写入，读取 index 必须检查用户合同规定的范围行为。
- scatter：分析目标 index 是否唯一。无法证明唯一时，必须使用与数学合同匹配的 atomic 或提出阻塞问题。
- atomic 浮点归约可能非确定；如果需求要求确定性，不能用“通常误差很小”绕过。
- index tensor dtype 和负 index 规则必须来自 requirement。

## Bounds 与谓词

为每类 memory access 列出 predicate：

```json
{
  "access": "x[row * stride_x0 + col * stride_x1]",
  "predicate": "0 <= row < M && 0 <= col < N",
  "proof": "row/col are derived from launch coordinates and guarded before access"
}
```

共享内存访问也需要范围证明，不能只检查 global pointer。向量访问要单独说明主体区间和 scalar tail。

## 输出 Schema

```json
{
  "schema_version": 1,
  "operator_name": "affine_relu",
  "mapping_kind": "one_dimensional_coverage",
  "logical_domain": {
    "axes": [{"name": "i", "range": "0 <= i < N"}],
    "total_elements": "N"
  },
  "launch": {
    "block": {"x": 256, "y": 1, "z": 1},
    "grid": {
      "x": "ceil_div(N, block.x)",
      "y": 1,
      "z": 1
    },
    "dynamic_shared_bytes": 0,
    "stream": "stream",
    "zero_size": "return cudaSuccess without launch"
  },
  "thread_coordinates": [
    {
      "logical": "i",
      "expression": "int64(blockIdx.x) * blockDim.x + threadIdx.x",
      "predicate": "i < N"
    }
  ],
  "coverage": {
    "writes_per_valid_output": "exactly_one",
    "overlap": "none",
    "tail_handling": "predicate i < N",
    "proof": "Euclidean division maps each i to one block/lane pair"
  },
  "memory_accesses": [
    {
      "tensor": "x",
      "mode": "read",
      "offset": "i",
      "predicate": "i < N",
      "coalescing": "adjacent lanes access adjacent float elements"
    },
    {
      "tensor": "y",
      "mode": "write",
      "offset": "i",
      "predicate": "i < N",
      "coalescing": "adjacent lanes access adjacent float elements"
    }
  ],
  "index_types": {
    "logical_index": "int64_t",
    "launch_dimensions": "unsigned int",
    "overflow_checks": ["N >= 0", "ceil_div(N, block.x) <= maxGridSize[0]"]
  },
  "synchronization": [],
  "atomics": [],
  "candidate_blocks": [128, 256, 512],
  "selected_baseline_block": 256,
  "selection_reason": "legal conservative baseline; final value requires measurement",
  "open_issues": []
}
```

不同 pattern 可以扩展字段，但固定顶层字段不得缺失。

## 覆盖证明

### 唯一性

普通 1D 映射中，线程全局坐标为 `i=b*T+t`，其中 `0<=t<T`。对任意非负 `i`，欧几里得除法给出唯一 `b=floor(i/T)` 与 `t=i mod T`，因此不同有效线程不会写同一 `i`。

### 完整性

当 `grid.x=ceil(N/T)` 且 `N>0`，最后一个有效 index `N-1` 满足：

```text
floor((N-1)/T) < ceil(N/T)
```

因此所有 `[0,N)` 均有线程覆盖。额外线程由 `i<N` 屏蔽。

### Grid-stride

令总线程数 `S=blockDim.x*gridDim.x>0`。每个逻辑 index 可唯一写成 `i=r+qS`，`0<=r<S`，因此由初始线程 `r` 在第 `q` 次循环覆盖。需要保证 `i += S` 不溢出；可以用 unsigned/64-bit 范围检查。

## 合并访问评价

对每个 memory access 写结论，而不是只写“coalesced”：

- lane-to-address 差值是什么？
- 一个 warp 是否访问连续元素？
- 元素字节数和潜在对齐是什么？
- 是否有跨 stride、broadcast 或 scatter？
- 尾部访问如何保护？

若访问天然不规则，诚实标记 `irregular`；后续阶段可考虑 shared-memory 重排，但不能伪称合并。

## 资源合法性检查

从共享平台规则获取并检查：

- block 总线程数
- block 各维上限
- grid 各维上限
- shared memory/block
- register 压力的潜在风险

此阶段可以根据算法估计 shared memory 表达式，但准确字节数在 GenerateSpec 落定。不要硬编码一份与共享规则重复的平台常数表。

## 失败与保守回退

| 问题 | 处理 |
|---|---|
| 输出域未知 | 停止，要求补充 shape 公式 |
| scatter 冲突未知 | 停止，要求确定性/atomic 语义 |
| alignment 未知 | 使用 scalar mapping，不假设向量对齐 |
| stride 未知 | 使用显式 runtime stride，不假设连续 |
| grid 维超限 | 扁平化或 grid-stride，并给出证明 |
| block 候选资源不合法 | 移除候选，不通过编译尝试碰碰运气 |
| 空输入可能产生 grid=0 | wrapper 早返回 |

## 完成检查

- [ ] 所有逻辑输出轴与 CUDA 坐标有映射。
- [ ] grid/block/dynamic shared/stream 表达式齐全。
- [ ] 每个读写均有 offset、predicate 和 coalescing 描述。
- [ ] 证明覆盖完整且写入无意外重叠。
- [ ] index 类型与 overflow check 明确。
- [ ] reduction/sync/atomic 参与范围明确。
- [ ] 空输入和非整 block 已处理。
- [ ] JSON 标准可解析，`open_issues` 为空后才能交接。
