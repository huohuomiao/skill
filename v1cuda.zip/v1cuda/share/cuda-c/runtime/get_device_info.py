#!/usr/bin/env python3
"""Collect Linux CUDA C/C++ toolchain and RTX 3090 device facts as JSON."""

from __future__ import annotations

import argparse
import csv
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from io import StringIO
from pathlib import Path
from typing import Any


RTX_3090 = re.compile(r"^(?:NVIDIA\s+)?GeForce\s+RTX\s+3090$", re.IGNORECASE)
SMI_FIELDS = (
    "index",
    "uuid",
    "pci.bus_id",
    "name",
    "driver_version",
    "memory.total",
    "memory.used",
    "memory.free",
    "utilization.gpu",
    "temperature.gpu",
)
PROBE_SOURCE = r'''
#include <cuda_runtime.h>
#include <cstdlib>
#include <iostream>

static int fail(cudaError_t status, const char* operation) {
    std::cerr << operation << ": " << cudaGetErrorString(status) << "\n";
    return 20 + static_cast<int>(status);
}

int main(int argc, char** argv) {
    const int requested = argc > 1 ? std::atoi(argv[1]) : 0;
    int count = 0;
    cudaError_t status = cudaGetDeviceCount(&count);
    if (status != cudaSuccess) return fail(status, "cudaGetDeviceCount");
    if (requested < 0 || requested >= count) {
        std::cerr << "logical device " << requested << " is outside [0," << count << ")\n";
        return 10;
    }
    status = cudaSetDevice(requested);
    if (status != cudaSuccess) return fail(status, "cudaSetDevice");
    cudaDeviceProp p{};
    status = cudaGetDeviceProperties(&p, requested);
    if (status != cudaSuccess) return fail(status, "cudaGetDeviceProperties");
    char pci[32] = {};
    status = cudaDeviceGetPCIBusId(pci, sizeof(pci), requested);
    if (status != cudaSuccess) return fail(status, "cudaDeviceGetPCIBusId");
    std::cout << "logical_index=" << requested << "\n";
    std::cout << "visible_device_count=" << count << "\n";
    std::cout << "name=" << p.name << "\n";
    std::cout << "pci_bus_id=" << pci << "\n";
    std::cout << "major=" << p.major << "\n";
    std::cout << "minor=" << p.minor << "\n";
    std::cout << "multiprocessor_count=" << p.multiProcessorCount << "\n";
    std::cout << "total_global_memory_bytes="
              << static_cast<unsigned long long>(p.totalGlobalMem) << "\n";
    return 0;
}
'''


def run(command: list[str], timeout: int) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        capture_output=True,
        text=True,
        errors="replace",
        timeout=timeout,
        check=False,
    )


def clean(value: str) -> str | None:
    value = value.strip()
    return None if value in {"", "N/A", "[N/A]", "Not Supported"} else value


def integer(value: str | None) -> int | None:
    if value is None:
        return None
    match = re.search(r"-?\d+", value.replace(",", ""))
    return int(match.group()) if match else None


def exact_rtx_3090(name: str | None) -> bool:
    return bool(name and RTX_3090.fullmatch(" ".join(name.split())))


def pci_key(value: str | None) -> str | None:
    if value is None:
        return None
    match = re.search(r"([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$", value, re.I)
    return ":".join(match.groups()).lower() if match else value.strip().lower()


def collect_nvidia_smi() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    executable = shutil.which("nvidia-smi")
    command = [
        executable or "nvidia-smi",
        f"--query-gpu={','.join(SMI_FIELDS)}",
        "--format=csv,noheader,nounits",
    ]
    meta: dict[str, Any] = {"available": executable is not None, "command": command}
    if executable is None:
        meta["error"] = "nvidia-smi was not found on PATH"
        return [], meta
    try:
        proc = run(command, 15)
    except (OSError, subprocess.SubprocessError) as exc:
        meta["error"] = f"{type(exc).__name__}: {exc}"
        return [], meta
    meta.update(returncode=proc.returncode, stderr=proc.stderr.strip())
    if proc.returncode != 0:
        meta["error"] = "nvidia-smi query failed"
        return [], meta
    rows = list(csv.reader(StringIO(proc.stdout)))
    devices: list[dict[str, Any]] = []
    for row in rows:
        if len(row) != len(SMI_FIELDS):
            continue
        values = dict(zip(SMI_FIELDS, (clean(item) for item in row)))
        item = {
            "index": integer(values["index"]),
            "uuid": values["uuid"],
            "pci_bus_id": values["pci.bus_id"],
            "name": values["name"],
            "driver_version": values["driver_version"],
            "memory_total_mib": integer(values["memory.total"]),
            "memory_used_mib": integer(values["memory.used"]),
            "memory_free_mib": integer(values["memory.free"]),
            "utilization_gpu_percent": integer(values["utilization.gpu"]),
            "temperature_c": integer(values["temperature.gpu"]),
        }
        item["is_exact_rtx_3090"] = exact_rtx_3090(item["name"])
        devices.append(item)
    if not devices:
        meta["error"] = f"no valid {len(SMI_FIELDS)}-column GPU rows were returned"
    return devices, meta


def collect_nvcc() -> dict[str, Any]:
    executable = shutil.which("nvcc")
    result: dict[str, Any] = {"available": executable is not None, "path": executable}
    if executable is None:
        result["error"] = "nvcc was not found on PATH"
        return result
    try:
        proc = run([executable, "--version"], 15)
    except (OSError, subprocess.SubprocessError) as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result
    output = "\n".join(part.strip() for part in (proc.stdout, proc.stderr) if part.strip())
    release = re.search(r"release\s+(\d+\.\d+)", output, re.I)
    build = re.search(r"\bV(\d+\.\d+\.\d+)\b", output)
    result.update(
        returncode=proc.returncode,
        release=release.group(1) if release else None,
        build=build.group(1) if build else None,
        version_output=output,
    )
    if proc.returncode != 0:
        result["error"] = "nvcc --version failed"
    return result


def collect_host_compiler() -> dict[str, Any]:
    configured = os.environ.get("NVCC_CCBIN")
    candidates = [configured] if configured else []
    candidates.extend(["g++", "gcc", "clang++", "clang", "c++", "cc"])
    for candidate in candidates:
        if not candidate:
            continue
        executable = shutil.which(candidate)
        if executable is None and Path(candidate).is_file():
            executable = str(Path(candidate).resolve())
        if executable:
            return {
                "configured_nvcc_ccbin": configured,
                "available_on_path": True,
                "path": executable,
                "note": "the nvcc compile probe is the compatibility check",
            }

    return {
        "configured_nvcc_ccbin": configured,
        "available_on_path": False,
        "path": None,
        "note": "Linux GCC/Clang host compiler was not found",
    }


def parse_probe_output(output: str) -> dict[str, Any]:
    raw: dict[str, str] = {}
    for line in output.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            raw[key.strip()] = value.strip()
    required = {"name", "pci_bus_id", "major", "minor", "multiprocessor_count", "total_global_memory_bytes"}
    missing = sorted(required.difference(raw))
    if missing:
        raise ValueError(f"runtime probe omitted fields: {', '.join(missing)}")
    numeric = {
        "logical_index", "visible_device_count", "major", "minor",
        "multiprocessor_count", "total_global_memory_bytes",
    }
    result: dict[str, Any] = {key: int(value) if key in numeric else value for key, value in raw.items()}
    result["compute_capability"] = f"{result['major']}.{result['minor']}"
    result["cuda_target"] = f"sm_{result['major']}{result['minor']}"
    result["is_exact_rtx_3090"] = exact_rtx_3090(result["name"])
    return result


def collect_runtime_probe(nvcc: dict[str, Any], logical_device: int) -> dict[str, Any]:
    result: dict[str, Any] = {
        "logical_device": logical_device,
        "compile_target": "sm_86",
        "compiled": False,
        "ran": False,
    }
    executable = nvcc.get("path")
    if platform.system() != "Linux":
        result["error"] = "CUDA C/C++ runtime validation requires Linux"
        return result
    if not executable:
        result["error"] = "nvcc is unavailable"
        return result
    try:
        with tempfile.TemporaryDirectory(prefix="cuda_device_probe_") as temp_name:
            temp_dir = Path(temp_name)
            source = temp_dir / "device_probe.cu"
            binary = temp_dir / "device_probe"
            source.write_text(PROBE_SOURCE, encoding="utf-8", newline="\n")
            compile_command = [str(executable), "-std=c++17", "-arch=sm_86", str(source), "-o", str(binary)]
            result["compile_command"] = compile_command
            compiled = run(compile_command, 120)
            result.update(
                compile_returncode=compiled.returncode,
                compile_stdout=compiled.stdout.strip(),
                compile_stderr=compiled.stderr.strip(),
                compiled=compiled.returncode == 0 and binary.is_file(),
            )
            if not result["compiled"]:
                result["error"] = "CUDA Runtime probe compilation failed"
                return result
            run_command = [str(binary), str(logical_device)]
            result["run_command"] = run_command
            executed = run(run_command, 30)
            result.update(
                run_returncode=executed.returncode,
                run_stdout=executed.stdout.strip(),
                run_stderr=executed.stderr.strip(),
                ran=executed.returncode == 0,
            )
            if executed.returncode != 0:
                result["error"] = "CUDA Runtime probe execution failed"
                return result
            result["device"] = parse_probe_output(executed.stdout)
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def select_smi_device(
    devices: list[dict[str, Any]], runtime_device: dict[str, Any] | None, logical_device: int
) -> dict[str, Any] | None:
    runtime_pci = pci_key((runtime_device or {}).get("pci_bus_id"))
    if runtime_pci:
        for device in devices:
            if pci_key(device.get("pci_bus_id")) == runtime_pci:
                return device
    if not os.environ.get("CUDA_VISIBLE_DEVICES"):
        for device in devices:
            if device.get("index") == logical_device:
                return device
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", type=int, default=0, help="CUDA-visible logical device index")
    parser.add_argument(
        "--allow-other-gpu",
        action="store_true",
        help="return success for a working non-RTX-3090 CUDA device while reporting exact_match=false",
    )
    parser.add_argument("--indent", type=int, default=2, help="JSON indentation; use 0 for compact JSON")
    args = parser.parse_args()

    smi_devices, smi = collect_nvidia_smi()
    nvcc = collect_nvcc()
    operating_system = platform.system()
    host_compiler = collect_host_compiler()
    runtime = collect_runtime_probe(nvcc, args.device)
    runtime_device = runtime.get("device")
    selected_smi = select_smi_device(smi_devices, runtime_device, args.device)

    reasons: list[str] = []
    if operating_system != "Linux":
        reasons.append(f"operating system is {operating_system!r}, expected 'Linux'")
    if args.device < 0:
        reasons.append("logical device index must be non-negative")
    if selected_smi is None:
        reasons.append(smi.get("error", "nvidia-smi device could not be correlated with the CUDA Runtime device"))
    elif not selected_smi["is_exact_rtx_3090"]:
        reasons.append(f"nvidia-smi name is not exact RTX 3090: {selected_smi.get('name')!r}")
    if not nvcc.get("available") or nvcc.get("returncode") != 0:
        reasons.append(nvcc.get("error", "nvcc validation failed"))
    if not host_compiler.get("path"):
        reasons.append(host_compiler.get("note", "Linux host compiler validation failed"))
    if not runtime.get("compiled") or not runtime.get("ran") or runtime_device is None:
        reasons.append(runtime.get("error", "CUDA Runtime probe failed"))
    else:
        if not runtime_device["is_exact_rtx_3090"]:
            reasons.append(f"CUDA Runtime name is not exact RTX 3090: {runtime_device['name']!r}")
        if runtime_device["compute_capability"] != "8.6":
            reasons.append(
                f"CUDA Runtime compute capability is {runtime_device['compute_capability']}, expected 8.6"
            )
        if runtime_device["multiprocessor_count"] != 82:
            reasons.append(
                f"CUDA Runtime SM count is {runtime_device['multiprocessor_count']}, expected 82"
            )

    environment_ready = bool(
        operating_system == "Linux"
        and host_compiler.get("path")
        and selected_smi is not None
        and runtime.get("compiled")
        and runtime.get("ran")
    )
    exact_match = bool(
        environment_ready
        and selected_smi["is_exact_rtx_3090"]
        and runtime_device
        and runtime_device["is_exact_rtx_3090"]
        and runtime_device["compute_capability"] == "8.6"
        and runtime_device["multiprocessor_count"] == 82
    )
    summary = {
        "schema_version": 2,
        "collected_at_utc": datetime.now(timezone.utc).isoformat(),
        "requested_logical_device": args.device,
        "operating_system": operating_system,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "nvidia_smi": {**smi, "devices": smi_devices, "selected_device": selected_smi},
        "toolchain": {"nvcc": nvcc, "host_compiler": host_compiler},
        "cuda_runtime_probe": runtime,
        "target": {
            "expected_name": "NVIDIA GeForce RTX 3090",
            "expected_compute_capability": "8.6",
            "expected_cuda_target": "sm_86",
            "expected_multiprocessor_count": 82,
            "environment_ready": environment_ready,
            "exact_match": exact_match,
            "reasons": reasons,
        },
    }
    print(json.dumps(summary, indent=None if args.indent == 0 else args.indent, ensure_ascii=False, sort_keys=True))
    if not smi_devices or selected_smi is None:
        return 2
    if not environment_ready:
        return 3
    if not exact_match and not args.allow_other_gpu:
        return 4
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
