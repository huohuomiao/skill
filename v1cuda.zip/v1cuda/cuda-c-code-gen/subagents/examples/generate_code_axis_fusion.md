# Code 示例：连续轴融合的完整 CUDA C++ 程序

下面程序把连续三维 `[B,M,N]` 融合为一维线程域，实现 affine + ReLU，包含 wrapper、CPU reference、尾部用例、API 检查和 CUDA Event benchmark。可直接保存为 `.cu`：

```cpp
#include <cuda_runtime.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <random>
#include <vector>

static bool cuda_ok(cudaError_t status, const char* expr, int line) {
    if (status == cudaSuccess) return true;
    std::fprintf(stderr, "CUDA_ERROR line=%d expr=%s name=%s message=%s\n",
                 line, expr, cudaGetErrorName(status), cudaGetErrorString(status));
    return false;
}
#define CUDA_OK(expr) cuda_ok((expr), #expr, __LINE__)

static bool checked_mul(std::int64_t a, std::int64_t b, std::int64_t* out) {
    if (a < 0 || b < 0 || out == nullptr) return false;
    if (a != 0 && b > std::numeric_limits<std::int64_t>::max() / a) return false;
    *out = a * b;
    return true;
}

__global__ void affine_relu_kernel(const float* x, float* y,
                                   std::int64_t total,
                                   float alpha, float beta) {
    const std::int64_t i =
        static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i < total) {
        const float value = alpha * x[i] + beta;
        y[i] = value > 0.0f ? value : 0.0f;
    }
}

cudaError_t launch_affine_relu_3d(const float* x, float* y,
                                  std::int64_t b, std::int64_t m,
                                  std::int64_t n, float alpha, float beta,
                                  cudaStream_t stream) {
    std::int64_t bm = 0;
    std::int64_t total = 0;
    if (!checked_mul(b, m, &bm) || !checked_mul(bm, n, &total)) {
        return cudaErrorInvalidValue;
    }
    if (total == 0) return cudaSuccess;
    if (x == nullptr || y == nullptr) return cudaErrorInvalidDevicePointer;
    constexpr unsigned threads = 256;
    const std::uint64_t blocks =
        (static_cast<std::uint64_t>(total) + threads - 1) / threads;
    if (blocks > std::numeric_limits<unsigned>::max()) {
        return cudaErrorInvalidConfiguration;
    }
    affine_relu_kernel<<<static_cast<unsigned>(blocks), threads, 0, stream>>>(
        x, y, total, alpha, beta);
    return cudaGetLastError();
}

static void reference(const std::vector<float>& x, std::vector<float>* y,
                      float alpha, float beta) {
    y->resize(x.size());
    for (std::size_t i = 0; i < x.size(); ++i) {
        const float value = alpha * x[i] + beta;
        (*y)[i] = value > 0.0f ? value : 0.0f;
    }
}

static bool nearly_equal(float a, float b, double atol, double rtol) {
    if (std::isnan(b)) return std::isnan(a);
    if (std::isinf(b)) return a == b;
    const double diff = std::abs(static_cast<double>(a) - b);
    return diff <= atol + rtol * std::abs(static_cast<double>(b));
}

static bool run_case(std::int64_t b, std::int64_t m, std::int64_t n,
                     float alpha, float beta, unsigned seed) {
    std::int64_t bm = 0;
    std::int64_t total = 0;
    if (!checked_mul(b, m, &bm) || !checked_mul(bm, n, &total)) return false;
    if (total == 0) {
        const cudaError_t status =
            launch_affine_relu_3d(nullptr, nullptr, b, m, n, alpha, beta, 0);
        const bool pass = status == cudaSuccess;
        std::printf("CASE_RESULT shape=%lldx%lldx%lld passed=%s\n",
                    static_cast<long long>(b), static_cast<long long>(m),
                    static_cast<long long>(n), pass ? "true" : "false");
        return pass;
    }

    std::vector<float> input(static_cast<std::size_t>(total));
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-3.0f, 3.0f);
    for (float& value : input) value = dist(rng);
    if (input.size() >= 5) {
        input[0] = 0.0f;
        input[1] = -0.0f;
        input[2] = std::numeric_limits<float>::infinity();
        input[3] = -std::numeric_limits<float>::infinity();
        input[4] = std::numeric_limits<float>::quiet_NaN();
    }
    std::vector<float> expected;
    reference(input, &expected, alpha, beta);
    std::vector<float> actual(input.size());
    const std::size_t bytes = input.size() * sizeof(float);
    float* dx = nullptr;
    float* dy = nullptr;
    cudaStream_t stream = nullptr;
    bool ok = CUDA_OK(cudaStreamCreate(&stream));
    ok = ok && CUDA_OK(cudaMalloc(reinterpret_cast<void**>(&dx), bytes));
    ok = ok && CUDA_OK(cudaMalloc(reinterpret_cast<void**>(&dy), bytes));
    ok = ok && CUDA_OK(cudaMemcpyAsync(dx, input.data(), bytes,
                                       cudaMemcpyHostToDevice, stream));
    ok = ok && CUDA_OK(launch_affine_relu_3d(
        dx, dy, b, m, n, alpha, beta, stream));
    ok = ok && CUDA_OK(cudaStreamSynchronize(stream));
    ok = ok && CUDA_OK(cudaMemcpy(actual.data(), dy, bytes,
                                  cudaMemcpyDeviceToHost));

    double max_abs = 0.0;
    std::size_t first_bad = input.size();
    if (ok) {
        for (std::size_t i = 0; i < actual.size(); ++i) {
            if (!nearly_equal(actual[i], expected[i], 1e-6, 1e-6)) {
                first_bad = i;
                break;
            }
            if (!std::isnan(actual[i]) && !std::isnan(expected[i])) {
                max_abs = std::max(max_abs, std::abs(
                    static_cast<double>(actual[i]) - expected[i]));
            }
        }
        ok = first_bad == input.size();
    }
    if (!ok && first_bad != input.size()) {
        std::fprintf(stderr, "ACCURACY_FAIL index=%zu expected=%.9g actual=%.9g\n",
                     first_bad, expected[first_bad], actual[first_bad]);
    }
    if (dx != nullptr) ok = CUDA_OK(cudaFree(dx)) && ok;
    if (dy != nullptr) ok = CUDA_OK(cudaFree(dy)) && ok;
    if (stream != nullptr) ok = CUDA_OK(cudaStreamDestroy(stream)) && ok;
    std::printf("CASE_RESULT shape=%lldx%lldx%lld passed=%s max_abs_error=%.9g\n",
                static_cast<long long>(b), static_cast<long long>(m),
                static_cast<long long>(n), ok ? "true" : "false", max_abs);
    return ok;
}

static bool benchmark() {
    constexpr std::int64_t b = 64, m = 512, n = 512;
    constexpr std::int64_t total = b * m * n;
    constexpr int warmup = 20, iterations = 100;
    const std::size_t bytes = static_cast<std::size_t>(total) * sizeof(float);
    float* dx = nullptr;
    float* dy = nullptr;
    cudaStream_t stream = nullptr;
    cudaEvent_t start = nullptr, stop = nullptr;
    bool ok = CUDA_OK(cudaStreamCreate(&stream));
    ok = ok && CUDA_OK(cudaMalloc(reinterpret_cast<void**>(&dx), bytes));
    ok = ok && CUDA_OK(cudaMalloc(reinterpret_cast<void**>(&dy), bytes));
    ok = ok && CUDA_OK(cudaMemsetAsync(dx, 0, bytes, stream));
    ok = ok && CUDA_OK(cudaEventCreate(&start));
    ok = ok && CUDA_OK(cudaEventCreate(&stop));
    for (int i = 0; ok && i < warmup; ++i)
        ok = CUDA_OK(launch_affine_relu_3d(dx, dy, b, m, n, 1.25f, -0.3f, stream));
    ok = ok && CUDA_OK(cudaStreamSynchronize(stream));
    ok = ok && CUDA_OK(cudaEventRecord(start, stream));
    for (int i = 0; ok && i < iterations; ++i)
        ok = CUDA_OK(launch_affine_relu_3d(dx, dy, b, m, n, 1.25f, -0.3f, stream));
    ok = ok && CUDA_OK(cudaEventRecord(stop, stream));
    ok = ok && CUDA_OK(cudaEventSynchronize(stop));
    float elapsed = 0.0f;
    ok = ok && CUDA_OK(cudaEventElapsedTime(&elapsed, start, stop));
    if (ok) {
        const double ms = elapsed / iterations;
        const double gbps = (2.0 * bytes) / (ms * 1.0e6);
        std::printf("BENCHMARK_RESULT warmup=%d iterations=%d kernel_ms=%.6f effective_gbps=%.3f\n",
                    warmup, iterations, ms, gbps);
    }
    if (start) ok = CUDA_OK(cudaEventDestroy(start)) && ok;
    if (stop) ok = CUDA_OK(cudaEventDestroy(stop)) && ok;
    if (dx) ok = CUDA_OK(cudaFree(dx)) && ok;
    if (dy) ok = CUDA_OK(cudaFree(dy)) && ok;
    if (stream) ok = CUDA_OK(cudaStreamDestroy(stream)) && ok;
    return ok;
}

int main() {
    cudaDeviceProp prop{};
    if (!CUDA_OK(cudaGetDeviceProperties(&prop, 0))) return 2;
    if (prop.major != 8 || prop.minor != 6) {
        std::fprintf(stderr, "TARGET_MISMATCH name=%s cc=%d.%d expected=8.6\n",
                     prop.name, prop.major, prop.minor);
        return 2;
    }
    const std::int64_t cases[][3] = {
        {0, 5, 7}, {1, 1, 1}, {1, 1, 255}, {1, 2, 128}, {3, 7, 19}
    };
    for (unsigned i = 0; i < 5; ++i) {
        if (!run_case(cases[i][0], cases[i][1], cases[i][2],
                      1.25f, -0.3f, 20260813u + i)) return 1;
    }
    if (!benchmark()) return 1;
    std::puts("FINAL_RESULT accuracy_pass=true benchmark_pass=true fast_math=false");
    return 0;
}
```

编译：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 axis_fusion.cu -o axis_fusion
```

该示例为了保持单文件清晰使用手动清理；生产生成器也可输出 RAII buffer/event，但必须保证析构错误不会覆盖主要失败原因。程序默认严格检查 CC 8.6；若还要求设备名称精确为 RTX 3090，应按 EnvConfig 合同增加 name gate。
