# Code 示例：可执行的共享内存矩阵转置

该示例是完整 `.cu` 程序，使用 padded shared tile 保持输入读取和输出写入合并访问，并覆盖双维 tail、CUDA 错误和 Event 计时。

```cpp
#include <cuda_runtime.h>

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <random>
#include <vector>

static bool check(cudaError_t s, const char* e, int line) {
    if (s == cudaSuccess) return true;
    std::fprintf(stderr, "CUDA_ERROR line=%d expr=%s name=%s message=%s\n",
                 line, e, cudaGetErrorName(s), cudaGetErrorString(s));
    return false;
}
#define CHECK(expr) check((expr), #expr, __LINE__)

template <int TileDim, int BlockRows>
__global__ void transpose_kernel(const float* __restrict__ x,
                                 float* __restrict__ y,
                                 std::int64_t m, std::int64_t n) {
    __shared__ float tile[TileDim][TileDim + 1];
    const std::int64_t in_col =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.x;
    const std::int64_t in_row =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.y;
    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (in_col < n && in_row + j < m)
            tile[threadIdx.y + j][threadIdx.x] = x[(in_row + j) * n + in_col];
    }
    __syncthreads();
    const std::int64_t out_col =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.x;
    const std::int64_t out_row =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.y;
    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (out_col < m && out_row + j < n)
            y[(out_row + j) * m + out_col] = tile[threadIdx.x][threadIdx.y + j];
    }
}

cudaError_t launch_transpose(const float* x, float* y,
                             std::int64_t m, std::int64_t n,
                             cudaStream_t stream) {
    if (m < 0 || n < 0) return cudaErrorInvalidValue;
    if (m == 0 || n == 0) return cudaSuccess;
    if (x == nullptr || y == nullptr) return cudaErrorInvalidDevicePointer;
    constexpr unsigned tile = 32;
    const std::uint64_t gx = (static_cast<std::uint64_t>(n) + tile - 1) / tile;
    const std::uint64_t gy = (static_cast<std::uint64_t>(m) + tile - 1) / tile;
    if (gx > std::numeric_limits<unsigned>::max() || gy > 65535u)
        return cudaErrorInvalidConfiguration;
    transpose_kernel<32, 8><<<dim3(static_cast<unsigned>(gx),
                                     static_cast<unsigned>(gy)),
                               dim3(32, 8), 0, stream>>>(x, y, m, n);
    return cudaGetLastError();
}

static bool checked_count(std::int64_t m, std::int64_t n, std::size_t* count) {
    if (m < 0 || n < 0 || count == nullptr) return false;
    const std::uint64_t um = static_cast<std::uint64_t>(m);
    const std::uint64_t un = static_cast<std::uint64_t>(n);
    if (um != 0 && un > std::numeric_limits<std::size_t>::max() / um) return false;
    *count = static_cast<std::size_t>(um * un);
    return *count <= std::numeric_limits<std::size_t>::max() / sizeof(float);
}

static void cpu_transpose(const std::vector<float>& x, std::vector<float>* y,
                          std::int64_t m, std::int64_t n) {
    y->assign(x.size(), 0.0f);
    for (std::int64_t row = 0; row < m; ++row)
        for (std::int64_t col = 0; col < n; ++col)
            (*y)[static_cast<std::size_t>(col * m + row)] =
                x[static_cast<std::size_t>(row * n + col)];
}

static bool run_case(std::int64_t m, std::int64_t n, unsigned seed) {
    std::size_t count = 0;
    if (!checked_count(m, n, &count)) return false;
    if (count == 0) return launch_transpose(nullptr, nullptr, m, n, 0) == cudaSuccess;
    std::vector<float> x(count), expected, actual(count);
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-10.0f, 10.0f);
    for (float& v : x) v = dist(rng);
    cpu_transpose(x, &expected, m, n);
    const std::size_t bytes = count * sizeof(float);
    float* dx = nullptr;
    float* dy = nullptr;
    cudaStream_t stream = nullptr;
    bool ok = CHECK(cudaStreamCreate(&stream));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dx), bytes));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dy), bytes));
    ok = ok && CHECK(cudaMemcpyAsync(dx, x.data(), bytes, cudaMemcpyHostToDevice, stream));
    ok = ok && CHECK(launch_transpose(dx, dy, m, n, stream));
    ok = ok && CHECK(cudaStreamSynchronize(stream));
    ok = ok && CHECK(cudaMemcpy(actual.data(), dy, bytes, cudaMemcpyDeviceToHost));
    std::size_t bad = count;
    if (ok) {
        for (std::size_t i = 0; i < count; ++i) {
            if (actual[i] != expected[i]) { bad = i; break; }
        }
        ok = bad == count;
    }
    if (!ok && bad != count)
        std::fprintf(stderr, "ACCURACY_FAIL linear=%zu expected=%g actual=%g\n",
                     bad, expected[bad], actual[bad]);
    if (dx) ok = CHECK(cudaFree(dx)) && ok;
    if (dy) ok = CHECK(cudaFree(dy)) && ok;
    if (stream) ok = CHECK(cudaStreamDestroy(stream)) && ok;
    std::printf("CASE_RESULT m=%lld n=%lld passed=%s\n",
                static_cast<long long>(m), static_cast<long long>(n),
                ok ? "true" : "false");
    return ok;
}

static bool benchmark() {
    constexpr std::int64_t m = 4096, n = 4096;
    constexpr int warmup = 20, iterations = 100;
    constexpr std::size_t count = static_cast<std::size_t>(m * n);
    constexpr std::size_t bytes = count * sizeof(float);
    float* dx = nullptr;
    float* dy = nullptr;
    cudaStream_t stream = nullptr;
    cudaEvent_t start = nullptr, stop = nullptr;
    bool ok = CHECK(cudaStreamCreate(&stream));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dx), bytes));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dy), bytes));
    ok = ok && CHECK(cudaMemsetAsync(dx, 0, bytes, stream));
    ok = ok && CHECK(cudaEventCreate(&start));
    ok = ok && CHECK(cudaEventCreate(&stop));
    for (int i = 0; ok && i < warmup; ++i)
        ok = CHECK(launch_transpose(dx, dy, m, n, stream));
    ok = ok && CHECK(cudaStreamSynchronize(stream));
    ok = ok && CHECK(cudaEventRecord(start, stream));
    for (int i = 0; ok && i < iterations; ++i)
        ok = CHECK(launch_transpose(dx, dy, m, n, stream));
    ok = ok && CHECK(cudaEventRecord(stop, stream));
    ok = ok && CHECK(cudaEventSynchronize(stop));
    float total_ms = 0.0f;
    ok = ok && CHECK(cudaEventElapsedTime(&total_ms, start, stop));
    if (ok) {
        const double ms = total_ms / iterations;
        const double gbps = (2.0 * bytes) / (ms * 1.0e6);
        std::printf("BENCHMARK_RESULT kernel_ms=%.6f effective_gbps=%.3f warmup=%d iterations=%d\n",
                    ms, gbps, warmup, iterations);
    }
    if (start) ok = CHECK(cudaEventDestroy(start)) && ok;
    if (stop) ok = CHECK(cudaEventDestroy(stop)) && ok;
    if (dx) ok = CHECK(cudaFree(dx)) && ok;
    if (dy) ok = CHECK(cudaFree(dy)) && ok;
    if (stream) ok = CHECK(cudaStreamDestroy(stream)) && ok;
    return ok;
}

int main() {
    cudaDeviceProp prop{};
    if (!CHECK(cudaGetDeviceProperties(&prop, 0))) return 2;
    if (prop.major != 8 || prop.minor != 6) {
        std::fprintf(stderr, "TARGET_MISMATCH name=%s cc=%d.%d expected=8.6\n",
                     prop.name, prop.major, prop.minor);
        return 2;
    }
    const std::int64_t cases[][2] = {
        {0, 17}, {1, 1}, {7, 13}, {32, 32}, {33, 65}, {127, 257}
    };
    for (unsigned i = 0; i < 6; ++i)
        if (!run_case(cases[i][0], cases[i][1], 20260813u + i)) return 1;
    if (!benchmark()) return 1;
    std::puts("FINAL_RESULT accuracy_pass=true benchmark_pass=true fast_math=false");
    return 0;
}
```

构建命令：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 matrix_transpose.cu -o matrix_transpose
```

正式评审还应对 correctness-only 运行 `compute-sanitizer --tool memcheck`、`racecheck` 和 `synccheck`。所有线程无条件到达 barrier；global tail 仅通过 predicated access 处理。
