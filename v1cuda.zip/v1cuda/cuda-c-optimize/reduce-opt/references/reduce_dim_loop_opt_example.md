# Reduce 轴循环优化示例

## 场景 1：线程局部 + Block 分层

### 原始串行实现

```cpp
__global__ void row_sum_serial(
    const float* x, float* y, int rows, int cols) {
  int row = blockIdx.x;
  if (row >= rows || threadIdx.x != 0) return;
  float acc = 0.0f;
  for (int col = 0; col < cols; ++col)
    acc += x[(long long)row * cols + col];
  y[row] = acc;
}
```

只有一个线程工作，候选将 col 分给整个 block。

### 候选实现

```cpp
__inline__ __device__
float warp_sum(float value, unsigned mask, int active) {
  int lane = threadIdx.x & 31;
  for (int offset = 16; offset > 0; offset >>= 1) {
    float other = __shfl_down_sync(mask, value, offset);
    if (lane + offset < active) value += other;
  }
  return value;
}

template<int BLOCK>
__device__ float block_sum(float value) {
  __shared__ float partial[(BLOCK + 31) / 32];
  int lane = threadIdx.x & 31;
  int warp = threadIdx.x >> 5;
  int active = min(32, BLOCK - warp * 32);
  unsigned mask = __ballot_sync(0xffffffffu, lane < active);
  value = warp_sum(value, mask, active);
  if (lane == 0) partial[warp] = value;
  __syncthreads();

  float out = 0.0f;
  if (warp == 0) {
    int warps = (BLOCK + 31) / 32;
    bool take = lane < warps;
    unsigned first = __ballot_sync(0xffffffffu, take);
    out = take ? partial[lane] : 0.0f;
    out = warp_sum(out, first, warps);
  }
  return out;
}

template<int BLOCK>
__global__ void row_sum_block(
    const float* x, float* y, int rows, int cols) {
  int row = blockIdx.x;
  if (row >= rows) return;

  float acc = 0.0f;
  for (int col = threadIdx.x; col < cols; col += BLOCK)
    acc += x[(long long)row * cols + col];

  float total = block_sum<BLOCK>(acc);
  if (threadIdx.x == 0) y[row] = total;
}
```

### Launch

```cpp
constexpr int BLOCK = 256;
row_sum_block<BLOCK><<<dim3(rows), dim3(BLOCK), 0, stream>>>(
    x, y, rows, cols);
```

### 验证重点

- BLOCK 与模板值一致。
- cols 小于/等于/大于 block。
- barrier 由所有 block threads 到达。
- 浮点次序变化仍满足原容差。
- 全部 shape 的并行度；rows 很小时单 block/row 可能不足。
- ptxas register/shared 和 RTX 3090 benchmark。

## 场景 2：每线程多元素与 Unroll

```cpp
template<int BLOCK, int ITEMS>
__global__ void row_sum_items(
    const float* x, float* y, int rows, int cols) {
  int row = blockIdx.x;
  float acc = 0.0f;
  long long base = (long long)row * cols + threadIdx.x;

  for (int col = threadIdx.x; col < cols;
       col += BLOCK * ITEMS) {
#pragma unroll
    for (int item = 0; item < ITEMS; ++item) {
      int c = col + item * BLOCK;
      if (c < cols) acc += x[(long long)row * cols + c];
    }
  }

  float total = block_sum<BLOCK>(acc);
  if (threadIdx.x == 0) y[row] = total;
}
```

ITEMS 增加 ILP，也增加 register 与单线程工作。候选 `ITEMS={1,2,4}` 必须外部独立编译运行，不能默认 4 更快。

## 场景 3：Vector 读取

只有 row base、cols 和 pointer 都满足对齐时建立向量快路径。一个安全 wrapper 可以检查对齐和 `cols % 4 == 0`，不满足时调用标量 kernel。

```cpp
bool aligned =
    reinterpret_cast<uintptr_t>(x) % alignof(float4) == 0;
if (aligned && cols % 4 == 0) {
  // vector candidate
} else {
  // original scalar path
}
```

不要让 vector load 跨行。vector kernel 内仍需正确 block reduction。

## 场景 4：大 Reduce 的两阶段

Pass 1 每 block 写一个 partial：

```cpp
template<int BLOCK>
__global__ void partial_sum(
    const float* x, float* partial, long long n) {
  float local = 0.0f;
  for (long long i =
           (long long)blockIdx.x * BLOCK + threadIdx.x;
       i < n; i += (long long)BLOCK * gridDim.x)
    local += x[i];

  float value = block_sum<BLOCK>(local);
  if (threadIdx.x == 0) partial[blockIdx.x] = value;
}
```

Pass 2 对 partial 归约。性能必须包含两阶段和 buffer 管理；若 buffer 可复用需在两边采用一致口径。

## 场景 5：不应改写

- 用户要求逐位确定性，而候选改变浮点树。
- argmax tie/NaN 语义未定义。
- block 中部分线程提前 return 后仍有 barrier。
- atomic dtype 支持不明确。
- reduce 地址非连续且候选没改善。
- 目标 RTX 3090 不可用，无法作 keep 决策。

这些情况输出原 input 和明确原因。
