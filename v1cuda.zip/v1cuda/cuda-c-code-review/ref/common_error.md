# CUDA C/C++ common-error catalog

Use this catalog for static review. A pattern is a repairable defect only when its preconditions are proved from the source; otherwise record it as requiring compilation or sanitizer evidence.

## 1. Kernel and launch ABI mismatch

Symptoms:

- kernel parameter order or type differs from the launch
- `size_t`, `int64_t`, pointer, or scalar values are passed with an incompatible ABI
- template parameters and runtime arguments are confused
- a launch uses the wrong overload or stale signature

Consequences range from compilation failure to silent address corruption. Match every argument against the selected kernel instantiation and preserve pointer constness.

## 2. Unchecked asynchronous errors

Kernel launch syntax is asynchronous. Checking only the next host operation can attribute an error to the wrong call.

Require:

```cpp
kernel<<<grid, block, shared_bytes, stream>>>(...);
CUDA_CHECK(cudaGetLastError());
CUDA_CHECK(cudaStreamSynchronize(stream));  // or an equivalent checked completion point
```

Check allocations, copies, memset, stream/event operations, and cleanup too. Do not insert device-wide synchronization when stream-local ordering suffices.

## 3. Zero or illegal launch dimensions

Launching zero blocks is invalid. Total threads/block must not exceed the runtime device limit; each dimension must also be legal. Multiplying three valid-looking dimensions may still exceed 1024.

Handle empty work before launch and validate calculated `dim3` values. Use runtime properties for legal limits; target-specific policy lives in `share/cuda-c/references/platform-rules.md`.

## 4. Ordinary grid capped to SM count

This is wrong unless the kernel contains a complete grid-stride loop:

```cpp
int blocks = min(logical_blocks, prop.multiProcessorCount);
kernel<<<blocks, threads>>>(...);  // one tile per block: remaining tiles are lost
```

For ordinary kernels, launch all logical blocks. For persistent/grid-stride kernels, advance by the actual launched grid size and cover every logical item.

## 5. 32-bit index overflow

An assignment to `size_t` after an `int` multiplication is too late:

```cpp
size_t offset = row * stride;  // multiplication may overflow as int
```

Widen before multiplication:

```cpp
size_t offset = static_cast<size_t>(row) * static_cast<size_t>(stride);
```

Apply the same rule to byte counts, flattened indices, grid calculations, and shared-memory sizes.

## 6. Missing or incomplete tail guard

A guard for the first vector lane does not prove all lanes are in range. Check the full vector or use a scalar tail. Loads and stores may need different guards when shapes, strides, or padding differ.

Do not repair an OOB by reducing the test shape.

## 7. Misaligned vector access

Casting an arbitrary pointer to `float4*`, `half2*`, or another vector type creates an alignment requirement. Base alignment alone is insufficient if the per-thread byte offset breaks alignment.

Prove pointer and offset alignment for every vectorized iteration, and keep a scalar or narrower tail path. Never rely on observed allocator alignment when the public API permits sliced/offset pointers.

## 8. Divergent block barrier

This can deadlock or trigger synccheck:

```cpp
if (idx < n) {
    shared[threadIdx.x] = x[idx];
    __syncthreads();
}
```

All participating threads must reach a block-wide barrier. Predicate the memory operation, place the barrier in uniform control flow, then predicate later work as required.

## 9. Incorrect warp mask

Hardcoding `0xffffffff` is invalid for a partial warp when inactive lanes do not execute the collective. Derive the participation mask with `__ballot_sync` from a condition evaluated by the relevant live warp, then use the same mask consistently. Verify shuffle source lanes are members of the mask.

## 10. Missing shared-memory ordering

Shared-memory writes are not automatically visible to other warps. Insert synchronization between producer and consumer phases, but only at the scope required by the algorithm. A warp synchronization cannot order independent warps; a block barrier cannot order blocks.

## 11. Shared-memory layout or size mismatch

Common defects include:

- dynamic shared byte count smaller than the typed layout
- different typed regions overlap because alignment padding is omitted
- indexing uses a compile-time tile different from the launch candidate
- padding intended to avoid bank conflicts is absent from the allocation calculation

Derive layout and launch bytes from the same constants using overflow-safe `size_t` arithmetic.

## 12. Cross-block race

Blocks have no implicit ordering. A kernel cannot safely consume another block's output through ordinary loads/stores without atomics, a cooperative launch contract, or a kernel boundary. `__syncthreads()` is never a cross-block fix.

## 13. Unsupported atomic or architecture feature

Check atomic dtype/address-space support for the selected Toolkit and `sm_86`. Do not use Hopper/Blackwell-only TMA, WGMMA, clusters, distributed shared memory, or FP8 Tensor Core paths on RTX 3090.

## 14. Asynchronous lifetime violation

Host memory, device memory, stream, event, and temporary workspace must outlive all queued operations that use them. In particular, do not free a buffer immediately after `cudaMemcpyAsync` or kernel launch without an ordering dependency.

## 15. Incomplete output coverage

A successful process can leave part of the output unwritten. Initialize output to a poison value, compare all logical elements, and include non-multiple block sizes. Avoid references that read only the same subset the kernel writes.

## 16. Reference is not independent

Calling the tested kernel, copying the CUDA output, reusing the same faulty index calculation, or selecting a library result only on failure invalidates the reference. Keep the reference structurally independent and freeze it before optimization.

## 17. Test failure does not affect exit status

Printing `FAIL` or a warning and returning 0 causes the review workflow to accept incorrect code. Throw, return nonzero, or otherwise make mismatch observable in the process exit code.

## 18. Timing asynchronous work with a CPU clock

A host timer around a launch measures enqueue latency unless synchronized. Use CUDA events recorded in the same stream for kernel time. Warm up, repeat, and report a robust statistic. Keep sanitizer and NCU runs out of final timing.

## 19. Fast math introduced globally

`--use_fast_math` changes multiple operations and special-value behavior, not just one function. Treat it as a separate candidate under unchanged correctness thresholds. Prefer a local, documented intrinsic experiment when the intended approximation is narrow.

## 20. Performance change accepted without a baseline

Compile baseline and candidate with identical release flags, run them on the same exact RTX 3090, interleave measurements where practical, and keep a candidate only when it passes all correctness/safety gates and improves beyond the noise threshold. NCU replay duration is diagnostic, not the acceptance benchmark.

## 21. Platform residue

Executable Triton, PyTorch, MLU, Cambricon, CNRT, CNDrv, NRAM, or BangUtils code does not belong in the CUDA C/C++ artifact. Compatibility prose in Skill documents is unrelated; the generated `.cu` and build path must contain only the intended CUDA C/C++ implementation and reference harness.
