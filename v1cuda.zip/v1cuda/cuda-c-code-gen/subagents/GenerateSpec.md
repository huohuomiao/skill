# GenerateSpec

## 任务

把基础信息、block/thread 映射和访存规划固化为无歧义的 CUDA C/C++ 实现规格 `step4_code_spec.json`。规格必须足以让 GenerateCode 机械落地，不允许保留“自行选择 block”“必要时同步”“适当优化”等开放决策。

## 输入

- `step1_base_info.json`
- `step2_block_mapping.json`
- `step3_axis_fusion.json`
- `requirement.md`
- `.claude/skills/share/cuda-c/references/platform-rules.md`
- `.claude/skills/share/cuda-c/references/primitives.md`

上游任一 `ready_*` 为 false、存在 blocking/open issues 或 JSON 不一致时，停止并返回对应阶段，不能继续生成猜测规格。

## 规格覆盖范围

必须明确以下内容：

1. translation unit 所需 headers 和 namespace。
2. CUDA 错误检查策略。
3. 每个 `__device__` helper 的签名、数值语义和限定符。
4. 每个 `__global__` kernel 的完整参数、grid/block、动态 shared memory、stream。
5. thread/block 到逻辑索引的准确表达式。
6. 每个 global/shared/register load、compute、store 和 predicate。
7. barrier、warp primitive、atomic 的参与集合和顺序。
8. host wrapper 的参数检查、空输入、launch、错误返回和异步语义。
9. build flags、依赖库和目标架构。
10. CPU reference、测试矩阵、比较规则与 CUDA Event benchmark 的要求。

## Kernel schema

对每个 kernel 创建独立对象：

```json
{
  "name": "affine_relu_kernel",
  "qualifier": "__global__",
  "parameters": [
    {"type": "const float* __restrict__", "name": "x"},
    {"type": "float* __restrict__", "name": "y"},
    {"type": "std::int64_t", "name": "n"},
    {"type": "float", "name": "a"},
    {"type": "float", "name": "b"}
  ],
  "launch_bounds": null,
  "grid": ["ceil_div(n, 256)", 1, 1],
  "block": [256, 1, 1],
  "dynamic_shared_bytes": 0,
  "stream": "stream",
  "indexing": [
    "int64_t i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x"
  ],
  "operations": [
    {
      "order": 1,
      "kind": "guarded_element",
      "predicate": "i < n",
      "body": [
        "float value = fmaf(a, x[i], b)",
        "y[i] = fmaxf(value, 0.0f)"
      ]
    }
  ],
  "barriers": [],
  "warp_intrinsics": [],
  "atomics": [],
  "global_accesses": [
    {"tensor": "x", "mode": "read", "offset": "i", "predicate": "i < n"},
    {"tensor": "y", "mode": "write", "offset": "i", "predicate": "i < n"}
  ],
  "shared_memory": [],
  "register_state": ["i", "value"]
}
```

`__restrict__` 仅在 requirement 明确禁止 x/y overlap 时使用。允许精确原地时，应移除相互冲突的 restrict，并确认读取发生在写入前。

## Launch schema

host wrapper 必须明示：

```json
{
  "name": "launch_affine_relu",
  "return_type": "cudaError_t",
  "parameters": ["...", "cudaStream_t stream"],
  "preconditions": [
    {"condition": "n >= 0", "failure": "cudaErrorInvalidValue"},
    {"condition": "n == 0", "action": "return cudaSuccess"},
    {"condition": "x != nullptr && y != nullptr", "failure": "cudaErrorInvalidDevicePointer"}
  ],
  "launch_dimension_calculation": [
    "threads = 256",
    "blocks64 = ceil_div_u64(uint64_t(n), uint64_t(threads))",
    "validate blocks64 <= device maxGridSize[0] or use specified grid-stride cap"
  ],
  "launch": "affine_relu_kernel<<<grid, block, 0, stream>>>(x, y, n, a, b)",
  "post_launch": "return cudaGetLastError()",
  "synchronization": "none; wrapper is asynchronous with respect to host"
}
```

wrapper 不应无条件 `cudaDeviceSynchronize()`，因为那会破坏 stream 异步语义。测试 harness 在需要读取结果或隔离错误时负责同步。若 wrapper 包含临时 allocation 或跨 stream 生命周期，规格必须明确安全管理方式。

## Grid/block 规格

将上游选择固定成合法整数/公式，并记录选择理由：

```json
{
  "block": {"x": 256, "y": 1, "z": 1, "threads": 256},
  "grid": {"x": "ceil_div(N, 256)", "y": 1, "z": 1},
  "grid_limit_handling": "use grid-stride loop capped at maxGridSize[0]",
  "zero_size_handling": "wrapper returns before launch",
  "selection_basis": "conservative baseline, multiple of warp size, resource legal"
}
```

需要运行时设备属性才能决定的上限，优先生成安全 grid-stride 方案或由 wrapper 查询并检查。不要假设所有合法 `uint32` 值都可用于 y/z grid。

## Shared-memory schema

静态 shared memory：

```json
{
  "storage": "static",
  "declaration": "__shared__ float tile[32][33]",
  "bytes": 4224,
  "writers": "threads with x<M and y<N, each unique element",
  "readers": "same block after barrier",
  "initialization": "valid elements loaded; invalid elements never read due store predicate",
  "barriers": [
    {
      "primitive": "__syncthreads()",
      "position": "after all predicated global loads",
      "reachability": "all block threads; no early return before barrier"
    }
  ]
}
```

动态 shared memory：记录 `extern __shared__` 类型、对齐、subregion offsets、host bytes 公式和设备限制检查。多个类型共享 buffer 时必须按 alignment 向上取整。

## Warp primitive schema

使用 shuffle/ballot/reduce 时必须记录 mask：

```json
{
  "primitive": "__shfl_down_sync",
  "mask_expression": "active_mask",
  "mask_source": "__ballot_sync(0xffffffffu, lane < valid_count)",
  "width": 32,
  "participants": "lanes whose bit is set in active_mask",
  "value_defined_for_participants": true,
  "offsets": [16, 8, 4, 2, 1]
}
```

不能在已分歧分支中机械传 `0xffffffff`。如果所有 32 lanes 都必然到达且值定义完整，可以使用 full mask，但证明要写入规格。

## Barrier schema

每个 barrier 回答：

- 哪些线程到达？
- barrier 前写了什么，后面谁读取？
- 是否存在 barrier 前 return/break？
- 循环中 barrier 的迭代次数是否对所有线程一致？
- 仅需 warp sync 还是完整 block sync？

如果不能证明统一到达，重构控制流。例如：

```cpp
float v = 0.0f;
if (global_valid) {
    v = x[offset];
}
tile[ty][tx] = v;
__syncthreads();
if (output_valid) {
    y[out] = tile[tx][ty];
}
```

而不是在无效线程上提前 return。

## Atomic schema

如果使用 atomic，记录：

- operation/type/address space 的 API 支持依据。
- 多线程写冲突的数学必要性。
- 确定性影响和容差。
- 初始化是谁完成、何时完成。
- 是否需要单独清零 kernel/API。

能通过唯一 mapping 避免 atomic 的 baseline 不应无理由采用 atomic。

## 数值与 math 函数

- 使用精确/标准 CUDA math 函数匹配数值合同。
- `fmaf` 可能改变与分步乘加的舍入；仅当 reference/合同允许相应误差时使用。
- half/bfloat16 默认可提升到 float 计算，按合同转换回输出。
- 不默认启用 `--use_fast_math`。
- 快速 intrinsic 如 `__expf` 只有在需求允许、测试覆盖误差与特殊值且后续实测有效时作为显式候选；baseline 使用对应标准函数。

## 测试 schema

```json
{
  "cpu_reference": {
    "function": "reference_affine_relu",
    "independent_algorithm": true,
    "accumulation_type": "float"
  },
  "correctness_cases": ["C01", "C02", "C03"],
  "comparison": {
    "floating": "abs(actual-expected) <= atol + rtol*abs(expected)",
    "nan": "per requirement",
    "integer": "exact"
  },
  "cuda_checks": [
    "all allocation/copy/event calls",
    "cudaGetLastError immediately after launch",
    "cudaDeviceSynchronize before result read"
  ],
  "benchmark": {
    "method": "CUDA Event",
    "warmup": 20,
    "iterations": 100,
    "scope": "wrapper device work only",
    "case": "P01"
  },
  "failure_exit_code": 1
}
```

warmup/iterations 可按 kernel 时长调整，但必须是确定正整数，并在报告中使用实际值。

## 顶层输出 Schema

```json
{
  "schema_version": 1,
  "operator_name": "...",
  "translation_unit": {
    "language": "CUDA C++17",
    "output": "step5_kernel_code.cu",
    "headers": ["cuda_runtime.h", "cstdint", "cstdio", "cstdlib"],
    "namespaces": [],
    "external_libraries": []
  },
  "build": {
    "compiler": "nvcc",
    "flags": ["-std=c++17", "-O3", "-DNDEBUG", "-lineinfo", "-arch=sm_86"],
    "fast_math": false,
    "command": "nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 step6_test_code.cu -o step6_test_code"
  },
  "error_handling": {
    "helper": "CUDA_CHECK for host/test APIs",
    "wrapper": "returns cudaError_t",
    "launch_check": "cudaGetLastError"
  },
  "device_helpers": [],
  "kernels": [],
  "wrappers": [],
  "tests": {},
  "provenance": {
    "base_info": "step1_base_info.json",
    "mapping": "step2_block_mapping.json",
    "axis_plan": "step3_axis_fusion.json"
  },
  "unresolved": [],
  "ready_for_code": true
}
```

## 参考示例路由

根据 pattern 仅打开必要示例：

| Pattern | Spec 示例 | Code 示例 |
|---|---|---|
| 连续逐元素/维度线性化 | `examples/generate_spec_axis_fusion.md` | `examples/generate_code_axis_fusion.md` |
| transpose + shared tile | `examples/generate_spec_matrix_transpose.md` | `examples/generate_code_matrix_transpose.md` |
| block reduction | `examples/generate_spec_reduce_sum.md` | `examples/generate_code_reduce_sum.md` |
| transpose + elementwise | `examples/generate_spec_transpose_elementwise.md` | `examples/generate_code_transpose_elementwise.md` |

示例用于结构参考，不替代 requirement。不要把示例算子名、shape、容差或 block 配置复制到无关算子。

## 一致性检查

- kernel 参数与 wrapper launch 参数顺序/类型一致。
- grid/block 与 mapping JSON 一致；若 AxisFusion 改变 mapping，使用其完整更新方案。
- shared memory 声明字节数与 host dynamic bytes 一致。
- 所有 barrier/warp/atomic 均在 schema 中列出。
- 每个 memory access 有 predicate 或可证明总在范围内。
- 空输入和非法参数有 wrapper 行为。
- test cases 与 base_info 对齐。
- build flags 明确 `sm_86`、C++17 且 fast math false。
- `unresolved=[]` 且 `ready_for_code=true` 才能交接。

## 失败处理

发现以下冲突应返回对应阶段：

| 冲突 | 返回 |
|---|---|
| 数学/接口不完整 | ExtractBaseInfo / Extractor |
| mapping 无覆盖证明 | TraceBlockMapping |
| stride/axis 融合无依据 | AxisFusion |
| 资源超平台限制 | TraceBlockMapping 或 AxisFusion 重选方案 |
| barrier 无统一到达证明 | AxisFusion 重构 tile/control flow |
| fast math 与合同冲突 | 移除 fast math，保留标准函数 |

禁止在规格中用 TODO、placeholder 或未解析自然语言绕过失败。
