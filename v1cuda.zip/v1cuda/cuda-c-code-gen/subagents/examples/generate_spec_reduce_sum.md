# Spec 示例：二维最后一维求和

## 需求

对连续 float32 输入 `x[rows, cols]` 计算 float32 输出：

```text
y[row] = sum_{col=0}^{cols-1} x[row,col]
```

使用 float32 device accumulator；CPU reference 用 double 累加后转换到 float32。允许 `cols=0`，此时每个 y 为 `0.0f`；`rows=0` 时不 launch。要求固定输入下结果可复现，但不要求与串行 CPU 顺序逐位相同。x/y 不重叠。

## Block 映射

- `blockIdx.x` 唯一对应一个 output row。
- `threadIdx.x` 沿归约轴以 `col=threadIdx.x+q*blockDim.x` 遍历。
- 256 threads/block，即 8 个完整 warp。
- 每线程寄存器累加后，先做 warp shuffle reduction。
- 每个 warp lane 0 写 `warp_sums[warp_id]`。
- 全 block barrier。
- warp 0 读取 8 个 warp sums，其余 lane 用 identity 0，再做一次完整 warp reduction。
- block thread 0 唯一写 y[row]。

因为 blockDim 固定为 256，所有 warp 都是 32 lanes，所有线程执行相同 shuffle 循环，可以使用 full warp mask。无效 col 不退出，只贡献 identity。

## 实现规格

```json
{
  "schema_version": 1,
  "operator_name": "row_sum_f32",
  "translation_unit": {
    "language": "CUDA C++17",
    "headers": ["cuda_runtime.h", "cstdint", "limits", "vector", "cmath"]
  },
  "build": {
    "flags": ["-std=c++17", "-O3", "-DNDEBUG", "-lineinfo", "-arch=sm_86"],
    "fast_math": false
  },
  "constants": {
    "threads": 256,
    "warp_size": 32,
    "warps_per_block": 8
  },
  "device_helpers": [
    {
      "name": "warp_sum",
      "signature": "__device__ __forceinline__ float warp_sum(float value)",
      "mask": "0xffffffffu",
      "offsets": [16, 8, 4, 2, 1],
      "precondition": "all 32 lanes participate and value is defined for every lane"
    }
  ],
  "kernels": [
    {
      "name": "row_sum_f32_kernel",
      "parameters": [
        {"type": "const float* __restrict__", "name": "x"},
        {"type": "float* __restrict__", "name": "y"},
        {"type": "std::int64_t", "name": "rows"},
        {"type": "std::int64_t", "name": "cols"}
      ],
      "grid": ["rows", 1, 1],
      "block": [256, 1, 1],
      "dynamic_shared_bytes": 0,
      "stream": "stream",
      "shared_memory": [
        {
          "declaration": "__shared__ float warp_sums[8]",
          "bytes": 32,
          "writers": "lane 0 of each warp",
          "readers": "warp 0 after block barrier"
        }
      ],
      "operations": [
        "row = int64_t(blockIdx.x)",
        "local = 0.0f",
        "for col=threadIdx.x; col<cols; col+=256: local += x[row*cols+col]",
        "local = warp_sum(local)",
        "if lane==0: warp_sums[warp_id]=local",
        "__syncthreads()",
        "if warp_id==0: total = lane<8 ? warp_sums[lane] : 0.0f; total=warp_sum(total); if lane==0 y[row]=total"
      ],
      "barriers": [
        {
          "primitive": "__syncthreads()",
          "participants": "all 256 threads",
          "position": "after warp_sums writes and before warp 0 reads",
          "uniform_reachability": true
        }
      ],
      "atomics": []
    }
  ],
  "wrappers": [
    {
      "name": "launch_row_sum_f32",
      "return_type": "cudaError_t",
      "preconditions": [
        "rows >= 0 && cols >= 0",
        "rows*cols fits int64_t and allocation size",
        "y is non-null when rows > 0",
        "x is non-null when rows > 0 && cols > 0",
        "rows fits grid.x limit"
      ],
      "zero_rows": "return cudaSuccess",
      "zero_cols": "launch reduction; all lanes contribute 0 and write y rows",
      "launch": "row_sum_f32_kernel<<<rows,256,0,stream>>>(x,y,rows,cols)",
      "post_launch": "return cudaGetLastError()",
      "host_synchronization": "none"
    }
  ],
  "tests": {
    "correctness": [
      {"id": "C01", "rows": 0, "cols": 7, "purpose": "no_output"},
      {"id": "C02", "rows": 5, "cols": 0, "purpose": "empty_reduction"},
      {"id": "C03", "rows": 1, "cols": 1, "purpose": "minimum"},
      {"id": "C04", "rows": 7, "cols": 31, "purpose": "partial_warp_data"},
      {"id": "C05", "rows": 9, "cols": 256, "purpose": "exact_block_stride"},
      {"id": "C06", "rows": 17, "cols": 1003, "purpose": "multi_iteration_tail"},
      {"id": "C07", "rows": 33, "cols": 4097, "purpose": "large_reduction"}
    ],
    "values": ["all_zero", "alternating_sign", "seeded_uniform", "mixed_magnitude"],
    "comparison": {
      "atol": "1e-5 * max(1, cols)",
      "rtol": 0.00001,
      "nan": "not included unless requirement defines propagation"
    },
    "benchmark": {
      "rows": 8192,
      "cols": 4096,
      "warmup": 20,
      "iterations": 100,
      "method": "CUDA Event",
      "logical_bytes": "rows*cols*sizeof(float) + rows*sizeof(float)"
    },
    "sanitizer": ["memcheck", "racecheck", "synccheck", "initcheck"]
  },
  "unresolved": [],
  "ready_for_code": true
}
```

## 对应 CUDA C++ 核心

```cpp
__device__ __forceinline__ float warp_sum(float value) {
    constexpr unsigned mask = 0xffffffffu;
    value += __shfl_down_sync(mask, value, 16);
    value += __shfl_down_sync(mask, value, 8);
    value += __shfl_down_sync(mask, value, 4);
    value += __shfl_down_sync(mask, value, 2);
    value += __shfl_down_sync(mask, value, 1);
    return value;
}

__global__ void row_sum_f32_kernel(const float* __restrict__ x,
                                   float* __restrict__ y,
                                   std::int64_t rows,
                                   std::int64_t cols) {
    __shared__ float warp_sums[8];
    const std::int64_t row = static_cast<std::int64_t>(blockIdx.x);
    float local = 0.0f;
    for (std::int64_t col = threadIdx.x; col < cols; col += blockDim.x) {
        local += x[row * cols + col];
    }
    local = warp_sum(local);
    const unsigned lane = threadIdx.x & 31u;
    const unsigned warp = threadIdx.x >> 5u;
    if (lane == 0) warp_sums[warp] = local;
    __syncthreads();
    if (warp == 0) {
        float total = lane < 8 ? warp_sums[lane] : 0.0f;
        total = warp_sum(total);
        if (lane == 0) y[row] = total;
    }
}
```

`rows` 参数在 kernel 内不用于 guard，因为 wrapper launch 的 grid.x 精确等于 rows；保留它可用于一致签名或移除，但 spec/code 必须一致。不能让 `row>=rows` 的 block 存在。

## 同步和确定性

- 第一次 warp reduction 在每个 warp 内采用固定树。
- warp_sums 每项唯一写入，barrier 后 warp 0 读取，无码态竞争。
- 第二次 warp reduction采用固定树。
- 无 atomic，因此相同 binary、设备、输入和 launch 下具有固定 reduction 顺序。
- 它不会与串行 CPU double sum 逐位相同，accuracy 使用显式容差。

## 边界与验证

- `cols=0` 时 x 可为 null，因为 kernel 不读取；y 必须有效并写 0。
- `rows=0` 时 wrapper 在 y null 检查前返回成功。
- `rows` 超 grid.x 上限时 wrapper 返回 `cudaErrorInvalidConfiguration`，或改用一个明确的 row grid-stride 规格；不能截断 cast。
- `row*cols+col` 使用 64-bit，并由 host 证明乘积不溢出。
- racecheck、synccheck 和 initcheck 应覆盖跨 warp shared 通信。

## 性能解释

该实现是可靠 baseline，不宣称最佳。潜在后续候选包括每 block 多 row、vector load、不同 block size、分段 reduction 或 CUB，但每项都必须重新验证精度、资源和 CUDA Event 性能。
