## 情况 B：普通一维 Grid

### 初始代码

```cpp
template<int BLOCK>
__global__ void copy_kernel(const float* x, float* y, long long n) {
  long long i = (long long)blockIdx.x * BLOCK + threadIdx.x;
  if (i < n) y[i] = x[i];
}

long long logical = (n + BLOCK - 1) / BLOCK;
copy_kernel<BLOCK><<<dim3((unsigned)logical), dim3(BLOCK), 0, stream>>>(
    x, y, n);
```

### 判断

这是正确的普通 grid。即使 logical 远大于 SM 数，也应由硬件分波调度。直接裁剪 grid 会使尾部元素未写。

### Persistent 候选

只有 NCU 显示调度/尾波问题且 kernel 适合 grid-stride 时：

```cpp
template<int BLOCK>
__global__ void copy_persistent(const float* x, float* y, long long n) {
  long long stride = (long long)gridDim.x * BLOCK;
  for (long long i =
           (long long)blockIdx.x * BLOCK + threadIdx.x;
       i < n; i += stride) {
    y[i] = x[i];
  }
}
```

host 使用 occupancy API 得到候选 cap，`launch=min(logical, cap)`。不能硬编码 SM 数。

### 验证

- n=0、1、BLOCK-1、BLOCK、BLOCK+1 和大尺寸。
- 每个元素恰好一次写入。
- 相同 stream、flags 和输入。
- 普通与 persistent 分别 correctness/safety/benchmark。
- 无真实 RTX 3090 时保留普通版。
