# CUDA C/C++ DynamicFixer

## Responsibility

Repair `xxx_fix.cu` from real `nvcc`, executable, correctness, and Compute Sanitizer evidence. Make one minimal hypothesis-driven change per iteration, rerun the affected gate and then the full gate, and stop after success, an environment block, the same normalized failure twice, or five iterations.

Do not optimize performance here. Do not weaken the test contract.

## Input and output

Input: one `fixed_code_path` ending in `_fix.cu`, already produced by StaticReviewer.

Update only:

- `xxx_fix.cu`, directly and atomically after retaining the previous contents in memory
- the existing `xxx_fix.md`, by appending commands, evidence, edits, and final status

Do not create `_fix_1.cu`, backup sources, committed binaries, or persistent build trees.

## Immutable contract

Freeze these values from the input and report before the first edit:

- host wrapper API and requested custom-kernel requirement
- tensor/buffer dtype, shape, strides, layout, aliasing, and stream semantics
- reference implementation
- test cases, seeds, poison/canary checks, and tolerances
- target `sm_86` and compile mode

Never obtain a pass by changing any frozen item. Never replace the custom kernel with CPU code, a CUDA library, a framework operation, or a precomputed result.

## Resolve execution backend

Search upward from `fixed_code_path` for the nearest `EnvConfig/config.md` and use its `execution_backend` for every iteration.

- `local`: run commands directly in a temporary build directory.
- `worker`: run each command synchronously through `.claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py` under the current `JOB_ID`.
- missing/invalid EnvConfig or unavailable exact RTX 3090: append an environment block and stop without editing source.

Do not switch from local to Worker midway through an iteration. Re-run EnvConfig as a separate operation if the recorded environment becomes invalid.

## Canonical build and test sequence

Use the exact compiler and `validation_flags` recorded in EnvConfig. The canonical sequence is:

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 -Xptxas=-v xxx_fix.cu -o <temporary-binary>
timeout --signal=TERM --kill-after=5s 120s <temporary-binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 <temporary-binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool initcheck --error-exitcode 99 <temporary-binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool racecheck --racecheck-report all --racecheck-detect-level info --error-exitcode 99 <temporary-binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool synccheck --error-exitcode 99 <temporary-binary>
```

Capture the command, backend, exit code, stdout, stderr, duration, and relevant PTXAS resource lines. Treat timeout exit 124 as failure, never as a clean result. Remove the temporary build directory afterward.

Run the stages sequentially and stop at the first failing stage for diagnosis. After a repair passes its targeted stage, run the complete sequence before declaring success.

## Failure taxonomy

Read `.claude/skills/cuda-c-code-review/ref/troubleshooting.md` and the shared CUDA C references. Classify evidence using the earliest failing gate.

| Class | Typical evidence | First checks |
| --- | --- | --- |
| Environment | missing `nvcc`, unsupported host compiler, no device, driver/tool mismatch | EnvConfig and shared runtime probe; do not edit kernel |
| NVCC/C++ | parser, overload, template, header, host-link error | source location, signature, include, language standard |
| PTXAS/resource | registers/shared-memory overflow, unsupported target | block/tile/staging, target feature gate, PTXAS output |
| Launch/API | invalid configuration/value, unchecked async error | grid/block/shared bytes, argument ABI, API return checks |
| Illegal/misaligned access | memcheck OOB, misalignment, hardware exception | index width, bound, vector alignment, lifetime |
| Uninitialized access | initcheck report or poisoned output remains | input initialization, write coverage, conditional store |
| Shared race | racecheck RAW/WAR/WAW hazard | producer/consumer order, shared index, block barrier |
| Synchronization | synccheck divergent/invalid barrier | branch/return around barrier, warp mask, pipeline waits |
| Correctness | finite mismatch, NaN/Inf disagreement, wrong untouched region | mapping, reduction order, dtype, masks, aliasing |
| Timeout/hang | watchdog, nonterminating grid-stride loop, deadlock | stride progress, barrier reachability, launch size |

Normalize a failure by tool, class, first relevant source location, CUDA error name, and key message. Ignore timestamps, temporary paths, addresses, and process identifiers when deciding whether the same failure repeated.

## Repair rules by class

### Compilation and ABI

- Fix the first root compiler error rather than downstream cascades.
- Keep kernel and wrapper argument order/types consistent.
- Add the narrowest required header or qualification.
- Do not remove warnings by disabling diagnostic classes globally.
- Do not change `-arch=sm_86` to compile newer-only features; replace or gate the feature.

### Launch and resources

- Handle empty work before launch.
- Ensure positive grid/block dimensions and at most 1024 threads/block.
- Recompute dynamic shared bytes using checked `size_t` arithmetic.
- For an ordinary kernel, restore full logical grid coverage.
- For a persistent kernel, require a complete grid-stride loop based on actual launched grid dimensions.
- Reduce tile/staging only when it preserves mapping and is the demonstrated resource root cause.

### Memory

- Trace the failing address back to logical indices and supplied strides.
- Widen products before multiplication; avoid fixing overflow after it already occurred.
- Guard every partial vector lane or use a scalar tail with identical semantics.
- Preserve alignment requirements for vector types; do not cast an unaligned pointer to force vectorization.
- Keep allocations alive until all work using them completes.

### Race and synchronization

- Add the smallest synchronization that establishes the required producer/consumer ordering.
- Never use `__syncthreads()` to synchronize blocks.
- Ensure every live thread in the block reaches a block barrier the same number of times.
- Use the correct active mask for warp collectives and verify source lanes exist.
- For async copies, fix commit/wait/order rather than adding unrelated global synchronization.

### Accuracy

- Compare the first wrong logical index, intermediate formula, and mapping against the frozen reference.
- Fix bounds, mapping, initialization, reduction order, accumulation dtype, or special-value behavior at the source.
- Preserve tolerance and test shapes.
- Do not enable fast math or introduce `__expf`/other approximate intrinsics in a correctness repair.

## Iteration protocol

For iteration 1 through 5:

1. Append the failing command and normalized failure signature.
2. State one root-cause hypothesis and the exact minimal edit.
3. Retain the current source bytes in memory.
4. Apply the edit to `xxx_fix.cu`.
5. Rebuild and run the earliest affected gate.
6. If the failure worsens, changes class unexpectedly, or adds a sanitizer finding, restore the retained source and record the rejected attempt.
7. If the targeted gate passes, run the complete sequence.
8. Stop when all gates pass.

Stop without another edit when:

- an environment/tool/infrastructure error is confirmed
- the same normalized failure occurs in two consecutive attempts
- five attempts have completed
- the source contract is ambiguous enough that a repair would be speculative

An edit that does not compile counts as an iteration. Do not hide it from the report.

## Final status

Append one of:

### Passed

Require all of the following:

- exact RTX 3090 / CC 8.6 environment confirmed
- `nvcc` build for `sm_86` passed
- executable and every correctness case passed
- memcheck, initcheck, racecheck, and synccheck passed
- final source still contains and executes the requested custom CUDA kernel

Set:

```text
passed: true
blocked: false
target_verified: true
```

### Failed

Use when a code gate remains failing after the bounded iterations. Preserve the most useful candidate, but do not call it validated:

```text
passed: false
blocked: false
target_verified: true|false
```

### Blocked

Use when the target environment, compiler, Worker, or required sanitizer is unavailable. Do not make speculative source repairs:

```text
passed: false
blocked: true
target_verified: false
```

Always include `final_code_path`, the last failing gate, and enough stdout/stderr to reproduce the result.
