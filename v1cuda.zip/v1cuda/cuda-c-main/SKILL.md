---
name: cuda-c-main
description: 面向 Linux 与 NVIDIA GeForce RTX 3090（CUDA Compute Capability 8.6）的 CUDA C/C++ 算子开发主流程。根据功能描述或现有 .cu 源码，依次完成工具链与设备验证、需求抽取、CUDA kernel 生成、正确性评审和性能优化，最终交付可用 nvcc 独立编译的源码与可追溯报告。用于新建、迁移或优化 CUDA C/C++ 算子。
---

# CUDA C/C++ 算子开发主流程

## 目标与边界

本 Skill 将用户的算子需求或已有 CUDA C/C++ 实现转换为面向 Linux + RTX 3090 / `sm_86` 的可验证实现。流程只接受 CUDA C/C++ 源码与明确的算子需求，不生成依赖 Python JIT 的 kernel。最终代码必须能由 `nvcc` 编译，包含 `__global__` kernel、host 侧 launcher/wrapper、CUDA API 错误处理和可独立运行的测试入口。

执行链固定为：

```mermaid
flowchart TD
    A["cuda-c-main"] --> B["EnvConfig：设备与工具链"]
    B --> C["Extractor：需求与接口"]
    C --> D["cuda-c-code-gen：生成并评审"]
    D --> E["cuda-c-optimize：基准与优化"]
    E --> F["cuda_final.cu + summary.md"]
    B -. 环境不可用 .-> B
    C -. 信息不足 .-> C
    D -. 编译或正确性失败 .-> D
    E -. 候选回退 .-> E
```

仓库源码位于 `v1/`；部署时把 `v1` 下的 Skill 目录复制或映射到 `.claude/skills/`。本文的 `.claude/skills/...` 均表示部署后的运行路径。

## 不可变约束

1. 目标环境固定为 Linux 与 NVIDIA RTX 3090 的 `sm_86`；只有在该环境得到的结果才能标记为目标平台已验证。
2. 默认编译参数固定包含 `-std=c++17 -O3 -lineinfo -arch=sm_86`。可以添加必要的 include、library 或宏，但不得默认添加 `--use_fast_math`。
3. 动态结果必须来自 EnvConfig 选定的 `local` 或 `worker` 后端；不得把 CPU 推演、静态阅读或其它 GPU 的结果描述为 RTX 3090 实测。
4. 每个阶段只消费上游固定产物并写入自己的固定目录。缺少交接文件时必须回到对应阶段，禁止猜测内容后继续。
5. 子流程串行执行。一次只允许一个负责当前阶段的 subagent 或 Skill 工作，必须等待其完成并验证产物后再进入下一阶段。
6. 禁止修改驱动、系统 CUDA、Worker 全局环境或安装/卸载共享依赖。

## 输出目录

若用户未指定 `output_dir`，默认使用当前工作目录下的 `output_cuda_c_main`。启动流程前创建需要的子目录，但不得覆盖用户提供的源文件。

```text
{output_dir}/
├── EnvConfig/
│   ├── config.md
│   └── runtime_info.txt
├── Extractor/
│   ├── requirement.md
│   └── original_code.cu              # 仅已有 CUDA 源码输入时存在
├── KernelGen/
│   ├── step1_base_info.json
│   ├── step2_block_mapping.json
│   ├── step3_axis_fusion.json
│   ├── step4_code_spec.json
│   ├── step5_kernel_code.cu
│   ├── step6_test_code.cu
│   ├── cuda_code_fix.cu
│   └── cuda_report.md
├── Optimizer/
│   ├── cuda_optimized.cu
│   └── cuda_optimized.md
├── cuda_final.cu
└── summary.md
```

## 执行环境选择

所有任务必须先完成 EnvConfig。环境探测顺序固定，先运行设备与工具链采集，再编译执行共享 smoke test：

```bash
python3 .claude/skills/share/cuda-c/runtime/get_device_info.py
python3 .claude/skills/share/cuda-c/runtime/test_env_code.py
```

判定规则：

- 两个命令均返回 `0`，且结果确认设备名为 RTX 3090、Compute Capability 为 8.6、`nvcc` 与 CUDA Runtime 可用：记录 `execution_backend=local`。
- 任一命令失败：本地只允许继续文本分析和源码生成；所有编译、kernel launch、正确性及性能步骤必须改由当前 Job 的 Worker 执行。
- Worker 上也必须先串行运行同一组探测命令。全部成功后记录 `execution_backend=worker`。
- 本地和 Worker 均失败：停止依赖执行结果的流程，保存真实 stdout/stderr，不得宣称编译、正确性或性能已通过。
- 其它 NVIDIA GPU 可以用于显式标记的 portability smoke test，但不能满足本流程的 RTX 3090 验证门禁。

Worker 环境探测命令：

```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
  --task-type custom \
  --workdir <仓库根目录绝对路径> \
  --timeout-sec 600 \
  --command "python3 .claude/skills/share/cuda-c/runtime/get_device_info.py && python3 .claude/skills/share/cuda-c/runtime/test_env_code.py"
```

后续编译或测试使用相同入口：

```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
  --task-type {compile|accuracy|performance|custom} \
  --workdir <绝对路径> \
  --timeout-sec <正整数> \
  --command "<完整命令>"
```

每次调用必须前台同步等待。以脚本退出码和 `task_output_dir` 中的 `stdout.log`、`stderr.log`、`result.json` 为准：`0` 为成功，`1` 为任务失败，`2` 为输入或基础设施错误，`3` 为取消。禁止后台提交或并行提交多个 Worker Task。

## 阶段 1：环境准备与验证

将任务分发给一个 subagent，要求完整遵循：

```text
.claude/skills/cuda-c-main/subagents/EnvConfig.md
```

输入：

- `output_dir`
- 当前工作目录
- 可选的用户指定 CUDA 路径或 Worker 设备标签

必须产出：

- `{output_dir}/EnvConfig/config.md`
- `{output_dir}/EnvConfig/runtime_info.txt`

`config.md` 至少包含：`execution_backend`、GPU 名称、Compute Capability、driver、`nvcc` 版本、CUDA Runtime 版本、host compiler、目标架构、`validation_flags`、`performance_flags`、smoke-test 结论和原始日志位置。

交接门禁：`execution_backend` 只能是 `local`、`worker` 或 `unavailable`。若为 `unavailable`，只能继续生成未验证候选，不得进行动态结论；如果用户要求完成实测，则应报告阻塞。

## 阶段 2：需求抽取

将任务分发给一个 subagent，要求完整遵循：

```text
.claude/skills/cuda-c-main/subagents/Extractor.md
```

输入：

- 用户原始需求或完整 `.cu` 源码
- `{output_dir}`
- `{output_dir}/EnvConfig/config.md`

Extractor 必须识别输入属于自然语言需求还是现有 CUDA C/C++ 实现。现有实现的判定需要结合 `__global__`/`__device__` 函数、CUDA Runtime API 和 `<<<grid, block, shared_bytes, stream>>>` launch，而不能只凭文件扩展名。

必须产出 `{output_dir}/Extractor/requirement.md`。若输入是已有源码，还必须原样保存为 `{output_dir}/Extractor/original_code.cu`。需求文档应覆盖接口、数据类型、shape/stride、数学定义、边界行为、别名/原地约束、精度策略、launch 约束与测试矩阵。

若数学语义、输出 shape、归约轴或别名规则存在会影响实现的歧义，Extractor 必须请求补充信息；不得靠假设进入生成阶段。

## 阶段 3：CUDA C/C++ 代码生成

直接调用 `cuda-c-code-gen` Skill，不得由主流程自行实现其六个子步骤，也不得通过普通 subagent 间接代替 Skill：

```python
Skill(
    skill="cuda-c-code-gen",
    args="{output_dir}/Extractor/requirement.md {output_dir}"
)
```

输入：

- `requirement`：`{output_dir}/Extractor/requirement.md`
- `output_dir`：`{output_dir}`
- 环境配置：由 code-gen 向上查找最近的 `EnvConfig/config.md`

必须产出：

- `{output_dir}/KernelGen/cuda_code_fix.cu`
- `{output_dir}/KernelGen/cuda_report.md`

`cuda_code_fix.cu` 必须是单一、自包含、可独立编译运行的 `.cu` 文件，包括 kernel、host wrapper、CPU reference、测试与 benchmark。code-gen 内部必须调用 `cuda-c-code-review` 对生成候选进行真实编译/运行或明确标记未验证状态。

交接门禁：确认两个产物存在且非空；报告中必须有 `passed`、`blocked`、`target_verified`、`compile_pass`、`accuracy_pass`、`execution_backend`、`atol`、`rtol`、`max_abs_error`、四项 sanitizer 结果和基线耗时字段。缺失则本阶段失败。

- 动态验证模式下，只有 `passed=true`、`blocked=false`、`target_verified=true`、compile/accuracy 通过且四项 sanitizer 全部通过才能进入动态优化。
- 环境或必需工具不可用时，只接受 `passed=false`、`blocked=true`、`target_verified=false`；可继续到 optimize 的 `static_only` 回退分支，但最终交付必须明确未验证。
- `passed=false`、`blocked=false` 或明确的 compile/accuracy/sanitizer 代码失败表示实现失败，必须停止，禁止进入优化。

## 阶段 4：性能优化

直接调用 `cuda-c-optimize` Skill，禁止主流程自行改写优化策略：

```python
Skill(
    skill="cuda-c-optimize",
    args="{output_dir}/KernelGen/cuda_code_fix.cu {output_dir}"
)
```

输入：

- `cuda_code`：`{output_dir}/KernelGen/cuda_code_fix.cu`
- `output_dir`：`{output_dir}`
- `execution_backend`：最近的 `{output_dir}/EnvConfig/config.md`

必须产出：

- `{output_dir}/Optimizer/cuda_optimized.cu`
- `{output_dir}/Optimizer/cuda_optimized.md`

优化阶段必须保留生成阶段代码作为 baseline。每个候选都要重新编译、通过 CPU reference 正确性与 CUDA API 检查，并在同一设备、同一输入和同一计时协议下比较 CUDA Event 结果。候选无提升、回退、失败或无法验证时，应恢复 best-so-far，不得把失败候选传递给下一策略。

交接门禁：两个优化产物存在且非空，报告明确最终代码来自哪个候选；若没有有效改进，`cuda_optimized.cu` 应为输入实现。`static_only` 时必须逐字节回退输入，报告写 `decision=not_measured`、`target_verified=false`、`blocked=true`。

## 阶段 5：最终交付

1. 读取 `{output_dir}/Optimizer/cuda_optimized.cu`，原样写入 `{output_dir}/cuda_final.cu`。
2. 汇总以下输入，写入 `{output_dir}/summary.md`：
   - `EnvConfig/config.md`
   - `Extractor/requirement.md`
   - `KernelGen/cuda_report.md`
   - `Optimizer/cuda_optimized.md`
3. 不得重新测量或推断缺失数据；缺失字段写成 `N/A（原因：...）`。

`summary.md` 至少包含：

- 顶层 `delivery_status: validated | unverified | failed`；只有 Linux / RTX 3090 全门禁通过才能写 `validated`

### 1. 算子与环境

- 算子名、接口和数学语义摘要
- `execution_backend`
- GPU 名称、CC、driver、CUDA Toolkit/Runtime、host compiler
- 编译命令；明确 `--use_fast_math` 是否启用（默认必须为否）

### 2. Code Gen 正确性

- `compile_pass`、`accuracy_pass`
- `atol`、`rtol`、最大绝对/相对误差
- 覆盖的 shape、dtype、非整 block 和特殊值用例
- CUDA API/launch error 与同步检查结果

### 3. 优化前后性能

| 阶段 | kernel 时间 (ms) | 有效带宽 (GB/s) | 相对 baseline |
|---|---:|---:|---:|
| Code Gen baseline | `{baseline_ms}` | `{baseline_gbps}` | `1.000x` |
| Optimize best | `{optimized_ms}` | `{optimized_gbps}` | `{speedup}x` |

性能表必须注明 warmup 次数、测量轮数、统计量、输入规模和是否为 RTX 3090 实测。端到端 host 时间不得冒充 kernel-only CUDA Event 时间。

### 4. 资源与策略

- grid/block/shared-memory 配置
- registers/thread、occupancy 等可获得指标
- 实际尝试、接受和回退的优化策略
- 精度或资源约束

### 5. 产物索引

- `cuda_final.cu`
- `KernelGen/cuda_code_fix.cu`
- `KernelGen/cuda_report.md`
- `Optimizer/cuda_optimized.cu`
- `Optimizer/cuda_optimized.md`

## 默认构建与测试协议

构建命令基线：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  {output_dir}/KernelGen/cuda_code_fix.cu \
  -o {output_dir}/KernelGen/cuda_code_fix
```

不使用 `-use_fast_math` 或 `--use_fast_math`。仅当用户精度契约允许且优化阶段分别验证误差、特殊值与性能后，才允许创建带 fast-math 的候选；必须在报告中显式记录。

运行前后要求：

- 每次 CUDA Runtime 调用检查返回值。
- kernel launch 后立即检查 `cudaGetLastError()`。
- 正确性阶段使用 `cudaDeviceSynchronize()` 暴露异步错误。
- benchmark 使用 CUDA Event，在同一 stream 中记录并同步 stop event。
- 正确性数据与计时数据分离；CPU reference 不进入 kernel 时间。
- 对含共享内存或同步的候选，按需要运行 Compute Sanitizer；对纯逐元素 kernel 至少运行 memcheck。

## 失败与回退

| 场景 | 处理 |
|---|---|
| 本地无目标 GPU 或工具链 | 尝试当前 Job 的 Worker |
| Worker 也不可用 | 保存日志；动态状态标记 `unavailable`，不伪造结论 |
| 需求存在关键歧义 | 请求用户补充，不进入 code-gen |
| 生成文件无法编译 | 交给 code-review 修复并重试；达到迭代上限后保留报告 |
| 正确性失败 | 禁止优化；报告首个失败用例和误差 |
| 优化候选回退 | 丢弃候选，恢复 best-so-far |
| 性能数据噪声过大 | 增加轮数并报告分布；仍不稳定则标记 inconclusive |
| 产物缺失 | 回到产物所有者阶段，不得由主流程伪造 |

## 完成条件

仅在以下条件全部满足时声明完成：

- `cuda_final.cu` 与 `summary.md` 存在且非空。
- 最终 `.cu` 可使用报告中的准确命令构建；若环境不可用，必须显式标记未验证而不是“通过”。
- 所有动态结论能追溯到 local 或 Worker 日志。
- 正确性、性能和资源信息均来自同一最终实现或清楚标明所属候选。
- 输出目录中没有把失败候选误标为最终版本。
- 若当前系统提供 Job/Task 生命周期接口，结束前确认本 Job 没有仍在 queued、leased 或 running 的活动任务。
