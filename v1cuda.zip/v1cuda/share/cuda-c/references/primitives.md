# CUDA C/C++ 原语与 RTX 3090 门禁

本文件不是某个 CUDA Toolkit 版本的完整 API 快照。生成代码时先以安装版本的 NVIDIA 官方文档、头文件、`nvcc` 诊断和真实运行结果为准，再应用这里的 `sm_86` 硬件门禁。不要把 Triton/MLU 原语逐字替换成名称相似的 CUDA API。

## 快速结论

- CUDA kernel 使用 `__global__`，通过 `<<<grid, block, dynamic_shared, stream>>>` 启动；每次 launch 都检查 `cudaGetLastError()`，correctness 阶段再同步。
- 普通 grid 覆盖逻辑工作量；只有 kernel 含等价 grid-stride loop 或任务队列时才可限制为 SM 驻留规模。
- RTX 3090 是 `sm_86`，warp 为 32 threads。每 block 最多 1024 threads，每 SM 最多 48 resident warps、1536 threads 和 16 blocks。
- `__syncthreads()` 只同步 block，`__syncwarp(mask)` 只同步 mask 中的 lanes；两者都不是 grid barrier。
- TMA、WGMMA、thread-block cluster 和原生 FP8 MMA 不属于 `sm_86`。
- `--use_fast_math` 会全局改变数值语义；默认禁用，局部 intrinsic 逐项测试。

## 1. 执行层级和索引

| 层级 | CUDA C/C++ 符号 | 规则 |
| --- | --- | --- |
| thread | `threadIdx.{x,y,z}` | block 内局部编号，类型为 `uint3` 分量 |
| block | `blockIdx.{x,y,z}` | grid 内 block 编号 |
| block shape | `blockDim.{x,y,z}` | 三维乘积不得超过设备限制 |
| grid shape | `gridDim.{x,y,z}` | 各维分别检查设备限制 |
| warp | `warpSize`、lane id | RTX 3090 的 `warpSize == 32`；lane id 通常由线性 thread id `% warpSize` 得到 |

二维 block 的线性 thread id：

```cpp
const unsigned linear_tid =
    threadIdx.x + blockDim.x * (threadIdx.y + blockDim.y * threadIdx.z);
const unsigned lane = linear_tid & 31u;
const unsigned warp = linear_tid >> 5;
```

一维 grid-stride 模式：

```cpp
for (std::size_t i = blockIdx.x * static_cast<std::size_t>(blockDim.x) + threadIdx.x;
     i < n;
     i += static_cast<std::size_t>(blockDim.x) * gridDim.x) {
    output[i] = input[i];
}
```

地址表达式应在乘法前提升到 64-bit。不要让 `blockIdx.x * blockDim.x` 先以 32-bit 溢出。展平或恢复多维索引时，为每个 shape/stride 明确 signedness，禁止对负 stride 使用无符号回绕。

## 2. 主机 Runtime 原语

### 设备与属性

使用 `cudaGet/SetDevice`、`cudaGetDeviceProperties`、`cudaDeviceGetAttribute`、`cudaMemGetInfo`、`cudaDeviceGetPCIBusId` 获取实际设备；用 `cudaFuncGet/SetAttribute` 和 occupancy API 获取 kernel 配置。所有 API 检查 `cudaError_t`，不得从型号表猜运行时属性。动态 shared-memory opt-in 在 launch 前设置并检查返回值。

### 分配、拷贝与释放

| 用途 | 常用 API | 关键条件 |
| --- | --- | --- |
| device/async allocation | `cudaMalloc/Free`、`cudaMalloc/FreeAsync` | 字节数不溢出；async 版本遵守 pool 和 stream 生命周期 |
| host/managed memory | `cudaMallocHost`、`cudaMallocManaged` | pinned memory 有上限；page migration 与 kernel 分开计时 |
| copy/set | `cudaMemcpy*`、`cudaMemset*` | direction、bytes、stream 与 host buffer 生命周期正确 |

`cudaMemcpyAsync` 的返回不代表传输已完成。host buffer 在相关 event/stream 完成前不可销毁或改写。性能测试中要区分 H2D/D2H、kernel time 和端到端 time。

### stream 与 event

使用 `cudaStreamCreate/Destroy`、`cudaEventCreate/Record/ElapsedTime`、`cudaStreamWaitEvent` 和相应同步 API。显式传递 stream，保证 baseline/candidate 同步点一致。Event 计时先 warmup，在同一 stream 记录 start/stop；它不是 CPU 端到端时间。

## 3. 设备内存空间与访问

| 空间 | 声明/来源 | 规则 |
| --- | --- | --- |
| global | kernel pointer、`__device__` | 大容量高延迟；优先 warp 内连续、对齐访问 |
| shared | `__shared__`、`extern __shared__` | block 共享；明确容量、bank conflict 和 barrier |
| local | 自动数组、spill | 通常位于 device memory；不要把语法上的“局部”误认为 register |
| register | 编译器分配 | 无法按源码变量数精确推断；查看 ptxas/NCU |
| constant | `__constant__`、`cudaMemcpyToSymbol` | warp 广播友好；容量和更新时机受限 |

### 对齐与向量访问

`float2`/`float4`、`int2`/`int4` 等向量 load/store 只有在指针和偏移满足自然对齐、有效范围覆盖完整向量且 alias 契约正确时才可用。尾部使用标量或有证明的 guarded path；不要通过越界向量读取后再丢弃 lane。

`__restrict__` 是别名承诺，会帮助优化也会在调用者违反时产生未定义行为。只有接口保证输入/输出不重叠时才添加。对齐提示必须由分配器、偏移和 stride 共同证明。

### shared memory

```cpp
extern __shared__ float tile[];
tile[threadIdx.x] = input[index];
__syncthreads();
// 所有参与线程在 barrier 前后遵守相同控制流。
```

动态字节数由 launcher 的第三个配置参数给出。容量公式包含 padding、双缓冲和数据类型大小，并使用防溢出的 `std::size_t` 计算。shared memory 的收益必须来自复用、合并访问、交换或归约；单纯复制一次 global load 通常无益。

## 4. 同步与内存顺序

| 原语 | 作用域 | 注意事项 |
| --- | --- | --- |
| `__syncthreads()` | block | barrier + block 内可见性；必须由 block 中所有活跃线程一致到达 |
| `__syncthreads_count/and/or` | block | 同步并聚合 predicate；仍受一致到达约束 |
| `__syncwarp(mask)` | 指定 lanes | mask 必须只包含会执行该原语的 lanes |
| `__threadfence_block` | block 可见顺序 | 不等待其他线程到达 |
| `__threadfence` | device 可见顺序 | 不构成跨 block barrier |
| `__threadfence_system` | system 可见顺序 | 成本更高，只在系统级通信契约需要时使用 |

独立 kernel 的 stream 顺序可作为全 grid 阶段边界。需要单 kernel grid synchronization 时，只在设备支持 cooperative launch、grid 满足同时驻留约束并使用 cooperative API 的情况下采用；否则拆成多个 kernel。

## 5. warp 原语

### shuffle

- `__shfl_sync(mask, value, src_lane, width)`
- `__shfl_up_sync`、`__shfl_down_sync`、`__shfl_xor_sync`

常用于 warp reduction、scan、broadcast。`width` 必须是 2 的幂且不超过 warp size。读取未参与或不存在的 source lane 结果没有算法保证；尾 warp 先构造 mask，并给非参与值设置正确幺元。

### vote 与 lane 集合

- `__ballot_sync(mask, predicate)`
- `__all_sync`、`__any_sync`、`__uni_sync`
- `__activemask`
- `__match_any_sync`、`__match_all_sync`

不要在已发生分歧后用 `__activemask()` 反推原始任务成员；成员关系通常在分歧前用 `__ballot_sync(__activemask(), predicate)` 固定。mask 的位必须对应实际会执行后续 collective 的 lanes。

### reduction 原语

CC 8.x 可候选使用 Toolkit 提供的 `__reduce_add_sync`、`__reduce_min_sync`、`__reduce_max_sync` 及按位 reduction。数据类型与 overload 以当前头文件为准；浮点或自定义运算不满足时使用经过验证的 shuffle reduction，不臆造 API。

## 6. 原子操作

常用家族包括 `atomicAdd`、`atomicSub`、`atomicExch`、`atomicMin/Max`、`atomicInc/Dec`、`atomicCAS`、`atomicAnd/Or/Xor`。规则：

1. 先确认数据类型、地址空间和 `sm_86` overload；缺失类型可评估 `atomicCAS` 循环，但必须处理 NaN、ABA 和 bit reinterpret。
2. 原子只保护单次更新。读取其他字段或更新复合状态仍需完整同步协议。
3. 高冲突时优先 warp/block 局部聚合，再减少 global atomics；正确性测试覆盖重复索引和极端冲突。
4. 浮点原子加法次序不确定，结果可能非 bitwise deterministic。阈值必须符合接口，而不是临时放宽。
5. 初始化与归零是 benchmark 的一部分。重复 launch 若累加输出，每轮必须恢复状态，否则 correctness 和 autotune 都无效。

## 7. 算术、类型和转换

### 标量与向量类型

使用固定宽度整数（如 `std::int32_t`、`std::int64_t`）表达接口，使用 `std::size_t` 表达字节数和非负索引。`half`/`__half` 来自 `<cuda_fp16.h>`，`__nv_bfloat16` 来自 `<cuda_bf16.h>`；host/device 可用运算符随 Toolkit 编译选项变化，先编译确认。

### 数学函数

CUDA C++ 中直接调用受支持的 device math，例如 `expf`、`logf`、`sqrtf`、`sinf`、`erff`；不需要导入 Triton wrapper。精确/近似、float/double 和特殊函数选择见 `libdevice.md`。

### 位操作和整数 intrinsic

常见候选包括 `__clz`、`__clzll`、`__popc`、`__popcll`、`__ffs`、`__brev`、`__byte_perm`、`__umulhi`。每个 intrinsic 有固定 width 和 signedness；对 0、负数、移位边界及 64-bit 输入分别验证。优先标准 C++ 或编译器能自然优化的表达式，只有证据表明 intrinsic 必要时才替换。

## 8. 异步拷贝与矩阵能力

- Ampere 支持 global-to-shared 异步 copy 的相应 CUDA pipeline/cooperative-groups 路径，但必须满足 alignment、大小、stage 生命周期和等待语义。先使用 Toolkit 提供的高层 API，避免无必要的 inline PTX。
- `wmma`/Tensor Core 路径要求支持的 fragment shape、layout、dtype 和对齐。RTX 3090 可用 FP16/BF16/TF32/INT8 等 Ampere 路径；累加与输出精度按接口验证。
- TMA、WGMMA、cluster launch、distributed shared memory 和 FP8 Tensor Core 路径在 3090 上禁用。
- inline PTX 仅限 CUDA 分支，必须约束 `__CUDA_ARCH__`、寄存器约束、memory clobber 和等价 fallback；同时验证 PTX 可被目标 Toolkit 汇编为 `sm_86`。

## 9. launch、错误和调试原语

launch 后立即检查 `cudaGetLastError()`，correctness/debug 阶段再检查 `cudaStreamSynchronize`，同时覆盖 launch 与异步错误。`cudaPeekAtLastError` 不清除 last error。设备端 `assert`/`printf` 和 `-G` 只用于调试；性能版本可保留 `-lineinfo`。`__launch_bounds__` 会影响 register 决策，必须验证所有实际 block size、资源、正确性和性能。

## 10. 常用模式

- block reduction：每 thread 先局部累加；warp 内使用正确 mask 的 shuffle；每 warp 一个 lane 写 shared；一致 barrier 后汇总 partial。幺元、NaN 传播和跨 block 的第二阶段/原子必须符合接口。
- tiled transpose：让 warp 沿连续维访问，用必要 padding 减少 bank conflict；load/store 分别做边界判断，barrier 一致到达；以实际 memory workload 验证收益。

## 11. 静态审查清单

1. `__global__` 签名、host wrapper 和 launch 参数一致。
2. grid/block 覆盖所有逻辑元素，各维合法，整数计算不溢出。
3. 所有 global/shared/vector 访问在有效范围且满足对齐。
4. 每个 barrier、warp collective 和原子协议参与集合正确。
5. CUDA Runtime 返回值、launch error 和异步 error 均被检查。
6. allocation、stream、event 在所有成功/失败路径正确释放。
7. 编译目标为 `sm_86`；没有 Hopper/Blackwell-only 能力。
8. 没有 `import triton`、`tl.*`、PyTorch device 管理或 MLU 扩展残留。
9. fast math、TF32、FP16/BF16、atomic 非确定性均符合精度契约。
10. 每项优化都有独立 baseline、真实测试与可执行回退。

## 12. 官方来源

- CUDA C++ Programming Guide：<https://docs.nvidia.com/cuda/cuda-c-programming-guide/>
- CUDA Runtime API：<https://docs.nvidia.com/cuda/cuda-runtime-api/>
- CUDA Math API：<https://docs.nvidia.com/cuda/cuda-math-api/>
- CUDA Binary Utilities：<https://docs.nvidia.com/cuda/cuda-binary-utilities/>
- CUDA Best Practices Guide：<https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/>
- Compute Capability 规格：<https://docs.nvidia.com/cuda/cuda-programming-guide/05-appendices/compute-capabilities.html>
