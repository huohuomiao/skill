---
name: cuda-c-code-gen
description: 从结构化算子需求生成面向 Linux + RTX 3090 / sm_86 的 CUDA C/C++ 实现。串行完成基础信息抽取、blockIdx/threadIdx 映射、线程映射与合并访存分析、kernel/launch/shared/sync 规格、单文件 .cu 生成、CPU reference 与 CUDA Event 测试，并调用 cuda-c-code-review 编译和修复。用于 CUDA kernel 新实现或已有算子的重新生成。
---

# CUDA C/C++ Code Generator

## 目标

将 `requirement.md` 转换为一个可由 Linux `nvcc` 独立构建和运行的 `.cu` 文件。产物面向 NVIDIA GeForce RTX 3090（Compute Capability 8.6），但所有动态结论必须来自 EnvConfig 选定的真实目标环境。

本 Skill 负责生成和验证初始 baseline，不负责穷举性能调优。设计应正确、清晰且具备合理的 CUDA 基线：线程覆盖完整、全局内存访问尽量合并、同步合法、资源使用保守、错误处理完整。

## 输入

调用参数：

| 参数 | 必需 | 含义 |
|---|---:|---|
| `requirement` | 是 | `Extractor/requirement.md` 的绝对或可解析路径 |
| `output_dir` | 是 | 主流程输出目录 |

还必须读取从 `output_dir` 向祖先查找到的最近一个：

```text
EnvConfig/config.md
```

其中 `execution_backend` 决定后续编译/运行使用 local、Worker，还是只能输出未验证候选。

平台公共事实只从以下共享资源读取：

```text
.claude/skills/share/cuda-c/references/platform-rules.md
.claude/skills/share/cuda-c/references/primitives.md
```

## 输出

所有文件写入 `{output_dir}/KernelGen/`：

```text
step1_base_info.json
step2_block_mapping.json
step3_axis_fusion.json
step4_code_spec.json
step5_kernel_code.cu
step6_test_code.cu
cuda_code_fix.cu
cuda_report.md
```

固定交接文件：

- `cuda_code_fix.cu`：经过 `cuda-c-code-review` 处理的完整候选；包含 kernel、host wrapper、CPU reference、测试和 benchmark。
- `cuda_report.md`：编译、正确性和 baseline 性能报告。无法执行时必须把相应字段标为 unavailable。

## 全局生成约束

1. 默认构建参数：`-std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86`。
2. 默认不启用 `--use_fast_math`，也不静默使用改变数值合同的快速 intrinsic。
3. kernel 使用显式 CUDA C/C++：`__global__`、`blockIdx`、`threadIdx`、`blockDim`、`gridDim`。
4. wrapper 接受 `cudaStream_t`，launch 到传入 stream；除非用户 ABI 另有规定。
5. device pointer 生命周期由测试程序管理，业务 wrapper 不隐藏同步和内存分配，除非需求明确要求。
6. 所有 size/index 乘加在 host 与 device 上均避免有符号溢出；大张量优先用 `std::int64_t`/`std::size_t`。
7. tail 元素必须显式 bounds check；禁止只为示例 shape 正确。
8. `__syncthreads()` 必须由 block 内所有非已退出线程一致到达；warp intrinsic 必须使用正确 active mask。
9. 生成单一 self-contained translation unit，不依赖未提供的项目 header 或第三方测试框架。
10. 每个 CUDA Runtime API 都检查错误；launch 后立即 `cudaGetLastError()`，正确性检查前同步。

## 串行工作流

每一步由对应任务文档约束。一次只分发一个 subagent；等待产物生成并验证后再继续。主 Skill 不得越过子步骤自行猜测 JSON。

```mermaid
flowchart LR
    R["requirement.md"] --> S1["1 ExtractBaseInfo"]
    S1 --> S2["2 TraceBlockMapping"]
    S2 --> S3["3 AxisFusion"]
    S3 --> S4["4 GenerateSpec"]
    S4 --> S5["5 GenerateCode"]
    S5 --> S6["6 GenTestCode"]
    S6 --> CR["cuda-c-code-review"]
    CR --> O["cuda_code_fix.cu + cuda_report.md"]
```

### 步骤 1：ExtractBaseInfo

任务文档：

```text
.claude/skills/cuda-c-code-gen/subagents/ExtractBaseInfo.md
```

输入：`requirement.md`

输出：`KernelGen/step1_base_info.json`

抽取接口、tensor/scalar、dtype、shape/stride、数学合同、数值容差、别名、stream、现有 CUDA 结构和测试矩阵。此步骤不得设计 block size 或代码。

交接检查：JSON 可解析；输入输出参数均有 role/C type/dtype；测试列表长度一致；关键歧义为空。

### 步骤 2：TraceBlockMapping

任务文档：

```text
.claude/skills/cuda-c-code-gen/subagents/TraceBlockMapping.md
```

输入：

- `step1_base_info.json`
- `requirement.md`

输出：`KernelGen/step2_block_mapping.json`

设计 logical output 到 `blockIdx.{x,y,z}` / `threadIdx.{x,y,z}` 的覆盖关系，写出 host grid/block 公式、线性索引、反解公式、tail predicate、grid-stride 条件和整数宽度。映射必须可证明无重叠、无遗漏。

交接检查：每个输出元素有唯一负责线程或明确 atomic/reduction 规则；grid 维度不超 CUDA 限制；空输入不会产生非法 launch。

### 步骤 3：AxisFusion

任务文档：

```text
.claude/skills/cuda-c-code-gen/subagents/AxisFusion.md
```

输入：

- `step1_base_info.json`
- `step2_block_mapping.json`

输出：`KernelGen/step3_axis_fusion.json`

分析维度线性化、线程轴选择、连续维合并、全局内存合并访问、广播索引复用和可选向量化。名称保留为 AxisFusion 以维持六阶段结构，但语义是 CUDA 线程映射与访存规划。

交接检查：任何维度合并都给出 stride/contiguity 证明；未知对齐时不能强制使用 `float4` 等宽向量访问；必须提供 scalar tail 路径。

### 步骤 4：GenerateSpec

任务文档：

```text
.claude/skills/cuda-c-code-gen/subagents/GenerateSpec.md
```

输入：步骤 1–3 的 JSON。

输出：`KernelGen/step4_code_spec.json`

生成可直接落地的 kernel/launch/shared-memory/synchronization schema：函数签名、grid/block、索引、加载、计算、存储、barrier、warp primitive、动态 shared memory、错误处理、build flags 和验收用例。

交接检查：schema 禁止含“自行决定”“视情况”等未解析占位；每个 barrier 的参与线程集合明确；每个 load/store 有边界与对齐依据。

### 步骤 5：GenerateCode

任务文档：

```text
.claude/skills/cuda-c-code-gen/subagents/GenerateCode.md
```

输入：`step4_code_spec.json` 和上游 JSON。

输出：`KernelGen/step5_kernel_code.cu`

生成单一 `.cu` translation unit，至少包含：

- 标准/CUDA headers
- `CUDA_CHECK` 或等价错误辅助
- `__global__` kernel 与必要 `__device__` helper
- host launcher/wrapper
- 参数与 launch 合法性检查
- 最小可链接的结构；测试逻辑由下一步补齐

不得生成 CMake 工程、多文件库或 Python 包装器。不得默认 fast math。

### 步骤 6：GenTestCode

任务文档：

```text
.claude/skills/cuda-c-code-gen/subagents/GenTestCode.md
```

输入：`step5_kernel_code.cu`、`step1_base_info.json`、`requirement.md`、EnvConfig。

输出：`KernelGen/step6_test_code.cu`

在 kernel translation unit 内补齐：

- CPU reference
- deterministic test-data generation
- host/device allocation 与 copy
- CUDA API 和 launch 错误检查
- 多 shape/dtype/boundary accuracy tests
- warmup 和 CUDA Event benchmark
- 机器可解析结果行或 JSON 输出
- 失败时非零退出码

GenTestCode 只生成测试文件；真实编译运行由下一步 code-review 统一执行，避免生成与评审阶段各自采用不同协议。

### 步骤 7：调用 code-review

必须直接调用 `cuda-c-code-review`：

```python
Skill(
    skill="cuda-c-code-review",
    args="{output_dir}/KernelGen/step6_test_code.cu"
)
```

code-review 的输入是单一完整 `.cu` 文件。它负责：

- 使用 EnvConfig 指定后端执行 `nvcc` 编译和 binary 运行
- 静态检查 CUDA API、索引、shared memory、barrier、warp mask、stream 和生命周期
- 在需要时修复并重新验证
- 输出 `KernelGen/step6_test_code_fix.cu` 与 `KernelGen/step6_test_code_fix.md`

code-review 返回后，code-gen 必须确认上述两个 basename 产物存在且非空，再执行固定规范化：

1. 将 `step6_test_code_fix.cu` 逐字节复制为 `KernelGen/cuda_code_fix.cu`。
2. 从 `step6_test_code_fix.md` 提取事实，按本 Skill 的固定字段写入 `KernelGen/cuda_report.md`，然后附上完整 review 报告。
3. 原样保留 `passed`、`blocked`、`target_verified`、所有 gate 和原始错误；不得把失败或未运行改为成功。

## 编译协议

默认编译：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  step6_test_code.cu -o step6_test_code
```

根据源码可以附加：

- `-I<path>`：需求明确依赖且路径存在
- `-lcublas`、`-lcudart` 等：源码实际调用相应库
- `-Xcompiler`：仅处理必要 host build 条件

不得为了绕过错误添加：

- `--allow-unsupported-compiler`
- 禁用错误检查的宏
- 默认 `--use_fast_math`
- 改变语义或丢弃边界用例的编译宏

编译命令与 stderr 必须进入报告。

## 正确性协议

### CPU reference

- 与需求数学合同一致，不复制 GPU 索引实现。
- 浮点 reduction 默认用更高精度累加，最终按输出 dtype 比较。
- 整数溢出、NaN/Inf、舍入和原地行为按合同实现。
- CPU reference 时间不进入 kernel benchmark。

### 比较

浮点逐元素判断通常使用：

```text
abs(actual - expected) <= atol + rtol * abs(expected)
```

同时根据合同正确处理：

- expected 与 actual 都为 NaN 是否视为相等
- Inf 符号
- signed zero（若有要求）
- 整数必须精确相等

失败时打印 test id、首个失败逻辑 index、expected、actual、abs/rel error，并返回非零退出码。禁止只打印 warning 后返回成功。

### CUDA 错误

每个 test case：

1. 检查 allocation/copy/event API。
2. 调用 wrapper。
3. launch 后检查 `cudaGetLastError()`。
4. 正确性读取前同步并检查同步返回值。
5. 释放资源，即使中途失败也应有确定清理路径。

## 性能协议

baseline 用 CUDA Event 测量同一 stream 上的 kernel/launcher device work：

1. correctness 先通过。
2. 至少若干 warmup，确保上下文初始化和冷启动不进入样本。
3. start event → 重复 launch → stop event。
4. 同步 stop event。
5. 使用 `cudaEventElapsedTime`，除以重复次数。
6. 报告迭代数、输入规模、统计方法与数据搬运是否包含。

如果 wrapper 包含多 kernel，event 时间覆盖整个 wrapper，并在报告中明确。host allocation、H2D/D2H 和 CPU reference 默认不计入 kernel-only 时间；若用户还需要端到端时间，作为独立指标报告。

## `cuda_report.md` 固定字段

```markdown
# CUDA C/C++ Code Generation Report

## Environment
- execution_backend: local | worker | unavailable
- passed: true | false
- blocked: true | false
- target_verified: true | false
- gpu: ...
- compute_capability: ...
- nvcc: ...
- build_command: ...
- fast_math: false

## Build
- compile_pass: true | false | unavailable
- link_pass: true | false | unavailable
- executable: ...
- compiler_diagnostics: ...

## Accuracy
- accuracy_pass: true | false | unavailable
- atol: ...
- rtol: ...
- max_abs_error: ...
- max_rel_error: ...
- test_cases: ...

## CUDA safety
- api_errors: none | ... | unavailable
- launch_errors: none | ... | unavailable
- sanitizer: passed | failed | not_run（原因）
- memcheck: passed | failed | not_run（原因）
- initcheck: passed | failed | not_run（原因）
- racecheck: passed | failed | not_run（原因）
- synccheck: passed | failed | not_run（原因）

## Baseline performance
- timing_method: CUDA Event
- warmup: ...
- iterations: ...
- baseline_ms: ...
- baseline_gbps: ...
- scope: kernel_only | wrapper_device_work

## Design
- kernel: ...
- grid: ...
- block: ...
- shared_memory_bytes: ...
- mapping: ...

## Artifacts
- generated: KernelGen/step6_test_code.cu
- reviewed: KernelGen/cuda_code_fix.cu
```

不能获得的字段必须保留并写 `unavailable` 或 `N/A（原因）`。

## 回退规则

| 失败阶段 | 允许的回退 |
|---|---|
| Step 1 信息缺失 | 回到 requirement/Extractor，不能猜接口 |
| Step 2 覆盖证明失败 | 重新设计 mapping，不能靠测试 shape 掩盖 |
| Step 3 合并/向量化依据不足 | 使用保守 scalar/原维度映射 |
| Step 4 同步或资源不成立 | 简化 schema，再生成代码 |
| Step 5 结构不完整 | 根据 spec 重生成，不手工跳过约束 |
| Step 6 测试不可构建 | 修复测试 harness，不删除失败用例 |
| code-review 不收敛 | 保留最后候选与真实失败报告，`passed=false` |
| 环境 unavailable | 输出静态候选，所有动态字段标 unavailable |

## 完成检查

- [ ] 八个固定输出文件存在；允许 unavailable 但不允许缺失报告。
- [ ] 四个 JSON 均可解析，字段能相互追踪。
- [ ] `.cu` 包含 kernel、wrapper、CPU reference、测试和 CUDA Event benchmark。
- [ ] 没有默认 fast math。
- [ ] build 命令显式使用 `sm_86` 与 C++17。
- [ ] 编译/正确性失败会返回非零状态。
- [ ] `cuda_code_fix.cu` 和 `cuda_report.md` 已形成主流程交接。
- [ ] 报告没有把其它 GPU 或静态检查描述成 RTX 3090 实测。
