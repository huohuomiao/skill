# CUDA C/C++ StaticReviewer

## Responsibility

Review one self-contained `.cu` file without compiling or running it. Repair only defects that are provable from the source. Preserve the operator, host API, reference, test shapes, tolerances, and custom CUDA-kernel requirement.

Read these resources before deciding platform support:

- `.claude/skills/share/cuda-c/references/platform-rules.md`
- `.claude/skills/share/cuda-c/references/primitives.md`
- `.claude/skills/share/cuda-c/references/libdevice.md` when CUDA math functions or intrinsics appear
- `.claude/skills/cuda-c-code-review/ref/common_error.md`

Shared references are platform gates, not complete snapshots of every installed Toolkit header. Mark an unlisted API `needs compile confirmation`; do not automatically delete it.

## Input and output

Input: one existing `input_code_path` ending in `.cu`.

For `xxx.cu`, write:

- `xxx_fix.cu`: complete repaired source, or a byte-for-byte copy when no definite repair is needed.
- `xxx_fix.md`: append the static-review section to the existing report; create it only when absent.

Do not emit numbered candidates or auxiliary source files.

## Review procedure

### 1. Establish the contract

Extract and record:

- kernel names, signatures, qualifiers, and template parameters
- host wrapper signature and ownership of every allocation
- launch expressions: `grid`, `block`, dynamic shared bytes, and stream
- pointer dtype, logical shape, stride, layout, alignment, alias/in-place behavior
- reference implementation and frozen `atol`/`rtol`
- validation cases and performance cases
- compile flags required by the file

Do not repair an ambiguous contract. Report the ambiguity and leave source unchanged.

### 2. Reject execution-path residues and bypasses

Require at least one `__global__` definition and a real launch. Treat executable references to these as definite residues:

- Triton imports, `@triton.jit`, `tl.*`, or `kernel[grid](...)`
- PyTorch/TensorFlow/JAX execution used in place of the CUDA kernel
- MLU/Cambricon/NRAM/CNRT/CNDrv/BangUtils code
- CPU-only implementation selected for the tested output
- cuBLAS/cuDNN/Thrust/CUB used to replace a custom kernel when the request requires a custom implementation

Headers or CPU code used solely as an independent reference are allowed. Do not remove the reference.

### 3. Check host/device interface

Verify:

- launch argument count, order, type, pointer constness, and template instantiation match the kernel
- byte counts use the element type and cannot overflow before conversion to `size_t`
- `cudaMalloc`, `cudaMemcpy[Async]`, `cudaMemset[Async]`, stream/event creation, and free/destroy calls have checked return values
- host buffers and device buffers have valid lifetimes through asynchronous work
- a kernel launch is followed by `cudaGetLastError()` or `cudaPeekAtLastError()` and a checked completion point before results are read or freed
- the code selects the intended logical CUDA device and does not hardcode a physical index that conflicts with `CUDA_VISIBLE_DEVICES`
- RAII or cleanup paths release resources on every early return

Do not convert an explicitly asynchronous API into global synchronization unless correctness requires it; prefer a checked synchronization on the relevant stream or event.

### 4. Check launch geometry and resources

For every launch:

- prove every `block.{x,y,z}` and total threads/block are positive and within `sm_86` limits
- prove grid dimensions are positive for nonempty work and within runtime limits
- ensure empty work is handled on the host instead of launching grid dimension zero
- ensure ordinary grids cover every logical tile; never cap them to the SM count without a complete grid-stride loop
- verify a persistent/grid-stride loop advances by the actual launched grid size and terminates
- derive dynamic shared bytes from the layout without integer overflow
- reject Hopper/Blackwell-only TMA, WGMMA, thread-block cluster, distributed shared memory, or FP8 Tensor Core assumptions

Treat occupancy as a performance question unless resource use makes the launch illegal. Do not rewrite a correct grid merely to increase estimated occupancy.

### 5. Check indexing and memory access

Trace `blockIdx`, `threadIdx`, loop induction variables, and vector lanes to each load/store:

- use a sufficiently wide integer type for products and byte offsets; cast before multiplication when dimensions can exceed 32-bit products
- verify every global access is guarded for tail blocks and every vector access satisfies both range and alignment requirements
- ensure address arithmetic preserves supplied strides and layouts
- verify input/output aliasing and in-place ordering match the contract
- check shared-memory indices, padding, and declared/dynamic size
- ensure all threads that reach a collective use a valid active mask
- require explicit behavior for zero dimensions, non-multiple sizes, and partial warps

Do not replace a missing bound with a smaller test case.

### 6. Check synchronization and races

Flag and minimally repair definite cases such as:

- `__syncthreads()` reached by only part of a block because of divergent control flow or early return
- a shared-memory producer/consumer phase without the required block or warp synchronization
- a warp shuffle/vote with an incorrect mask or source lane
- cross-block communication without atomics or a separate kernel/cooperative synchronization contract
- non-atomic writes from multiple threads to the same output
- an asynchronous copy consumed before its wait/commit protocol completes

Do not add barriers blindly. A barrier cannot synchronize blocks and can deadlock when placed in divergent block-wide control flow.

### 7. Check arithmetic, dtype, and CUDA math

- Preserve integer exactness and signed/unsigned semantics.
- Accumulate FP16/BF16 reductions in the dtype required by the contract, normally FP32 when accuracy requires it.
- Check `__half`, `__nv_bfloat16`, vector types, atomics, and math functions against `sm_86` and the selected Toolkit.
- Distinguish accurate functions (`expf`, `sinf`, and peers) from fast intrinsics (`__expf`, `__sinf`) and global `--use_fast_math` behavior.
- Never introduce a fast intrinsic without a separately measured candidate and unchanged tolerance.
- Do not mechanically replace integer division or nonconstant floating division with a reciprocal.

### 8. Protect reference and tests

Verify that the test harness:

- initializes all inputs and poisons output where useful
- computes the reference independently of the tested kernel
- compares every logical output element and fails with a nonzero process exit
- checks fixed boundary cases, non-divisible sizes, and random cases with a fixed seed
- keeps tolerance defined before optimization and reports maximum error
- does not use CPU-reference time as a CUDA speedup baseline

If these properties are absent, add the minimal missing check without changing the kernel result expected by the contract.

## Repair policy

Apply a source change only when the defect and semantics of the repair are definite. Common safe repairs include:

- adding missing CUDA error checks without changing scheduling
- widening an index expression before multiplication
- adding a provably correct tail bound
- fixing a mismatched launch argument
- moving a block-wide barrier out of a provably divergent region while preserving phase ordering
- replacing a hardcoded ordinary grid cap with full logical coverage

For uncertain API availability, numerical intent, aliasing, or synchronization semantics, report `needs dynamic confirmation` and leave the source unchanged.

## Report section

Use `.claude/skills/cuda-c-code-review/ref/report_template.md`. Append:

1. input and output paths
2. extracted kernel/launch/interface contract
3. definite defects and source locations
4. uncertain findings requiring compilation or sanitizer evidence
5. exact edits, or `no definite static repair`
6. gates that remain unexecuted

Static review never sets final `passed=true`; only the full dynamic gate can do that.
