# Optimizer

## 职责

本文件是所有 CUDA C/C++ 优化策略的统一包装契约。策略文档说明“可以尝试什么”，本包装器规定“如何安全、公平地尝试、验证、保留或回退”。任何策略都不得绕过本文件自行宣称成功。

## 输入

| 参数 | 说明 |
| --- | --- |
| 策略名称 | 当前策略目录名；目录名仅用于路由 |
| 策略文档路径 | 当前策略的 `strategy.md`，或共享数学优化文档 |
| 工作目录 | 包含只读语义基线 `input.cu` 的目录 |

只允许读取：

1. 当前工作目录的 `input.cu`、已有日志和结果。
2. 当前策略文档及其直接 references。
3. 从工作目录向上找到的最近 `EnvConfig/config.md`。
4. 当前策略明确引用的 `.claude/skills/share/cuda-c/` 文件。
5. 编译器、binary、NCU 或 sanitizer 在当前工作目录生成的真实输出。

只允许写当前工作目录。禁止读取或修改其他策略的工作目录。

## 固定输出

每次执行都必须生成：

| 文件 | 内容 |
| --- | --- |
| `candidate.cu` | 本轮尝试版本；无候选时可不生成 |
| `cuda_optimized.cu` | 通过门禁的候选或逐字回退后的 `input.cu` |
| `cuda_optimized.md` | 完整决策报告 |
| `result.json` | 结构化结果 |
| `compile.stdout.txt` | nvcc stdout |
| `compile.stderr.txt` | nvcc/ptxas stderr |

即使策略失败或环境不可用，也必须输出 `cuda_optimized.cu` 和最小报告；失败不能截断下游链路。

## 执行后端

先读取最近的 `EnvConfig/config.md`：

- `execution_backend=local`：在本地编译和运行。
- `execution_backend=worker`：通过 `.claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py` 前台同步执行。
- 缺失或无法识别：标记基础设施失败，回退源码，不修改 kernel。

Worker 命令必须等待退出，禁止后台或并发提交。退出码、stdout、stderr 和 `result.json` 是唯一执行证据。基础设施错误不得当作 kernel 错误修复。

## 默认编译基线

除非项目已经提供更完整且可复现的命令，统一使用：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  -Xptxas=-v input.cu -o input
```

候选命令只把源文件和输出 binary 改成对应名称，其他 flags 顺序和值保持一致。策略若研究某个编译 flag，必须：

1. 把该 flag 作为唯一实验变量。
2. 在报告中同时记录 baseline/candidate 完整命令。
3. 保留严格语义基线；不能把 `--use_fast_math` 当作默认。
4. correctness 和性能门禁都通过后才能保留。

## 执行步骤

### 步骤 1：冻结输入基线

1. 读取并计算 `input.cu` 哈希，不得覆盖该文件。
2. 确认存在 `__global__` kernel、host launch、correctness 和 benchmark。
3. 从已有 harness 获取用户 shape、dtype、stride、seed、容差、stream、warmup 和 repeat。
4. 编译并保存 ptxas 资源输出。
5. 运行 correctness；失败时停止策略，输出原代码和真实失败。
6. 若目标 RTX 3090 可用，运行基线 benchmark；否则记录 `not_measured`。

不得为了让输入通过而改 reference、测试 shape、容差、错误检查或 benchmark。本策略只优化 kernel/launch 相关实现。

### 步骤 2：建立一个可归因候选

读取策略文档，先记录：

- 匹配位置和前置条件。
- 预期影响：访存、指令、并行度、同步、资源或数学语义。
- 必须保持的接口和结果语义。
- 风险与明确回退条件。

每轮只应用一类变化。候选必须保留：

- kernel 名、host wrapper 对外签名和输出 dtype/shape。
- 原始 reference、输入生成、correctness 阈值和 benchmark 口径。
- 原始错误检查和 stream 语义。
- 所有有效测试用例。

若前置条件不满足，报告 `status=not_applicable`，直接回退输入。

### 步骤 3：编译和静态资源校验

使用相同编译基线生成 candidate binary。检查：

- nvcc 退出码和完整 stderr。
- 目标架构为 `sm_86`。
- ptxas registers、static/shared memory、spill、stack frame。
- block threads、dynamic shared bytes 与共享平台规则一致。
- 没有未检查的 CUDA API 或 launch error。
- 没有为通过编译而删掉测试、同步或错误处理。

编译失败时最多修复三次，且只修复当前候选引入的明确错误。仍失败则回退。

### 步骤 4：正确性与安全性

按原始顺序运行全部 correctness 用例：

- 不改变 seed、输入范围、shape、stride、dtype、容差。
- 检查 kernel launch 后错误和必要同步后的异步错误。
- 记录 max absolute/relative error、NaN/Inf 和首个失败样本。
- 原始流程已配置 Compute Sanitizer 时，候选必须运行相同检查。
- 策略改变同步、shared memory、warp primitive、atomic 或索引时，优先补跑对应的 memcheck/racecheck/synccheck；工具不可用则记录，而非伪造通过。

任何测试失败立即回退。禁止使用 CPU 计算替代 kernel、调用高层 GPU library 取代用户要求的自定义实现、缩小测试或放宽阈值。

### 步骤 5：公平 benchmark

只有真实 RTX 3090 环境且步骤 4 通过时执行：

1. baseline 和 candidate 使用相同 binary 构建 flags、输入、stream 和计时区域。
2. 排除首次 context 创建、module load 和 warmup。
3. 使用 CUDA Event 记录同一 stream 上的 kernel 时间。
4. 交错执行 baseline/candidate，减少 boost、温度与系统漂移。
5. 报告 median、p20、p80 和样本数，不用单次最小值作结论。
6. 若统计区间重叠、收益未超过预设阈值或噪声带，视为无可证明收益。
7. bandwidth 只按明确的实际读写字节计算；不明时写 `N/A`。

其他 GPU 的数据只能标记为非目标诊断，不能用于 RTX 3090 keep 决策。

### 步骤 6：保留或回退

`decision=keep` 必须满足：

- `compile_pass=true`
- `accuracy_pass=true`
- `safety_pass=true`
- `same_flags=true`
- `same_inputs=true`
- `performance_measured=true`
- `no_regression=true`

否则 `decision=revert` 或 `decision=not_measured`，并将 `input.cu` 逐字复制到 `cuda_optimized.cu`。通过候选才复制为 `cuda_optimized.cu`。

深度优化的每轮输入必须是上一轮 best-so-far。由于失败和无收益轮都回退为输入，链尾保持 best-so-far；汇总仍需比较所有明确通过的轮次，防止异常报告覆盖最佳版本。

## result.json 契约

```json
{
  "schema_version": 1,
  "strategy": "name",
  "status": "success|failed|not_applicable|not_measured",
  "decision": "keep|revert|not_measured",
  "execution_backend": "local|worker|unknown",
  "target_gpu": "NVIDIA GeForce RTX 3090",
  "compute_capability": "8.6",
  "compile": {
    "baseline_command": "...",
    "candidate_command": "...",
    "same_flags": true,
    "pass": true
  },
  "correctness": {
    "pass": true,
    "atol": null,
    "rtol": null,
    "max_abs_error": null,
    "max_rel_error": null
  },
  "safety": {
    "pass": true,
    "cuda_error_check": "pass",
    "sanitizer": "pass|failed|not_run"
  },
  "performance": {
    "measured": true,
    "baseline_median_ms": null,
    "candidate_median_ms": null,
    "p20_ms": null,
    "p80_ms": null,
    "speedup": null,
    "no_regression": null
  },
  "resources": {
    "registers_per_thread": null,
    "static_shared_bytes": null,
    "dynamic_shared_bytes": null,
    "spill_bytes": null
  },
  "output_code": "cuda_optimized.cu",
  "reason": "..."
}
```

未知值使用 `null` 并在 `reason` 解释，禁止编造。

## cuda_optimized.md 最小格式

```markdown
---
## 策略：<name>
- status:
- decision:
- execution_backend:
- target_verified:

### 修改
- 匹配位置：
- 单一变量：
- 风险：

### 编译
- baseline:
- candidate:
- same_flags:
- ptxas resources:

### 正确性与安全性
- accuracy_pass:
- atol / rtol:
- max_abs_error / max_rel_error:
- cuda_error_check:
- sanitizer:

### 性能
- measured:
- baseline median/p20/p80:
- candidate median/p20/p80:
- speedup:
- no_regression:

### 输出
- file: <工作目录>/cuda_optimized.cu
- reason:
```

## 禁止事项

- 禁止凭经验值、静态估算、其他 GPU 或单次计时声称 RTX 3090 提速。
- 禁止将 occupancy 最大化视为优化目标；它只是资源和延迟隐藏信号。
- 禁止同时改变算法、tile、编译 flags 和测试后把收益归因给单一策略。
- 禁止隐藏编译失败、精度失败、sanitizer 错误、性能回退或测量噪声。
- 禁止把失败候选传给下一策略。

## 可复现执行目录

策略开始时将绝对路径规范化，并只在工作目录内生成临时产物：

```text
workdir/
├── input.cu
├── baseline.bin
├── baseline.compile.stdout.txt
├── baseline.compile.stderr.txt
├── baseline.correctness.json
├── baseline.benchmark.json
├── candidate.cu
├── candidate.bin
├── candidate.compile.stdout.txt
├── candidate.compile.stderr.txt
├── candidate.correctness.json
├── candidate.benchmark.json
├── result.json
├── cuda_optimized.cu
└── cuda_optimized.md
```

binary 名不得覆盖源码。清理可重建 binary 时不能删除输入、候选、日志、result 或用户文件。Worker 侧产生的 stdout/stderr/result 应回读到同一逻辑目录并记录远端 task id。

## 编译命令规范化

公平性不是字符串完全相同，而是除预先声明变量外的编译语义相同。记录 token 化命令：

```json
{
  "compiler": "/usr/local/cuda/bin/nvcc",
  "common_flags": [
    "-std=c++17", "-O3", "-DNDEBUG", "-lineinfo", "-arch=sm_86",
    "-Xptxas=-v"
  ],
  "include_flags": [],
  "link_flags": [],
  "experiment_flags": [],
  "source": "candidate.cu",
  "output": "candidate.bin"
}
```

检查：

- nvcc 必须是同一绝对路径和版本。
- host compiler 与 ABI flags 相同。
- include/library 搜索顺序相同。
- 宏定义相同，除非宏就是本轮唯一配置变量。
- source 之外的 translation unit、链接库相同。
- 环境变量（如 CUDA cache）有影响时记录。
- 不把 `-G`、不同 `-O` 或 debug/release 混合比较。

项目自带构建系统时可复用其命令，但要捕获实际 nvcc invocation。不能假设 CMake target 名代表 flags 一致。

## Ptxas 资源解析

保存每个目标 entry 的：

```text
registers/thread
static shared bytes
constant memory bytes
stack frame bytes
spill stores bytes
spill loads bytes
```

同一 `.cu` 有多个 kernel 时按 entry name 关联。找不到目标 entry 时将资源标为 null，不把其他 kernel 数值挪用。ptxas warning/error 原文进入报告。

资源判定：

- 超过硬限制或 launch 失败：candidate fail。
- 新增 spill：高风险，结合 NCU 和性能。
- register/shared 降低但耗时无改善：不构成 keep。
- resource 增加但实测更快且仍安全：可以 keep，报告 trade-off。
- 不用静态 occupancy 公式替代 runtime API/NCU。

## 运行隔离

baseline/candidate 使用：

- 同一 CUDA device index 和 UUID。
- 同一进程模型；若分别运行进程，两侧都排除相同初始化。
- 同一 stream 属性和优先级。
- 同一输入 buffer 内容。
- 同一 workspace 策略。
- 同一 warmup/repeat/sample count。
- 同一 event 范围和同步。

随机输入必须固定 seed并保存生成参数。若输入包含随机 NaN/Inf，baseline/candidate 复用同一保存 buffer，不各自重新随机。

## CUDA 错误分类

### 编译错误

- nvcc 语法/template 错误：仅修复候选引入的错误。
- unsupported architecture/toolkit：环境错误，停止。
- ptxas resource overflow：候选失败，通常减 tile/shared/unroll。
- linker undefined reference：先确认构建契约，不能删掉调用绕过。

### Launch 错误

- invalid configuration：检查 grid/block/shared。
- too many resources：读取 ptxas，回退候选。
- invalid device function/no kernel image：架构/工具链错误，不改算法。
- launch timeout：目标 Worker/显示环境问题需区分；保留日志。

### Runtime 错误

- illegal address/misaligned address：candidate safety fail。
- assert：保存断言和输入。
- unspecified launch failure：同步定位首次失败 launch。
- API allocation/copy failure：可能是输入规模/环境，先分类，不能当性能回退。

### 数值失败

- max error 超阈值。
- NaN/Inf mismatch。
- integer/index exact mismatch。
- nondeterministic intermittent mismatch。

所有业务失败都回退；环境失败停止本轮并标记 unknown/not_measured。

## Correctness 防篡改

比较 candidate 前，对 reference/harness 相关区域做 hash 或 diff 审计。允许修改：

- 目标 kernel 实现。
- 对应 launch 配置。
- 本策略必需的 workspace/dispatch。

默认禁止修改：

- reference 算法。
- 输入 shape/dtype/stride/seed。
- atol/rtol。
- pass/fail 条件和进程退出码。
- benchmark warmup/repeat/计时范围。
- 错误检查。

若策略确实需要给 harness 增加 workspace reset 或对齐 fallback，它必须同时应用到公平比较所需位置，且不改变被测语义。报告单列 harness change。

## Safety 测试矩阵

按修改选择最小充分集合：

### 索引/Vector

- n=0（接口允许）、1、vector-1、vector、vector+1。
- 未对齐合法 slice。
- 最大尺寸与 64-bit 地址。
- 非连续 stride。
- alias/in-place。

### Shared/Barrier

- partial block。
- block 边界 shape。
- 所有控制流分支。
- dynamic shared 最小/最大候选。
- memcheck/racecheck/synccheck。

### Warp

- active lanes 1、31、32。
- block 非 32 倍数（若支持）。
- 多 group/warp。
- shuffle mask 与提前 return。

### Atomic

- 重复执行 reset。
- 高 contention。
- 多输出 bucket。
- NaN/Inf/极值。
- determinism contract。

不能因为普通随机大 shape 通过就省略边界安全用例。

## Benchmark 统计

保存原始样本：

```json
{
  "method": "cuda_event",
  "stream": "non_default_0",
  "warmup": 25,
  "repeats_per_sample": 100,
  "sample_count": 50,
  "samples_ms": [],
  "median_ms": null,
  "p20_ms": null,
  "p80_ms": null
}
```

未测时为 null，不填 0。0 ms 会导致虚假无穷加速，应视为计时分辨率/解析错误。speedup 只在两个 median 均为正数且同口径时计算。

### Interleaving

推荐每轮：

```text
warm baseline
warm candidate
measure baseline sample
measure candidate sample
measure candidate sample
measure baseline sample
... alternating order ...
```

顺序可以预先随机化，但不能根据中间结果选择。保持输入相同；cache-sensitive 任务需明确 warm-cache 或 cold-cache 口径，并对两侧一致。

### 异常值

不任意删除慢样本。仅在可证明外部干扰（系统抢占、另一个 GPU 进程、错误）时作废整组并记录。主结论用 median 和分位数，保留样本供审计。

## No-Regression 判定

以下均不满足 no-regression：

- 任一 must-not-regress shape 超过阈值。
- candidate 更快但正确性/安全失败。
- flags、输入或计时范围不同。
- 只在非目标 GPU 更快。
- 性能未测量。
- 收益小于预设噪声/阈值且代码复杂度增加。
- 只比较 kernel 子阶段，遗漏 candidate 新增的初始化/额外 kernel。

只有报告中所有布尔门禁均由证据支撑时 decision=keep。

## Best-so-Far Ledger

每轮附加：

```json
{
  "round": 3,
  "input_hash": "...",
  "candidate_hash": "...",
  "output_hash": "...",
  "decision": "revert",
  "best_before_hash": "...",
  "best_after_hash": "...",
  "reason": "median regression"
}
```

revert 时 input/output/best_after 一致。keep 时 candidate/output/best_after 一致。汇总根据 ledger 和有效 result 重算 winner，不相信文件修改时间或“最后一个目录”。

## Worker 执行

Worker 任务应把 compile、correctness、benchmark 的相关命令封装为可重复脚本或单一前台命令，并返回真实退出码。每次提交显式：

- absolute workdir。
- timeout。
- task type。
- command。
- 当前 Job 上下文。

Worker 基础设施 exit code 不等于 binary exit code。先读取 submit wrapper 的 result，再读取内部 command stdout/stderr。禁止在 Worker 上安装/升级 CUDA、修改驱动、全局路径或共享依赖。

## 结果审计

策略完成前执行：

1. `input.cu` 仍存在且 hash 未变。
2. `candidate.cu` 若存在，其 diff 只属于本策略。
3. compile logs 非空或明确 not_run。
4. result.json 可解析、未知值为 null。
5. report 与 JSON decision 一致。
6. output 源码存在且非空。
7. keep/revert 的源码 hash 符合规则。
8. 未在目标设备时没有非 N/A 性能结论。
