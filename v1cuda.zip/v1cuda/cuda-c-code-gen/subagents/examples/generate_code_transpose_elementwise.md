# Code 示例：转置、bias 与 ReLU 融合

下面是可独立编译的 CUDA C++17 程序。kernel 在 shared tile 的 load 阶段执行 `scale*x+bias` 和 ReLU，然后转置写回，避免中间 global tensor。

```cpp
#include <cuda_runtime.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <random>
#include <vector>

static bool check(cudaError_t s, const char* e, int line) {
    if (s == cudaSuccess) return true;
    std::fprintf(stderr, "CUDA_ERROR line=%d expr=%s name=%s message=%s\n",
                 line, e, cudaGetErrorName(s), cudaGetErrorString(s));
    return false;
}
#define CHECK(expr) check((expr), #expr, __LINE__)

template <int TileDim, int BlockRows>
__global__ void transpose_bias_relu_kernel(
    const float* __restrict__ x, const float* __restrict__ bias,
    float* __restrict__ y, std::int64_t m, std::int64_t n, float scale) {
    __shared__ float tile[TileDim][TileDim + 1];
    const std::int64_t in_col =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.x;
    const std::int64_t in_row =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.y;
    const bool valid_col = in_col < n;
    const float bias_value = valid_col ? bias[in_col] : 0.0f;
    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (valid_col && in_row + j < m) {
            const float v = scale * x[(in_row + j) * n + in_col] + bias_value;
            tile[threadIdx.y + j][threadIdx.x] = v > 0.0f ? v : 0.0f;
        }
    }
    __syncthreads();
    const std::int64_t out_col =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.x;
    const std::int64_t out_row =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.y;
    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (out_col < m && out_row + j < n)
            y[(out_row + j) * m + out_col] = tile[threadIdx.x][threadIdx.y + j];
    }
}

cudaError_t launch_transpose_bias_relu(
    const float* x, const float* bias, float* y,
    std::int64_t m, std::int64_t n, float scale, cudaStream_t stream) {
    if (m < 0 || n < 0) return cudaErrorInvalidValue;
    if (m == 0 || n == 0) return cudaSuccess;
    if (x == nullptr || bias == nullptr || y == nullptr)
        return cudaErrorInvalidDevicePointer;
    constexpr unsigned tile = 32;
    const std::uint64_t gx = (static_cast<std::uint64_t>(n) + tile - 1) / tile;
    const std::uint64_t gy = (static_cast<std::uint64_t>(m) + tile - 1) / tile;
    if (gx > std::numeric_limits<unsigned>::max() || gy > 65535u)
        return cudaErrorInvalidConfiguration;
    transpose_bias_relu_kernel<32, 8>
        <<<dim3(static_cast<unsigned>(gx), static_cast<unsigned>(gy)),
           dim3(32, 8), 0, stream>>>(x, bias, y, m, n, scale);
    return cudaGetLastError();
}

static void reference(const std::vector<float>& x,
                      const std::vector<float>& bias,
                      std::vector<float>* y,
                      std::int64_t m, std::int64_t n, float scale) {
    y->assign(static_cast<std::size_t>(m * n), 0.0f);
    for (std::int64_t row = 0; row < m; ++row) {
        for (std::int64_t col = 0; col < n; ++col) {
            const float v = scale * x[static_cast<std::size_t>(row * n + col)] +
                            bias[static_cast<std::size_t>(col)];
            (*y)[static_cast<std::size_t>(col * m + row)] =
                v > 0.0f ? v : 0.0f;
        }
    }
}

static bool run_case(std::int64_t m, std::int64_t n, float scale, unsigned seed) {
    if (m < 0 || n < 0) return false;
    if (m == 0 || n == 0)
        return launch_transpose_bias_relu(nullptr, nullptr, nullptr,
                                          m, n, scale, 0) == cudaSuccess;
    const std::uint64_t count64 = static_cast<std::uint64_t>(m) * n;
    if (count64 > std::numeric_limits<std::size_t>::max() / sizeof(float)) return false;
    const std::size_t count = static_cast<std::size_t>(count64);
    std::vector<float> x(count), bias(static_cast<std::size_t>(n));
    std::vector<float> expected, actual(count);
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-3.0f, 3.0f);
    for (float& v : x) v = dist(rng);
    for (float& v : bias) v = dist(rng);
    if (!x.empty()) x[0] = std::numeric_limits<float>::quiet_NaN();
    reference(x, bias, &expected, m, n, scale);
    float* dx = nullptr;
    float* db = nullptr;
    float* dy = nullptr;
    cudaStream_t stream = nullptr;
    bool ok = CHECK(cudaStreamCreate(&stream));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dx), count * sizeof(float)));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&db),
                                static_cast<std::size_t>(n) * sizeof(float)));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dy), count * sizeof(float)));
    ok = ok && CHECK(cudaMemcpyAsync(dx, x.data(), count * sizeof(float),
                                     cudaMemcpyHostToDevice, stream));
    ok = ok && CHECK(cudaMemcpyAsync(db, bias.data(),
                                     static_cast<std::size_t>(n) * sizeof(float),
                                     cudaMemcpyHostToDevice, stream));
    ok = ok && CHECK(launch_transpose_bias_relu(dx, db, dy, m, n, scale, stream));
    ok = ok && CHECK(cudaStreamSynchronize(stream));
    ok = ok && CHECK(cudaMemcpy(actual.data(), dy, count * sizeof(float),
                                cudaMemcpyDeviceToHost));
    double max_abs = 0.0;
    std::size_t bad = count;
    if (ok) {
        for (std::size_t i = 0; i < count; ++i) {
            const double diff = std::abs(static_cast<double>(actual[i]) - expected[i]);
            if (!std::isnan(diff)) max_abs = std::max(max_abs, diff);
            if (diff > 1e-6 + 1e-6 * std::abs(static_cast<double>(expected[i]))) {
                bad = i;
                break;
            }
        }
        ok = bad == count;
    }
    if (!ok && bad != count)
        std::fprintf(stderr, "ACCURACY_FAIL output_linear=%zu expected=%g actual=%g\n",
                     bad, expected[bad], actual[bad]);
    if (dx) ok = CHECK(cudaFree(dx)) && ok;
    if (db) ok = CHECK(cudaFree(db)) && ok;
    if (dy) ok = CHECK(cudaFree(dy)) && ok;
    if (stream) ok = CHECK(cudaStreamDestroy(stream)) && ok;
    std::printf("CASE_RESULT m=%lld n=%lld scale=%g passed=%s max_abs_error=%.9g\n",
                static_cast<long long>(m), static_cast<long long>(n), scale,
                ok ? "true" : "false", max_abs);
    return ok;
}

static bool benchmark() {
    constexpr std::int64_t m = 4096, n = 4096;
    constexpr std::size_t matrix_bytes = static_cast<std::size_t>(m * n) * sizeof(float);
    constexpr std::size_t bias_bytes = static_cast<std::size_t>(n) * sizeof(float);
    constexpr int warmup = 20, iterations = 100;
    float *dx = nullptr, *db = nullptr, *dy = nullptr;
    cudaStream_t stream = nullptr;
    cudaEvent_t start = nullptr, stop = nullptr;
    bool ok = CHECK(cudaStreamCreate(&stream));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dx), matrix_bytes));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&db), bias_bytes));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dy), matrix_bytes));
    ok = ok && CHECK(cudaMemsetAsync(dx, 0, matrix_bytes, stream));
    ok = ok && CHECK(cudaMemsetAsync(db, 0, bias_bytes, stream));
    ok = ok && CHECK(cudaEventCreate(&start));
    ok = ok && CHECK(cudaEventCreate(&stop));
    for (int i = 0; ok && i < warmup; ++i)
        ok = CHECK(launch_transpose_bias_relu(dx, db, dy, m, n, 1.25f, stream));
    ok = ok && CHECK(cudaStreamSynchronize(stream));
    ok = ok && CHECK(cudaEventRecord(start, stream));
    for (int i = 0; ok && i < iterations; ++i)
        ok = CHECK(launch_transpose_bias_relu(dx, db, dy, m, n, 1.25f, stream));
    ok = ok && CHECK(cudaEventRecord(stop, stream));
    ok = ok && CHECK(cudaEventSynchronize(stop));
    float elapsed = 0.0f;
    ok = ok && CHECK(cudaEventElapsedTime(&elapsed, start, stop));
    if (ok) {
        const double ms = elapsed / iterations;
        const double logical_gbps = (2.0 * matrix_bytes + bias_bytes) / (ms * 1.0e6);
        std::printf("BENCHMARK_RESULT kernel_ms=%.6f logical_gbps=%.3f warmup=%d iterations=%d\n",
                    ms, logical_gbps, warmup, iterations);
    }
    if (start) ok = CHECK(cudaEventDestroy(start)) && ok;
    if (stop) ok = CHECK(cudaEventDestroy(stop)) && ok;
    if (dx) ok = CHECK(cudaFree(dx)) && ok;
    if (db) ok = CHECK(cudaFree(db)) && ok;
    if (dy) ok = CHECK(cudaFree(dy)) && ok;
    if (stream) ok = CHECK(cudaStreamDestroy(stream)) && ok;
    return ok;
}

int main() {
    cudaDeviceProp prop{};
    if (!CHECK(cudaGetDeviceProperties(&prop, 0))) return 2;
    if (prop.major != 8 || prop.minor != 6) {
        std::fprintf(stderr, "TARGET_MISMATCH name=%s cc=%d.%d expected=8.6\n",
                     prop.name, prop.major, prop.minor);
        return 2;
    }
    const std::int64_t cases[][2] = {{0,9},{1,1},{5,7},{32,32},{33,65},{127,257}};
    const float scales[] = {0.0f, 1.25f, -0.75f, 1.25f, -0.75f, 1.25f};
    for (unsigned i = 0; i < 6; ++i)
        if (!run_case(cases[i][0], cases[i][1], scales[i], 20260813u + i)) return 1;
    if (!benchmark()) return 1;
    std::puts("FINAL_RESULT accuracy_pass=true benchmark_pass=true fast_math=false");
    return 0;
}
```

构建：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 transpose_elementwise.cu -o transpose_elementwise
```

这里 CPU reference 与 device 都用条件表达式定义 NaN→0，避免 `fmaxf` 的 NaN 选择规则产生合同差异。正式评审还应执行 memcheck、racecheck 与 synccheck。
