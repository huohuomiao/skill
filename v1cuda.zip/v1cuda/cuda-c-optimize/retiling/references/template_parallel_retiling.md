# CUDA 并行 Retiling 模板

以下是候选形态，不是固定答案。变量、stride、对齐、边界和 launch 必须从目标代码推导。

## 1. 一线程一元素

```cpp
template<int BLOCK>
__global__ void unary_kernel(const float* x, float* y, long long n) {
  long long i = (long long)blockIdx.x * BLOCK + threadIdx.x;
  if (i < n) y[i] = op(x[i]);
}

dim3 block(BLOCK);
dim3 grid((unsigned)((n + BLOCK - 1) / BLOCK));
unary_kernel<BLOCK><<<grid, block, 0, stream>>>(x, y, n);
```

相邻线程访问相邻元素。BLOCK 只是候选，需外部编译运行搜索。

## 2. 每线程多元素，warp 连续

```cpp
template<int BLOCK, int ITEMS>
__global__ void unary_items(const float* x, float* y, long long n) {
  long long base =
      ((long long)blockIdx.x * ITEMS) * BLOCK + threadIdx.x;
#pragma unroll
  for (int item = 0; item < ITEMS; ++item) {
    long long i = base + (long long)item * BLOCK;
    if (i < n) y[i] = op(x[i]);
  }
}
```

同一 item 下 warp 连续。与“每线程连续 ITEMS”分别测量，不假设谁更快。

## 3. 对齐向量快路径

```cpp
template<int BLOCK>
__global__ void vec4_kernel(
    const float4* __restrict__ x4,
    float4* __restrict__ y4,
    long long vectors) {
  long long i = (long long)blockIdx.x * BLOCK + threadIdx.x;
  if (i < vectors) {
    float4 v = x4[i];
    y4[i] = op4(v);
  }
}
```

host wrapper 必须证明：

```cpp
bool aligned16 =
    (reinterpret_cast<uintptr_t>(x) % alignof(float4) == 0) &&
    (reinterpret_cast<uintptr_t>(y) % alignof(float4) == 0);
```

尾部与未对齐输入走正确标量路径。不要通过未对齐 reinterpret 触发未定义行为。

## 4. 二维映射

```cpp
template<int BX, int BY>
__global__ void elementwise_2d(
    const float* x, float* y, int rows, int cols, long long stride) {
  int col = blockIdx.x * BX + threadIdx.x;
  int row = blockIdx.y * BY + threadIdx.y;
  if (row < rows && col < cols) {
    long long index = (long long)row * stride + col;
    y[index] = op(x[index]);
  }
}
```

让 x 线程映射到 stride-1 的 col。若 stride 非 1 或 layout 不同，必须重新分析地址。

## 5. Shared-memory 转置

```cpp
template<int TILE>
__global__ void transpose(
    const float* x, float* y, int rows, int cols) {
  __shared__ float tile[TILE][TILE + 1];
  int ix = blockIdx.x * TILE + threadIdx.x;
  int iy = blockIdx.y * TILE + threadIdx.y;

  if (ix < cols && iy < rows)
    tile[threadIdx.y][threadIdx.x] = x[(long long)iy * cols + ix];
  __syncthreads();

  int ox = blockIdx.y * TILE + threadIdx.x;
  int oy = blockIdx.x * TILE + threadIdx.y;
  if (ox < rows && oy < cols)
    y[(long long)oy * rows + ox] = tile[threadIdx.x][threadIdx.y];
}
```

`TILE+1` 是典型 padding 候选，仍需确认 shared bank 行为和资源。

## 6. 邻域复用

```cpp
extern __shared__ float smem[];
int local = threadIdx.x + HALO;
long long global = (long long)blockIdx.x * OUTPUTS + threadIdx.x;

if (global < n) smem[local] = x[global];
if (threadIdx.x < HALO) {
  // 分别处理左右 halo，所有全局地址都有边界保护。
}
__syncthreads();
// 只读取已初始化的 shared 范围。
```

边界线程也必须到达 barrier；用 predicate 控制 load，不把 barrier 放入条件块。

## 7. 禁止的模板套用

- 无复用 elementwise 添加 shared staging。
- 未证明对齐就 reinterpret 为 vector。
- 通过减小 grid 漏掉逻辑 tile。
- 修改数据布局却不更新 host 接口。
- 让 thread-divergent 分支包围 `__syncthreads`。
- 为减少整数运算改成 32-bit 地址并引入溢出。
- 同时修改 tiling、math、persistent 和 flags，导致收益无法归因。

每个模板都必须通过原 correctness、安全检查和 RTX 3090 公平 benchmark。
