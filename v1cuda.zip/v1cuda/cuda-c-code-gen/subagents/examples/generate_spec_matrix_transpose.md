# Spec 示例：共享内存矩阵转置
有效字节数按一次读取和一次写入计算，即 `2*M*N*sizeof(float)`。这不等价于硬件 DRAM transaction 数；NCU 分析属于 optimize。初始 tile 配置来自经典 coalesced transpose baseline，但仍需在真实 RTX 3090 与 16×16、32×8 等合法候选比较后才能称为最优。
## 需求

将连续 row-major float32 矩阵 `x[M,N]` 转置为连续输出 `y[N,M]`：

```text
y[n,m] = x[m,n]
```

`x/y` 不允许重叠，M/N 为非负 64 位整数。M 或 N 为 0 时不 launch。目标架构 `sm_86`，使用 32×32 shared tile 和 32×8 线程块；每线程处理最多 4 个 tile 行。

## 映射与同步证明

load 阶段：

```text
input_col = blockIdx.x * 32 + threadIdx.x
input_row = blockIdx.y * 32 + threadIdx.y + j, j in {0,8,16,24}
```

相邻 `threadIdx.x` 读取连续 input。所有线程对每个 j 执行 predicated load，随后全部到达一次 `__syncthreads()`。

store 阶段交换 block 坐标：

```text
output_col = blockIdx.y * 32 + threadIdx.x   # output 的 M 轴
output_row = blockIdx.x * 32 + threadIdx.y + j  # output 的 N 轴
y[output_row * M + output_col] = tile[threadIdx.x][threadIdx.y+j]
```

相邻 lane 写连续 output_col。shared 声明 `float tile[32][33]`，第二维 padding 一列。无线程在 barrier 前 return。

## 实现规格

```json
{
  "schema_version": 1,
  "operator_name": "transpose_2d_f32",
  "translation_unit": {
    "language": "CUDA C++17",
    "headers": ["cuda_runtime.h", "cstdint", "limits"],
    "external_libraries": []
  },
  "build": {
    "flags": ["-std=c++17", "-O3", "-DNDEBUG", "-lineinfo", "-arch=sm_86"],
    "fast_math": false
  },
  "constants": {
    "tile_dim": 32,
    "block_rows": 8,
    "threads_per_block": 256
  },
  "kernels": [
    {
      "name": "transpose_f32_kernel",
      "parameters": [
        {"type": "const float* __restrict__", "name": "x"},
        {"type": "float* __restrict__", "name": "y"},
        {"type": "std::int64_t", "name": "m"},
        {"type": "std::int64_t", "name": "n"}
      ],
      "grid": ["ceil_div(n,32)", "ceil_div(m,32)", 1],
      "block": [32, 8, 1],
      "dynamic_shared_bytes": 0,
      "stream": "stream",
      "shared_memory": [
        {
          "declaration": "__shared__ float tile[32][33]",
          "bytes": 4224,
          "padding": "one float per row"
        }
      ],
      "load_loop": {
        "j_values": [0, 8, 16, 24],
        "predicate": "input_col < n && input_row + j < m",
        "source": "x[(input_row+j)*n + input_col]",
        "destination": "tile[threadIdx.y+j][threadIdx.x]"
      },
      "barriers": [
        {
          "primitive": "__syncthreads()",
          "position": "after all four predicated loads",
          "participants": "all 256 block threads",
          "early_return_before": false
        }
      ],
      "store_loop": {
        "j_values": [0, 8, 16, 24],
        "predicate": "output_col < m && output_row + j < n",
        "source": "tile[threadIdx.x][threadIdx.y+j]",
        "destination": "y[(output_row+j)*m + output_col]"
      },
      "atomics": [],
      "warp_intrinsics": []
    }
  ],
  "wrappers": [
    {
      "name": "launch_transpose_f32",
      "return_type": "cudaError_t",
      "parameters": [
        "const float* x",
        "float* y",
        "int64_t m",
        "int64_t n",
        "cudaStream_t stream"
      ],
      "preconditions": [
        "m >= 0 && n >= 0",
        "m*n fits size_t and int64_t",
        "x/y are non-null and non-overlapping for non-empty input",
        "ceil_div(n,32) and ceil_div(m,32) fit device grid limits"
      ],
      "zero_size": "return cudaSuccess",
      "post_launch": "return cudaGetLastError()",
      "host_synchronization": "none"
    }
  ],
  "tests": {
    "correctness": [
      {"id": "C01", "m": 0, "n": 17, "purpose": "empty"},
      {"id": "C02", "m": 1, "n": 1, "purpose": "minimum"},
      {"id": "C03", "m": 7, "n": 13, "purpose": "small_rectangular"},
      {"id": "C04", "m": 32, "n": 32, "purpose": "exact_tile"},
      {"id": "C05", "m": 33, "n": 65, "purpose": "both_tails"},
      {"id": "C06", "m": 127, "n": 257, "purpose": "rectangular_multi_tile"}
    ],
    "comparison": {"kind": "exact_float_copy", "atol": 0, "rtol": 0},
    "benchmark": {
      "m": 4096,
      "n": 4096,
      "warmup": 20,
      "iterations": 100,
      "method": "CUDA Event",
      "logical_bytes": "2*m*n*sizeof(float)"
    },
    "sanitizer": ["memcheck", "racecheck", "synccheck"]
  },
  "unresolved": [],
  "ready_for_code": true
}
```

## 对应真实 CUDA C++ 核心

```cpp
template <int TileDim, int BlockRows>
__global__ void transpose_f32_kernel(const float* __restrict__ x,
                                     float* __restrict__ y,
                                     std::int64_t m,
                                     std::int64_t n) {
    __shared__ float tile[TileDim][TileDim + 1];
    const std::int64_t input_col =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.x;
    const std::int64_t input_row =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.y;

    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (input_col < n && input_row + j < m) {
            tile[threadIdx.y + j][threadIdx.x] =
                x[(input_row + j) * n + input_col];
        }
    }
    __syncthreads();

    const std::int64_t output_col =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.x;
    const std::int64_t output_row =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.y;
    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (output_col < m && output_row + j < n) {
            y[(output_row + j) * m + output_col] =
                tile[threadIdx.x][threadIdx.y + j];
        }
    }
}
```

## 边界与共享内存安全

- 输入 tile 尾部未写的 shared 元素只可能对应超出真实矩阵的输出；store predicate 会排除这些读取。
- barrier 无条件执行，所以 racecheck/synccheck 有清晰预期。
- `tile[32][33]` 最大索引为 `[31][31]`；padding 列不被显式访问，只改变 stride。
- `m*n*sizeof(float)` 由 host checked multiply 后才用于 allocation/copy。
- in-place transpose 不在合同内，因此签名可以使用 `__restrict__`，测试也必须拒绝/不构造重叠。

## 性能口径

有效字节数按一次读取和一次写入计算，即 `2*M*N*sizeof(float)`。这不等价于硬件 DRAM transaction 数；NCU 分析属于 optimize。初始 tile 配置来自经典 coalesced transpose baseline，但仍需在真实 RTX 3090 与 16×16、32×8 等合法候选比较后才能称为最优。
