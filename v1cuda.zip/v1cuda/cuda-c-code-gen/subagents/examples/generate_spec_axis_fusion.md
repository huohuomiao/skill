# Spec 示例：连续多维逐元素线性化

## 需求

输入 `x[B,M,N]` 和输出 `y[B,M,N]` 均为连续 float32 device memory，接口执行：

```text
y[b,m,n] = max(alpha * x[b,m,n] + beta, 0)
```

允许 `x` 与 `y` 精确原地，但不允许部分重叠。`B/M/N` 均为非负 64 位整数；任一维为 0 时返回成功且不 launch。目标为 RTX 3090 / `sm_86`，默认不启用 fast math。

## 轴融合证明

对连续 row-major layout：

```text
stride_N = 1
stride_M = N
stride_B = M*N
```

所以 `(b,m,n)` 到 `linear=(b*M+m)*N+n` 是 `[0,B*M*N)` 的双射。算子不需要每轴独立语义，alpha/beta 是 uniform scalar，因此三轴可融合成一个一维输出域。host 必须在计算 `B*M*N` 前检查 `uint64_t`/`int64_t` 溢出。

## 实现规格

```json
{
  "schema_version": 1,
  "operator_name": "affine_relu_3d",
  "translation_unit": {
    "language": "CUDA C++17",
    "headers": [
      "cuda_runtime.h",
      "cstdint",
      "limits"
    ],
    "external_libraries": []
  },
  "build": {
    "compiler": "nvcc",
    "flags": [
      "-std=c++17",
      "-O3",
      "-DNDEBUG",
      "-lineinfo",
      "-arch=sm_86"
    ],
    "fast_math": false,
    "command": "nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 step6_test_code.cu -o step6_test_code"
  },
  "kernels": [
    {
      "name": "affine_relu_kernel",
      "parameters": [
        {"type": "const float*", "name": "x"},
        {"type": "float*", "name": "y"},
        {"type": "std::int64_t", "name": "total"},
        {"type": "float", "name": "alpha"},
        {"type": "float", "name": "beta"}
      ],
      "grid": ["ceil_div(total, 256)", 1, 1],
      "block": [256, 1, 1],
      "dynamic_shared_bytes": 0,
      "stream": "stream",
      "indexing": [
        "i = int64_t(blockIdx.x) * blockDim.x + threadIdx.x"
      ],
      "operations": [
        {
          "predicate": "i < total",
          "body": [
            "value = alpha * x[i] + beta",
            "y[i] = value > 0.0f ? value : 0.0f"
          ]
        }
      ],
      "barriers": [],
      "warp_intrinsics": [],
      "atomics": [],
      "shared_memory": []
    }
  ],
  "wrappers": [
    {
      "name": "launch_affine_relu_3d",
      "return_type": "cudaError_t",
      "parameters": [
        "const float* x",
        "float* y",
        "int64_t B",
        "int64_t M",
        "int64_t N",
        "float alpha",
        "float beta",
        "cudaStream_t stream"
      ],
      "preconditions": [
        "B >= 0 && M >= 0 && N >= 0",
        "B*M*N fits int64_t",
        "x and y non-null when total > 0",
        "x/y either disjoint or exactly alias"
      ],
      "zero_size": "return cudaSuccess",
      "launch": "affine_relu_kernel<<<ceil_div(total,256),256,0,stream>>>(x,y,total,alpha,beta)",
      "post_launch": "return cudaGetLastError()",
      "host_synchronization": "none"
    }
  ],
  "tests": {
    "correctness": [
      {"id": "C01", "B": 0, "M": 5, "N": 7, "purpose": "empty"},
      {"id": "C02", "B": 1, "M": 1, "N": 1, "purpose": "minimum"},
      {"id": "C03", "B": 1, "M": 1, "N": 255, "purpose": "below_block"},
      {"id": "C04", "B": 1, "M": 2, "N": 128, "purpose": "exact_block"},
      {"id": "C05", "B": 3, "M": 7, "N": 19, "purpose": "fused_tail"},
      {"id": "C06", "B": 2, "M": 17, "N": 31, "purpose": "in_place"}
    ],
    "values": [
      "seeded uniform values in [-3,3]",
      "values around alpha*x+beta == 0",
      "positive and negative infinity",
      "NaN according to the explicit max contract"
    ],
    "comparison": {
      "atol": 0.000001,
      "rtol": 0.000001
    },
    "benchmark": {
      "shape": [64, 512, 512],
      "warmup": 20,
      "iterations": 100,
      "method": "CUDA Event",
      "bytes_per_element": 8,
      "scope": "kernel_only"
    }
  },
  "unresolved": [],
  "ready_for_code": true
}
```

## 对应 CUDA C++ 核心

该规格必须生成如下真实索引和 launch 语义：

```cpp
__global__ void affine_relu_kernel(const float* x, float* y,
                                   std::int64_t total,
                                   float alpha, float beta) {
    const std::int64_t i =
        static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    if (i < total) {
        const float value = alpha * x[i] + beta;
        y[i] = value > 0.0f ? value : 0.0f;
    }
}

affine_relu_kernel<<<blocks, 256, 0, stream>>>(
    x, y, total, alpha, beta);
return cudaGetLastError();
```

因为接口允许精确原地，kernel 参数不能添加相互矛盾的 `__restrict__`。每个线程在写 y 前只读取同一 index 的 x，精确原地安全。

## Host 溢出与 launch 检查

host 不能直接写 `B*M*N`。依次检查：

```cpp
bool checked_mul_nonnegative(std::int64_t a, std::int64_t b,
                             std::int64_t* result) {
    if (a < 0 || b < 0 || result == nullptr) return false;
    if (a != 0 && b > std::numeric_limits<std::int64_t>::max() / a) {
        return false;
    }
    *result = a * b;
    return true;
}
```

先计算 `BM`，再计算 `total=BM*N`。`total==0` 在指针 null 检查前成功返回。非空时计算 `blocks64=ceil_div(total,256)`，并确保 launch grid 合法；该示例测试范围远小于 grid.x 上限。

## 正确性与性能解释

- CPU reference 使用三重循环，避免复制 GPU 的线性索引实现，从而能发现融合/反解错误。
- threshold 附近用明确值覆盖 ReLU 分支。
- exact in-place 是单独 correctness case。
- benchmark 字节口径是每元素读 4B、写 4B，共 8B；alpha/beta 参数不计入有效流量。
- CUDA Event 只包围 wrapper launch，H2D/D2H 和 CPU reference 在事件范围外。
- 初始 block 256 是合法保守 baseline，不代表对 RTX 3090 已证明最优；优化阶段可以比较 128/256/512。
