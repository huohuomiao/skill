# AxisFusion：CUDA 线程映射与合并访存规划

## 任务

根据逻辑维度、stride 和初始 block mapping，判断哪些轴可安全线性化，如何让 warp lane 对应连续地址，以及是否存在有依据的向量访问或共享内存重排机会。输出 `step3_axis_fusion.json`。

文件名保留 AxisFusion 以保持六阶段结构；这里的“融合”指 CUDA 索引/线程轴与内存访问规划，不是编译器自动融合多个 kernel。

## 输入

- `step1_base_info.json`
- `step2_block_mapping.json`
- `.claude/skills/share/cuda-c/references/platform-rules.md`
- `.claude/skills/share/cuda-c/references/primitives.md`

## 约束

1. 只有 stride 关系被需求证明时才能合并逻辑轴。
2. 合并不能改变 padding、广播、负 stride、切片或 aliasing 语义。
3. `threadIdx.x` 优先承载最连续的输出/主输入轴，使相邻 lane 访问相邻元素。
4. 对齐未知时，初始实现使用 scalar load/store。向量化可以记录为候选，但不能无条件写入 spec。
5. 归约轴与输出并行轴不能机械融合；必须保持 reduction 的聚合与同步语义。
6. 这里不运行性能测试，也不声称某个设计更快。

## 维度合并判定

对 row-major tensor 的相邻轴 `d` 和 `d+1`，可线性化的必要条件通常为：

```text
stride[d] == shape[d+1] * stride[d+1]
```

同时要求：

- 两轴没有独立广播语义。
- 地址计算不会溢出选定 index 类型。
- 所有参与 tensor 的访问都能通过线性 index 正确反解，或各自有明确转换。
- 输出的 iteration order 不涉及必须保留的跨轴同步。

例如连续 `[B,M,N]` 的纯逐元素算子可融合为 `total=B*M*N`：

```cpp
const std::int64_t linear =
    static_cast<std::int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
if (linear < total) {
    y[linear] = f(x[linear]);
}
```

如果还需要每轴坐标，安全反解：

```cpp
std::int64_t t = linear;
const std::int64_t n_idx = t % n;
t /= n;
const std::int64_t m_idx = t % m;
const std::int64_t b_idx = t / m;
```

必须在 host 检查 `B*M*N` 不溢出。

## 不可合并示例

### Broadcast

对 `y[b,m,n] = x[b,m,n] + bias[n]`，输出轴可以整体线性化，但 bias offset 仍为 `linear % N`。这不是把 bias 的广播轴变成连续全张量读取；报告需保留取模成本与复用机会。

### Padded stride

若 `stride_m > N*stride_n`，M/N 之间有 padding，不能把 `offset=m*N+n` 用于实际地址。可以线性化线程域，但 memory offset 必须从坐标和 runtime stride 重建。

### Transpose

`y[n,m]=x[m,n]` 中 input/output 的连续轴不同。简单线性化会让一端访问跨 stride。应记录 shared-memory tile 重排方案，而不是宣称两端都合并访问。

### Reduction

`y[m]=sum_k x[m,k]` 中 M 是输出并行轴，K 是 reduction 轴。可以让一个 block 负责 M、线程遍历 K，但不能把 M/K 当作独立输出元素共同写 y。

## 线程轴选择

按以下优先级：

1. 输出连续写入。
2. 占主要字节流量的输入连续读取。
3. warp lane (`threadIdx.x`) 沿连续轴。
4. `threadIdx.y/z` 用于 tile 的其它轴，确保 block 总线程合法。
5. 避免让同一 warp 的 lanes 跨大 stride，除非算法结构无法避免。

对二维 tile，记录 lane mapping：

```json
{
  "block": [32, 8, 1],
  "lane_mapping": "lane changes threadIdx.x first",
  "x_axis": "contiguous column",
  "y_axis": "row strip",
  "threads_per_block": 256
}
```

不要依赖 C/C++ 对 `dim3` 排列的含糊描述，应明确线性 thread id：

```cpp
unsigned linear_tid =
    threadIdx.x + blockDim.x * (threadIdx.y + blockDim.y * threadIdx.z);
```

## 合并访问分析

为每个访问计算同一 warp 中相邻 lane 的地址差：

```text
delta_bytes = address(lane + 1) - address(lane)
```

理想 scalar 连续访问通常是元素大小。报告字段示例：

```json
{
  "tensor": "x",
  "expression": "base + (row * stride0 + col * stride1)",
  "lane_axis": "col",
  "lane_delta_elements": "stride1",
  "classification": "coalesced_if_stride1_equals_1",
  "requirement_evidence": "stride1 is 1 for all supported layouts"
}
```

广播读取（所有 lane 读同一标量）标记 `uniform/broadcast`；scatter 标记 `irregular`；不要把它们硬归为连续访问。

## 向量访问门禁

使用 `float2/float4`、`int4`、`half2` 或显式 vector load 前必须同时满足：

- base pointer 对齐达到 vector 类型要求。
- offset 对齐由索引公式保证。
- 主体长度可按 vector width 处理。
- 尾部有 scalar 或安全 guarded 路径。
- aliasing/ABI 不违反类型别名和对齐规则。
- 运算语义支持打包类型；例如 `half2` 可能改变中间舍入路径。

如果 requirement 只说普通 device pointer 且没有 alignment 保证，输出：

```json
{
  "enabled": false,
  "reason": "pointer alignment is unspecified",
  "candidate": "runtime-aligned vector body plus scalar tail",
  "defer_to_optimization": true
}
```

初始 baseline 可以加入 runtime alignment branch，但复杂度必须值得且两条路径都测试；否则保持 scalar。

## 广播与索引复用

对于同一 block/warp 复用的值，区分：

- uniform scalar 参数：直接寄存器使用，无需 shared memory。
- 同一 warp 读取同一 global 地址：硬件可广播，但仍记录 cache 行为。
- block 内重复读取的小 tile：可以提议 shared memory，需计算字节数和 barrier。
- 大表或不规则 gather：不能假设 shared memory 自动有益。

索引复用可通过 hoist 公共乘积/基址实现：

```cpp
const std::int64_t row_base = row * stride0;
const std::int64_t offset = row_base + col * stride1;
```

保持 64-bit correctness；只有范围证明安全后才可缩为 32-bit。

## Shared-memory 重排

适用于 transpose、stencil、block reduction 等。记录：

- 静态或动态 shared memory。
- 元素类型、shape、padding 和总字节数。
- 写入与读取索引。
- barrier 的位置和全 block 一致到达证明。
- bank conflict 风险。
- 对 global memory 合并访问的改善来源。

例：transpose tile 方案：

```text
shared float tile[TILE_DIM][TILE_DIM + 1]
load:  x[(block_y*TILE_DIM + y) * in_stride0 + block_x*TILE_DIM + x]
store: y[(block_x*TILE_DIM + y) * out_stride0 + block_y*TILE_DIM + x]
barrier between load and transposed read
```

所有线程即使对应 global tail，也必须通过 predicate 跳过访问但继续到达 barrier，不能在 barrier 前 `return`。

## 输出 Schema

```json
{
  "schema_version": 1,
  "operator_name": "transpose2d",
  "axis_plan": {
    "logical_axes": ["M", "N"],
    "fused_groups": [],
    "preserved_axes": ["M", "N"],
    "thread_x_axis": "N",
    "thread_y_axis": "M",
    "linearization": null,
    "inverse_mapping": null
  },
  "block_plan": {
    "shape": [32, 8, 1],
    "threads": 256,
    "lane_contiguous_axis": "N",
    "items_per_thread": 4
  },
  "access_analysis": [
    {
      "tensor": "x",
      "mode": "read",
      "lane_delta_elements": 1,
      "classification": "coalesced",
      "evidence": "input stride along N is 1"
    },
    {
      "tensor": "y",
      "mode": "write",
      "lane_delta_elements": 1,
      "classification": "coalesced_after_shared_transpose",
      "evidence": "block coordinates are swapped on store"
    }
  ],
  "shared_memory": {
    "enabled": true,
    "declaration": "float tile[32][33]",
    "bytes": 4224,
    "purpose": "transpose while retaining coalesced global accesses",
    "barriers": ["after all predicated loads and before any transposed read"],
    "uniform_reachability": true
  },
  "vectorization": {
    "enabled": false,
    "width": 1,
    "alignment_required_bytes": null,
    "tail_path": "scalar predication",
    "reason": "baseline does not assume pointer alignment"
  },
  "index_reuse": ["precompute input and output row bases"],
  "changes_from_step2": ["preserve 2D tile and add shared-memory transpose"],
  "deferred_candidates": ["vectorized tile loads after runtime alignment gate"],
  "risks": [],
  "ready_for_spec": true
}
```

示例值必须替换为真实算子设计。

## 验证

- 合并轴必须有逐 tensor stride 证明。
- 每个 warp access 分类必须有 lane delta 或等价依据。
- block 总线程满足共享平台限制。
- shared memory 字节数可由声明复算。
- barrier 前没有部分线程提前退出。
- vectorization 未基于未知对齐。
- 线性化/反解使用足够宽的整数类型。
- `changes_from_step2` 不破坏原 coverage proof；若改变 mapping，要同步更新完整证明。
- `risks` 为空且 `ready_for_spec=true` 才能交接。

## 保守回退

无法证明安全时使用：

- 保留原逻辑轴。
- `threadIdx.x` 沿已知 stride-1 轴。
- scalar load/store。
- 对 tail 使用逐元素 predicate。
- 不使用 shared memory，除非算法本身需要跨线程归约/重排。
- 把潜在优化写入 `deferred_candidates`，留给 optimize 实测。
