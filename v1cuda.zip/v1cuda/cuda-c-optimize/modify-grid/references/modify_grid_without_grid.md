## 情况 A：无法提取 Grid

示例：

```cpp
using Launcher = void(*)(const void*, void*, cudaStream_t);
extern Launcher selected_launcher;

void run(const void* x, void* y, cudaStream_t stream) {
  selected_launcher(x, y, stream);
}
```

当前文件没有目标 kernel 的 launch 配置，或者 launch 被外部框架、宏生成器、driver module 封装。

## 处理

1. 搜索目标 `__global__` kernel 的直接 launch、`cudaLaunchKernel` 和 wrapper。
2. 检查调用方是否显式提供 grid/block/shared/stream。
3. 若仍无法唯一恢复，输出：
   - `status=not_applicable`
   - 缺失的 launch 证据
   - 需要用户提供的文件/参数
4. `cuda_optimized.cu` 原样回退为 `input.cu`。

禁止猜测 block=256、grid=ceil(n/block) 或默认 stream。未知 launch 下不能安全修改 grid。
