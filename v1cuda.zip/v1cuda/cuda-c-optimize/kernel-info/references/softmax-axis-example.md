# Softmax 轴分析例子

## 示例框架

```cpp
#include <cuda_runtime.h>
#include <cmath>
#include <cfloat>

__inline__ __device__ float warp_sum(float v, unsigned mask) {
  for (int d = 16; d > 0; d >>= 1)
    v += __shfl_down_sync(mask, v, d);
  return v;
}

__inline__ __device__ float warp_max(float v, unsigned mask) {
  for (int d = 16; d > 0; d >>= 1)
    v = fmaxf(v, __shfl_down_sync(mask, v, d));
  return v;
}

__global__ void softmax_rows(
    const float* __restrict__ x,
    float* __restrict__ y,
    int rows, int cols) {
  extern __shared__ float scratch[];
  int row = blockIdx.x;
  if (row >= rows) return;

  // 真实实现需完成 block-wide max 与 sum；
  // 本例重点展示分析字段，不把不完整片段当成可交付 kernel。
  float local_max = -CUDART_INF_F;
  for (int col = threadIdx.x; col < cols; col += blockDim.x)
    local_max = fmaxf(local_max, x[(long long)row * cols + col]);

  // block_reduce_max(local_max, scratch)
  // expf(x - row_max)
  // block_reduce_sum(local_sum, scratch)
  // y = exp / row_sum
}
```

## 轴信息

| 轴 | extent | 来源 | 类型 |
| --- | --- | --- | --- |
| row | rows | blockIdx.x | grid parallel |
| col | cols | threadIdx.x + k*blockDim.x | thread reduction / output |
| lane | 32 | threadIdx.x & 31 | warp cooperation |
| warp | ceil(block.x/32) | threadIdx.x >> 5 | block cooperation |

一行由一个 block 完成时，max、sum 和输出共享同一 row。若 `cols` 大于 block，线程通过 `col += blockDim.x` 遍历。若改为多 block/row，必须增加中间结果和第二阶段，不能在 blocks 之间使用 `__syncthreads`。

## 三阶段语义

1. `row_max = max(x)`
2. `e_i = exp(x_i - row_max)`，`row_sum = sum(e_i)`
3. `y_i = e_i / row_sum`

分析必须确认：

- max identity 是 `-inf`。
- 累加至少使用符合契约的 FP32。
- exp 选择是精确 `expf` 还是近似 intrinsic，并与容差一致。
- 临时 `e_i` 是重算、register 保存、shared 保存还是额外 global buffer。
- `__syncthreads` 由 block 中所有线程以一致次数到达。
- NaN、全 `-inf` 行和空列语义由需求规定。

## Shared memory

若用 warp partial：

```text
shared bytes = max_warps_per_block * sizeof(float)
```

若缓存整行：

```text
shared bytes = padded_cols * sizeof(float)
```

缓存整行可能快速耗尽 shared memory并降低 residency；必须用 ptxas/NCU 的实际值，不由源码变量数量猜测。

## 结构化输出

```json
{
  "kernel_name": "softmax_rows",
  "axes": [
    {"name": "row", "extent": "rows", "source": "blockIdx.x"},
    {"name": "col", "extent": "cols", "source": "threadIdx.x+k*blockDim.x"}
  ],
  "memory": {
    "input_index": "row*cols+col",
    "output_index": "row*cols+col",
    "coalesced_dimension": "col"
  },
  "reduction": {
    "present": true,
    "passes": [
      {"operator": "max", "identity": "-inf"},
      {"operator": "sum", "identity": "0"}
    ],
    "axis": "col",
    "scope": "block"
  },
  "math": {
    "functions": ["expf"],
    "fast_math": false
  },
  "resources": {
    "dynamic_shared_bytes_expr": "implementation dependent",
    "registers_per_thread": null
  }
}
```

## 候选

- block size：通常从 128/256/512 的小集合开始，真实编译运行筛选。
- 每线程多元素与向量读取：仅在对齐、尾部和 stride 得到证明时。
- exp intrinsic：只有需求允许近似且 adversarial correctness 通过时。
- shared 缓存与重算：比较 register/shared/DRAM 代价。
- persistent 行调度：必须 grid-stride 覆盖所有 rows，并由 NCU 与 benchmark 证明。

所有性能结论必须来自相同 RTX 3090、flags、输入、stream、warmup 和 repeat。
