# GenTestCode

## 任务

以 `step5_kernel_code.cu` 为唯一 kernel 源，在同一 translation unit 中补齐 CPU reference、确定性数据生成、CUDA 资源管理、正确性测试、错误检查和 CUDA Event benchmark，写出 `step6_test_code.cu`。本阶段只生成，不执行；统一由 `cuda-c-code-review` 编译运行。

## 输入

- `step5_kernel_code.cu`
- `step4_code_spec.json`
- `step1_base_info.json`
- `requirement.md`
- 最近的 `EnvConfig/config.md`

## 输出要求

`step6_test_code.cu` 必须是自包含可执行文件：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  step6_test_code.cu -o step6_test_code
./step6_test_code
```

默认不得添加 `--use_fast_math`。运行成功返回 `0`；编译后的程序发现任何 API、launch、同步或 accuracy 失败时返回非零。禁止只打印 warning 后返回成功。

## 文件合成规则

1. 读取完整 `step5_kernel_code.cu`。
2. 保留 kernel 和 wrapper 原文，除非为测试增加确实缺少的标准 header。
3. 在 `// === CUDA_C_TEST_HARNESS_BEGIN ===` 后写入测试；若标记缺失，报告 GenerateCode 失败，不盲目拼接。
4. 不复制第二份 kernel/wrapper。
5. 不引入测试框架、语言运行时或并行库等未在 spec 声明的依赖；CPU reference 使用标准 C++。

## 测试程序结构

```cpp
// 已生成的 include/helper/kernel/wrapper

// === CUDA_C_TEST_HARNESS_BEGIN ===
// RAII device/event helpers
// deterministic input generator
// independent CPU reference
// comparison and diagnostic helpers
// one run_case(...) per common dtype/signature
// benchmark_case(...)
// main(): device gate -> correctness -> benchmark -> summary
```

## CUDA API 错误处理

测试辅助可返回 `bool`：

```cpp
inline bool check_cuda(cudaError_t status, const char* expr,
                       const char* file, int line) {
    if (status == cudaSuccess) return true;
    std::fprintf(stderr, "CUDA_ERROR file=%s line=%d expr=%s name=%s message=%s\n",
                 file, line, expr, cudaGetErrorName(status),
                 cudaGetErrorString(status));
    return false;
}

#define TEST_CUDA(expr) \
    do { \
        if (!check_cuda((expr), #expr, __FILE__, __LINE__)) return false; \
    } while (0)
```

不要在析构函数里抛异常。清理 API 出错可记录 stderr 并影响最终状态；避免宏在错误返回类型的函数中使用。

每个 case 检查：

- `cudaMalloc` / `cudaMallocAsync`（若使用）
- H2D/D2H copy
- stream/event create/record/synchronize/destroy
- wrapper 返回值
- wrapper 内 `cudaGetLastError()`
- correctness 阶段 `cudaStreamSynchronize` 或 `cudaDeviceSynchronize`
- `cudaFree`

如果使用非默认 stream，所有 async copy、launch 和 event 必须使用同一 stream，或明确 event dependency。

## 资源管理

优先使用小型 RAII 类型，确保早退也释放资源：

```cpp
template <typename T>
class DeviceBuffer {
public:
    DeviceBuffer() = default;
    explicit DeviceBuffer(std::size_t count) { allocate(count); }
    ~DeviceBuffer() {
        if (ptr_ != nullptr) cudaFree(ptr_);
    }
    DeviceBuffer(const DeviceBuffer&) = delete;
    DeviceBuffer& operator=(const DeviceBuffer&) = delete;

    cudaError_t allocate(std::size_t count) {
        if (count == 0) return cudaSuccess;
        return cudaMalloc(reinterpret_cast<void**>(&ptr_), count * sizeof(T));
    }
    T* get() { return ptr_; }
    const T* get() const { return ptr_; }

private:
    T* ptr_ = nullptr;
};
```

需要防止 `count*sizeof(T)` 在 host 溢出。零长度 case 不应调用无意义指针访问。

## CPU reference

reference 必须独立表达数学合同，不复用 GPU 的 thread/tile/index helper。示例：

```cpp
void reference_affine_relu(const std::vector<float>& x,
                           std::vector<float>* y,
                           float a, float b) {
    y->resize(x.size());
    for (std::size_t i = 0; i < x.size(); ++i) {
        const float value = a * x[i] + b;
        (*y)[i] = value > 0.0f ? value : 0.0f;
    }
}
```

归约建议用 double 或明确的高精度 accumulator：

```cpp
double sum = 0.0;
for (std::int64_t k = 0; k < K; ++k) {
    sum += static_cast<double>(x[row * K + k]);
}
expected[row] = static_cast<float>(sum);
```

若合同要求与 GPU 固定顺序完全一致，则 reference 使用该定义并明确说明；不能同时宣称顺序无关。

## 输入生成

- 固定 seed，例如 `20260813`。
- 避免所有值相同、全零或恰好掩盖索引错误。
- 混合正负值、非整数、小量级和大但合法值。
- 特殊值用例单独构造，避免随机分布偶然不覆盖。
- index 输入必须覆盖首尾、重复（若合法）、非排序和边界。
- performance 输入在 benchmark 外提前初始化并拷贝。

标准库生成：

```cpp
std::mt19937 rng(seed);
std::uniform_real_distribution<float> dist(-3.0f, 3.0f);
```

## 测试矩阵

严格实现 `step1_base_info.json` 的 correctness cases，至少包含：

- 最小合法值。
- 小于 block。
- 恰好整 block。
- 非整 block/tile 的 tail。
- 大小合理的代表 shape。
- 支持的 layout/stride。
- 数值特殊值与 dtype 边界。
- `N=0` 或空 reduction（仅接口允许时）。

如果有多个 dtype，可用 template 或分别实现；不能只测试 float32 就宣称 half/int 支持通过。

## 比较器

浮点比较：

```cpp
bool nearly_equal(float actual, float expected, double atol, double rtol) {
    if (std::isnan(expected)) return std::isnan(actual);
    if (std::isinf(expected)) return actual == expected;
    const double diff = std::abs(static_cast<double>(actual) - expected);
    return diff <= atol + rtol * std::abs(static_cast<double>(expected));
}
```

同时统计：

- `max_abs_error`
- `max_rel_error`（expected 非零时）
- mismatch count
- 首个 mismatch 的逻辑坐标、expected、actual、abs/rel error

整数和 bitwise 合同使用精确比较。NaN/Inf/signed zero 按 requirement，不机械使用上面模板。

失败输出示例：

```text
ACCURACY_FAIL case=C04 index=[7,31] expected=1.25 actual=1.5 abs=0.25 rel=0.2
```

随后 case 返回 false，`main` 返回 `1`。

## 正确性 case 流程

每个 case 推荐：

1. 验证 host shape/bytes 乘积不会溢出。
2. 生成 host inputs 和 CPU expected。
3. 分配 device buffers。
4. H2D copy。
5. 调用 wrapper。
6. 检查 wrapper/launch 返回值。
7. 同步 stream，捕获异步执行错误。
8. D2H copy。
9. 比较并打印一行结构化结果。
10. 清理。

输出：

```text
CASE_RESULT id=C02 passed=true max_abs_error=0 max_rel_error=0
```

所有 correctness cases 成功后才能进入 benchmark。

## Device gate

测试程序自身再次验证正在运行的 GPU，避免 Worker 调度错误：

```cpp
cudaDeviceProp prop{};
TEST_CUDA(cudaGetDeviceProperties(&prop, 0));
if (std::string(prop.name).find("RTX 3090") == std::string::npos ||
    prop.major != 8 || prop.minor != 6) {
    std::fprintf(stderr,
                 "TARGET_MISMATCH name=%s cc=%d.%d expected=RTX_3090_cc_8.6\n",
                 prop.name, prop.major, prop.minor);
    return false;
}
```

如果共享环境脚本允许显式 portability 模式，测试 harness 可以通过明确 CLI flag 放宽 exact name，但默认严格模式必须拒绝其它 GPU，并在输出中标记非目标验证。

## CUDA Event benchmark

### 正确范围

事件和 kernel 在同一 stream：

```cpp
TEST_CUDA(cudaEventRecord(start, stream));
for (int i = 0; i < iterations; ++i) {
    TEST_CUDA(launch_op(..., stream));
}
TEST_CUDA(cudaEventRecord(stop, stream));
TEST_CUDA(cudaEventSynchronize(stop));
float total_ms = 0.0f;
TEST_CUDA(cudaEventElapsedTime(&total_ms, start, stop));
const double kernel_ms = total_ms / iterations;
```

先 warmup 并同步：

```cpp
for (int i = 0; i < warmup; ++i) {
    TEST_CUDA(launch_op(..., stream));
}
TEST_CUDA(cudaStreamSynchronize(stream));
```

不在计时循环中分配、初始化、拷贝或打印。每次 wrapper launch 都检查返回值；不要只检查循环最后一次。

### 带宽

只有能定义有效流量时报告：

```text
effective_GBps = bytes_per_iteration / (kernel_ms * 1e-3) / 1e9
```

例如逐元素 `y=x+x` 的最低逻辑流量可能是读一个输入 + 写一个输出；如果输入被读取两次但缓存复用，报告应说明采用的逻辑字节定义。不要把理论 DRAM transaction 伪装成已测流量。

### 输出

```text
BENCHMARK_RESULT case=P01 warmup=20 iterations=100 kernel_ms=0.1234 effective_gbps=456.7 scope=wrapper_device_work
```

若 event API 或 launch 失败，返回非零且不输出成功 benchmark 行。

## `main` 流程

```cpp
int main(int argc, char** argv) {
    // parse only documented optional flags
    // print device/build metadata
    // strict target gate
    // run every correctness case; fail immediately or aggregate failures
    // only after all accuracy passes, run benchmark
    // print final machine-readable summary
    return all_passed ? 0 : 1;
}
```

最终成功行：

```text
FINAL_RESULT compile_pass=true accuracy_pass=true benchmark_pass=true
```

`compile_pass` 在程序内部只能代表“本 binary 已构建并启动”的事实；完整编译命令由 code-review 报告记录。

## Sanitizer 准备

测试 binary 应能被 Compute Sanitizer 直接运行，不依赖交互输入。可接受 CLI 用于选择测试 case，例如：

```bash
./step6_test_code --correctness-only
./step6_test_code --benchmark-only
```

但 `--benchmark-only` 不应用于正式正确性结论。默认无参数应运行 correctness 后 benchmark。

涉及不同错误类别时，code-review 可运行：

```bash
compute-sanitizer --tool memcheck ./step6_test_code --correctness-only
compute-sanitizer --tool racecheck ./step6_test_code --correctness-only
compute-sanitizer --tool synccheck ./step6_test_code --correctness-only
compute-sanitizer --tool initcheck ./step6_test_code --correctness-only
```

本阶段只保证 CLI 可执行，不伪造 sanitizer 结果。

## 报告友好的元数据

程序启动时打印：

```text
DEVICE_INFO name=<...> cc=<major.minor> memory_bytes=<...>
BUILD_INFO arch=sm_86 cxx_standard=17 fast_math=false
TEST_CONFIG seed=<...> correctness_cases=<...> warmup=<...> iterations=<...>
```

如果编译时无法可靠知道是否启用 fast math，可由构建命令作为 source of truth；code-review 报告使用命令，不只依赖程序常量。

## 禁止做法

- 用 GPU 输出自身作为 expected。
- 只测试一个整 block shape。
- kernel 后不检查 launch/sync error。
- 用 host wall-clock 计时却标为 CUDA Event。
- 把 H2D/D2H 混入 kernel-only 指标。
- accuracy 失败后仍返回 0。
- 捕获异常/错误后只打印 warning。
- benchmark 先于 correctness。
- 用其它 GPU 成功冒充 RTX 3090 验证。
- 默认启用 fast math。

## 完成自检

- [ ] 输出包含且只包含一套 kernel/wrapper。
- [ ] CPU reference 与 GPU mapping 独立。
- [ ] 所有 requirement correctness cases 已实现。
- [ ] 有小值、tail、边界和 performance case。
- [ ] CUDA API、launch、同步均检查。
- [ ] device gate 默认要求 RTX 3090 / CC 8.6。
- [ ] benchmark 使用同 stream CUDA Event。
- [ ] correctness 失败必然产生非零退出码。
- [ ] 默认 flags 未含 fast math。
- [ ] 文件不依赖 Python/JIT/第三方测试框架。
- [ ] 可直接交给 `cuda-c-code-review`。

## 失败处理

- CPU reference 语义不明确：返回 Extractor，不能复制 GPU 行为。
- 测试矩阵缺失 dtype/layout：返回 ExtractBaseInfo。
- wrapper 不可测试或缺 host launch：返回 GenerateCode。
- 环境 unavailable：仍生成完整测试源码；不要执行，也不要写成功结论。
- 某特殊值无法构造：说明具体类型/API限制并回到 requirement，不静默删 case。
