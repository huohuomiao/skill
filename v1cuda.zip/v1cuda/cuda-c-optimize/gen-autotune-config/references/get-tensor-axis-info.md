# CUDA 外部配置搜索的 Tensor 轴信息提取

本参考用于 `config-tuner` 和 `gen-autotune-config`。目标是从 `.cu` 源码、launch 和实际测试规格中恢复“数据轴—线程轴—地址—配置参数”关系，而不是按变量名猜 block/tile。

## 返回格式

```json
{
  "kernel_name": "target_kernel",
  "test_cases": [
    {
      "shape": {"B": 32, "M": 1024, "N": 2048},
      "dtype": "float",
      "strides": {"x": ["M*N", "N", "1"]},
      "alignment_bytes": {"x": 256},
      "weight": 1.0
    }
  ],
  "launch": {
    "grid": ["ceil_div(N, BX)", "ceil_div(M, BY)", "B"],
    "block": ["BX", "BY", "1"],
    "dynamic_shared_bytes": "shared_expr",
    "stream": "stream"
  },
  "tunable": {
    "BX": {"kind": "block_x", "current": 32},
    "BY": {"kind": "block_y", "current": 8},
    "ITEMS": {"kind": "items_per_thread", "current": 1},
    "VEC": {"kind": "vector_width", "current": 1},
    "UNROLL": {"kind": "unroll", "current": 1}
  },
  "axes": [
    {
      "name": "N",
      "extent": "N",
      "stride": 1,
      "mapping": "blockIdx.x*BX+threadIdx.x",
      "role": "parallel_contiguous"
    },
    {
      "name": "M",
      "extent": "M",
      "stride": "N",
      "mapping": "blockIdx.y*BY+threadIdx.y",
      "role": "parallel"
    }
  ],
  "memory": {
    "transactions": [],
    "reuse": [],
    "vectorization": {
      "eligible": false,
      "proof": []
    }
  },
  "reduction": null,
  "resources": {
    "registers_per_thread": null,
    "static_shared_bytes": null,
    "dynamic_shared_bytes": null,
    "spill_bytes": null,
    "source": "static_only"
  }
}
```

无法证明的字段为 null。

## Step 1：展开 Launch

追踪 host 变量直到 `dim3`：

```cpp
constexpr int BX = 32;
constexpr int BY = 8;
dim3 block(BX, BY);
dim3 grid((N + BX - 1) / BX, (M + BY - 1) / BY, B);
kernel<<<grid, block, shared_bytes, stream>>>(x, y, B, M, N);
```

记录：

- grid/block 三维表达式。
- dynamic shared 表达式。
- stream。
- 模板参数、宏和 runtime 参数。
- 每 block 总线程数。
- 不同 shape 是否走不同 launch 分支。

如果 kernel 通过 `cudaLaunchKernel` 调用，按 `dim3 gridDim`、`dim3 blockDim` 和参数数组恢复同样信息。

## Step 2：展开数据索引

示例：

```cpp
int n = blockIdx.x * blockDim.x + threadIdx.x;
int m = blockIdx.y * blockDim.y + threadIdx.y;
long long offset = ((long long)b * M + m) * N + n;
```

展开为：

```text
offset = b*(M*N) + m*N + n
```

轴表：

| 轴 | extent | stride | 并行来源 | role |
| --- | --- | --- | --- | --- |
| B | B | M*N | blockIdx.z | grid parallel |
| M | M | N | blockIdx.y/threadIdx.y | parallel |
| N | N | 1 | blockIdx.x/threadIdx.x | parallel contiguous |

连续性由实际 stride 确定，不由 N 是最后一个逻辑轴自动确定。

## Step 3：识别每线程工作量

模式：

```cpp
for (int item = 0; item < ITEMS; ++item) {
  long long n = base + (long long)item * blockDim.x;
  if (n < N) { ... }
}
```

记录：

- ITEMS 是否模板常量。
- 相邻线程在同一 item 的地址差。
- 每线程 load/store 数。
- loop 是否 unroll。
- register live values 随 ITEMS 的可能增长。

不要把循环次数直接当作 vector width；标量多元素和单条 vector memory operation 是不同候选。

## Step 4：Vector 对齐证据

vectorization 只有在证据链完整时为 eligible：

1. allocation 对齐。
2. pointer slice offset 对齐。
3. axis stride 为 1。
4. vector 不跨逻辑行/对象边界。
5. 尾部 fallback。
6. alias/restrict 语义合法。
7. vector type 的大小与元素 dtype 匹配。

记录证据来源，例如 runtime alignment assert、API contract、base allocation 或静态 offset。没有证据时 false。

## Step 5：Shared memory

提取：

- `__shared__ T tile[...]`
- `extern __shared__ T smem[]`
- 数组维度、padding 和索引。
- producer/consumer thread 映射。
- barrier 次数和控制流。
- host dynamic shared bytes。

计算静态表达式只作为初筛。实际字节和 register/spill 从相同 flags 的 ptxas/NCU 读取。

## Step 6：归约

示例：

```cpp
float acc = 0.0f;
for (int k = threadIdx.x; k < K; k += blockDim.x)
  acc += x[row * K + k];
```

记录：

- K 是 reduce axis。
- block.x 影响并行 partial 数。
- 每线程迭代数约为 ceil(K/block.x)。
- 后续是 warp shuffle、shared tree、atomic 或第二 kernel。
- block 改变时 shared size、active mask、atomic count 是否变化。
- 浮点次序和确定性风险。

## Step 7：实际测试分布

从 harness 获取所有测试 case，而不是选择第一个：

```text
shape, dtype, stride, alignment, seed, stream, weight
```

若用户提供多 shape，配置搜索目标必须预先定义：

- 单 shape 最优。
- 加权几何/算术目标。
- worst-case guardrail。
- shape dispatch。

不得测完后临时更换评分口径。

## Step 8：候选边界

候选必须从共享平台规则和当前资源产生。常见维度：

- block.x/y/z
- tile M/N/K
- items/thread
- vector width
- unroll
- shared staging / padding
- dynamic shared bytes
- grid-stride cap

生成前过滤：

- threads/block 超限。
- grid 维超限。
- shared bytes 明显超限。
- vector alignment 未证明。
- tile 无法覆盖或 mask 缺失。
- reduction active mask 不合法。
- 估计 register 风险过高；最终仍看 ptxas。
- 使用目标架构不支持的能力。

## 示例 1：一维 Elementwise

```cpp
template<int BLOCK, int ITEMS>
__global__ void scale(const float* x, float* y, long long n, float alpha) {
  long long base =
      ((long long)blockIdx.x * ITEMS) * BLOCK + threadIdx.x;
#pragma unroll
  for (int j = 0; j < ITEMS; ++j) {
    long long i = base + (long long)j * BLOCK;
    if (i < n) y[i] = x[i] * alpha;
  }
}
```

可调：BLOCK、ITEMS；VEC 只有对齐得到证明时。grid 随 `BLOCK*ITEMS` 改变。小 n 需防止并行度不足。

## 示例 2：二维 Elementwise

```cpp
template<int BX, int BY>
__global__ void add2d(const float* a, const float* b, float* c, int M, int N) {
  int n = blockIdx.x * BX + threadIdx.x;
  int m = blockIdx.y * BY + threadIdx.y;
  if (m < M && n < N) {
    long long i = (long long)m * N + n;
    c[i] = a[i] + b[i];
  }
}
```

让 x 对应 N 的 stride-1。候选必须满足 BX*BY 合法。BX/BY 改变 block shape、grid、warp 排列和尾部利用率。

## 示例 3：行归约

```cpp
template<int BLOCK>
__global__ void row_sum(const float* x, float* y, int rows, int cols) {
  int row = blockIdx.x;
  float acc = 0.0f;
  for (int col = threadIdx.x; col < cols; col += BLOCK)
    acc += x[(long long)row * cols + col];
  float value = block_reduce_sum<BLOCK>(acc);
  if (threadIdx.x == 0) y[row] = value;
}
```

BLOCK 同时影响循环次数、shuffle/shared 结构和浮点次序。候选要覆盖 BLOCK<32/非 32 倍数的 active mask，或直接过滤这些配置。

## 示例 4：Shared Tile

```cpp
template<int TM, int TN>
__global__ void tile_kernel(...) {
  __shared__ float tile[TM][TN + 1];
  // cooperative load
  __syncthreads();
  // reuse
}
```

TM/TN 影响 threads、shared bytes、registers、reuse 和边界。不能只按 tile 面积选择。

## 输出校验

- 所有目标 kernel 唯一。
- 三维 launch 结构完整。
- 数据轴、stride、thread 映射一致。
- tunable 参数与源码真实符号对应。
- 多组测试没有遗漏。
- 对齐、归约和 shared 风险明确。
- ptxas/NCU 数值注明来源。
- JSON 可解析。

## 配置搜索附加分析

### Warp 内访存

为每个主指针写出 lane 地址函数：

```text
A(lane) = base + index(blockIdx, warp, lane, loop) * sizeof(T)
```

记录相邻 lane 的字节差、边界 predicate、alignment、广播和复用。同一 thread mapping 可能让输出连续、某输入却是 stride/gather；按真实 bytes 和 NCU transaction 证据决定优先级。

### 二维/三维 Block 的 Warp

线性 thread id：

```cpp
int tid = threadIdx.x +
          blockDim.x * (threadIdx.y + blockDim.y * threadIdx.z);
```

warp 由连续 tid 组成。BLOCK_X 小于 32 时一个 warp 会跨 y；因此 row reduction 的 shuffle group未必等于 threadIdx.y。每个候选必须重新验证 group、mask 和 shared partition。

### Vector 对齐证明

VEC>1 需证明：

- base allocation 对齐。
- slice/row offset 对齐。
- stride-1。
- vector 不跨逻辑行或对象边界。
- tail/scalar fallback。
- alias/restrict 语义。

例如 float4 要求每个实际 vector address 满足 16-byte alignment；仅有 cudaMalloc 基址对齐不足以证明任意 row/slice 对齐。

### Shared Memory

同时记录源码表达式和实际资源：

```json
{
  "static_expression": "TM*(TN+1)*sizeof(float)",
  "dynamic_expression": "...",
  "launch_bytes": "...",
  "ptxas_bytes": null,
  "bank_pattern": "unknown"
}
```

dynamic shared 的 host 第三 launch 参数必须与 kernel 分区一致；混合类型子区域需显式 alignment。padding 候选最终由 NCU 验证，不能机械使用 +1。

### Register 风险

大 accumulator、ITEMS、VEC、UNROLL 和同时存活 tile 都可能增加 register。源码只记录风险；真实 register/spill 必须来自每个候选的 ptxas。register 降低不等于耗时降低。

### Grid 覆盖

改变 BLOCK/ITEMS/VEC 后重新推导 logical work、work/block 和 grid。所有乘法先以 64-bit 计算，转 dim3 前检查范围。persistent 候选必须有 grid-stride loop；不能只裁剪普通 grid。

### Reduction

记录 operator、identity、dtype、active mask、barrier、atomic、determinism 和浮点次序。BLOCK 改变可能改变归约树；每个配置都需完整 correctness，而非复用 baseline 结果。

### Atomic

配置表需包含每 output 的 atomic 数、初始化/reset、返回值使用和目标 dtype 合法性。增大 grid 可能增加 contention；更多 block 不是单调收益。

### 多 Kernel Pipeline

若 wrapper 是 partial→final 或 preprocess→kernel→postprocess，为每个 kernel 生成单独资源和 launch 记录，并保存读写依赖。改变 partial grid 时同步更新 workspace 和 final 输入。性能目标预先声明 kernel-only 还是完整 pipeline。

### 测试矩阵

所有用户 case 都进入：

```text
shape, dtype, stride, alignment, seed, stream, weight, guardrail
```

权重和 no-regression guardrail 在搜索前固定。缺少用户权重时，要求每个关键 case no-regression，再按等权聚合；禁止事后选择有利 shape。

### 候选过滤顺序

1. 语义与覆盖。
2. threads/grid/shared 硬限制。
3. warp mask/barrier/atomic 安全。
4. vector alignment/tail。
5. nvcc/ptxas 编译资源。
6. correctness。
7. sanitizer（适用时）。
8. 真实 RTX 3090 性能。

上一步失败就淘汰，不运行后续昂贵步骤。

### 常见误判

- 把最后逻辑轴默认当连续轴。
- 忽略 blockDim.y/z 的 warp 排列。
- 把 loop ITEMS 当 vector instruction。
- 从局部变量数猜 registers。
- 只取首个 shape。
- ptxas 多 kernel 资源串错。
- 改 BLOCK 不更新 dynamic shared 或 shuffle mask。
- atomic benchmark repeat 不 reset。

不确定项必须为 null 并阻止对应危险配置。
