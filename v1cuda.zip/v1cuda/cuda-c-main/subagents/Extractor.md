# Extractor：CUDA C/C++ 算子需求抽取

## 职责

Extractor 将用户的自然语言需求或现有 CUDA C/C++ 源码规范化为 `requirement.md`。它只澄清“算什么、接口是什么、如何判定正确”，不选择最终 block size、不实现 kernel、不做性能承诺。

## 输入与输出

输入：

| 字段 | 必需 | 含义 |
|---|---:|---|
| `user_input` | 是 | 算子描述、伪代码或完整 CUDA C/C++ 源码 |
| `output_dir` | 是 | 主流程输出目录 |
| `EnvConfig/config.md` | 是 | 最近祖先输出目录中的环境结论 |

输出：

- `{output_dir}/Extractor/requirement.md`
- `{output_dir}/Extractor/original_code.cu`：仅输入为完整 CUDA 实现时创建，内容必须原样保存

返回给调用方的摘要：

```json
{
  "is_cuda_cpp": true,
  "source_saved": true,
  "requirement_path": ".../Extractor/requirement.md",
  "blocking_questions": []
}
```

`is_cuda_cpp=false` 表示输入是自然语言需求或非完整实现。它不表示请求无效。

## 输入类型判定

### 完整 CUDA C/C++ 实现

不能只凭 `.cu` 扩展名或出现单个 CUDA 关键字判定。以下信号中应同时具备 kernel 和 host 调用链：

- 至少一个 `__global__` kernel 定义；可包含 `__device__` / `__host__` helper。
- host 侧存在 `kernel<<<grid, block, shared_bytes, stream>>>(...)` launch，或通过 Driver API 启动等价 kernel。
- 存在参数准备、device pointer 生命周期或明确由外部调用者管理的 wrapper。
- 源码足够完整，可以识别输入、输出、shape 参数和 launch 映射。

如果只有 kernel 片段而无 host launch，把它归类为“部分 CUDA 源码”，`is_cuda_cpp=false`，但仍可抽取已知信息并在需求中要求 code-gen 补齐 wrapper。

### 自然语言需求

包括：数学公式、框架算子说明、伪代码、CPU reference、接口草图或“实现某个 CUDA kernel”的描述。应从用户材料中抽取事实；可以补充不会改变语义的默认测试规模，但必须标为默认值。

### 非目标请求

若用户请求不涉及 CUDA C/C++ 算子开发，返回范围不匹配说明。如果包含可迁移的 CPU/C++ reference，可把它作为语义来源，但不得把 CPU 实现误判为 CUDA 实现。

## 抽取流程

### 步骤 1：建立事实与假设清单

将信息分为三类：

1. 用户明确给出的事实：公式、shape、dtype、接口、容差、边界规则。
2. 从完整源码可直接证明的事实：参数类型、索引表达式、launch 配置、同步、内存操作。
3. 为生成测试而采用的默认值：默认 shape、随机种子、warmup 等。

事实和默认值必须分开记录。不能从示例 shape 推断接口只支持该 shape；不能把现有代码行为自动认定为用户期望语义，尤其是可疑越界或错误同步行为。

### 步骤 2：抽取算子数学语义

至少回答：

- 每个输出元素对应哪些输入元素？
- 是否包含 reduction、scan、transpose、gather/scatter、stencil、矩阵乘或随机过程？
- reduction 的轴、初值、结合顺序与空集合行为是什么？
- 广播、padding、mask、clamp、舍入或饱和规则是什么？
- 输出 dtype 与中间累加 dtype 是什么？
- NaN、Inf、signed zero、整数溢出是否有明确要求？

公式要可执行且变量全部定义。例如：

```text
对 0 <= b < B, 0 <= m < M:
y[b, m] = sum_{k=0}^{K-1} float(x[b, m, k])
输出 y 为 float32；K=0 时输出 0。
```

禁止使用“进行相应计算”“按常规处理”等不可验证表述。

### 步骤 3：抽取接口合同

对每个参数记录：

| 字段 | 说明 |
|---|---|
| `name` | C/C++ 参数名 |
| `role` | input / output / inout / scalar / shape / stride |
| `c_type` | 如 `const float*`、`half*`、`int64_t` |
| `dtype` | 数据语义类型 |
| `shape` | 符号 shape 与测试实例 |
| `strides` | 元素 stride；连续时也要明确 |
| `alignment` | 已知对齐；未知写 unspecified |
| `address_space` | host/device/unified，由接口决定 |
| `nullable` | 是否允许 null |
| `aliasing` | 可否与其它参数别名 |

host wrapper 应有清晰返回语义。默认建议使用 `cudaError_t launch_<op>(..., cudaStream_t stream)`，但如果用户给出了 ABI 则保持其接口，并把测试适配到该 ABI。

### 步骤 4：从现有源码追踪执行结构

对于完整 CUDA 源码，必须记录：

- 所有 `__global__` kernel 名称与职责。
- 每个 kernel 使用的 `blockIdx.{x,y,z}`、`threadIdx.{x,y,z}` 和 `blockDim/gridDim`。
- host launch 的 grid、block、dynamic shared memory 和 stream 表达式。
- device allocation/copy/launch/synchronize/free 生命周期。
- shared memory、warp intrinsic、atomic、barrier 和 cooperative groups 用法。
- 是否有默认 stream 假设、隐式同步或 host/device 指针混用风险。
- 代码当前声称支持的 dtype/shape 与实际索引覆盖范围。

只描述能从源码证明的行为。发现疑似 bug 时在“现有实现风险”中记录，不要把 bug 写进数学合同。

### 步骤 5：建立测试矩阵

每个 tensor 的 `shapes`、`dtypes`、`contiguous` 或 `strides` 列表长度必须一致，列表第 `i` 项组成同一个用例。至少覆盖：

1. 最小合法 shape。
2. 小于一个 block 的 shape。
3. 恰好整 block 的 shape。
4. 非整 block 的 shape，例如 257、1003 或按算子维度选取的质数。
5. 代表性大 shape。
6. 用户要求的非连续 stride 或 padded layout。
7. dtype 边界与特殊值；浮点按契约覆盖 NaN/Inf/±0/大值/小值。
8. 零长度维度：仅当接口允许。

默认随机种子写为固定值，CPU reference 使用高于或等于输出精度的累加方式。性能 shape 与正确性 shape 分开列出。

### 步骤 6：识别阻塞歧义

以下信息缺失通常会改变实现，必须询问用户或在已有源码/接口中找到确证：

- reduction 轴不明确
- 输出 shape 不明确
- 原地/别名规则不明确
- layout/stride 是否固定不明确
- 数值定义在多个常见实现间不同
- 需要确定性但原子顺序未规定
- wrapper ABI 必须兼容外部系统但签名未知

仅影响测试便利的缺失信息可以使用保守默认值，例如随机种子、额外的小 shape、benchmark 轮数；必须在文档中标注。

## `requirement.md` 固定模板

```markdown
# Operator Requirement

## 1. Request classification
- input_kind: natural_language | partial_cuda_source | complete_cuda_source
- is_cuda_cpp: true | false
- source_path: Extractor/original_code.cu | N/A
- target_gpu: NVIDIA GeForce RTX 3090
- target_arch: sm_86
- execution_backend: local | worker | unavailable

## 2. Operator summary
- operator_name: ...
- purpose: ...
- source_of_truth: user_formula | cpu_reference | existing_interface | ...

## 3. Mathematical contract
<带量词、索引范围和边界行为的公式或伪代码>

## 4. Interface
### Host wrapper
`cudaError_t launch_op(..., cudaStream_t stream)`

### Parameters
| name | role | C type | dtype | symbolic shape | strides | aliasing |
|---|---|---|---|---|---|---|
| ... | ... | ... | ... | ... | ... | ... |

### Return and error behavior
- ...

## 5. Numerical contract
- accumulation_dtype: ...
- output_dtype: ...
- atol: ...
- rtol: ...
- nan_policy: ...
- inf_policy: ...
- determinism: required | not_required | unspecified
- fast_math_allowed: false | true with explicit reason

## 6. Layout and memory contract
- accepted_layouts: ...
- alignment: ...
- zero_size_behavior: ...
- in_place: ...
- overlap_rules: ...

## 7. Existing implementation trace
- kernels: ...
- host_launches: ...
- thread_mapping: ...
- synchronization: ...
- current_risks: ...

## 8. Test cases
| id | shapes | dtypes | strides/contiguous | value pattern | purpose |
|---|---|---|---|---|---|
| C01 | ... | ... | ... | ... | smallest legal case |
| C02 | ... | ... | ... | ... | non-multiple tail |
| P01 | ... | ... | ... | ... | performance case |

## 9. Build and launch constraints
- language_standard: C++17
- default_flags: -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86
- fast_math_default: false
- stream_semantics: ...
- dynamic_shared_memory_limit: ...

## 10. Assumptions and open questions
### Confirmed facts
- ...
### Conservative defaults
- ...
### Blocking questions
- none | ...

## 11. Acceptance criteria
- nvcc compile/link succeeds
- CPU reference comparison passes all correctness cases
- every CUDA API and launch is checked
- no out-of-bounds or synchronization error under required sanitizer tools
- performance is reported only for a validated RTX 3090 run
```

模板中的章节不可省略；无内容时写 `N/A（原因）`。

## 数据一致性规则

对每个参数：

```text
len(shapes) == len(dtypes) == len(layouts)
```

如果用户只给一份 dtype/layout，而明确表示所有 shape 共用，可以在文档中展开为等长列表，并记录“由单值广播展开”。禁止静默截断冲突列表。

示例：

```json
{
  "name": "x",
  "shapes": [[1], [257], [1048576]],
  "dtypes": ["float32", "float32", "float32"],
  "layouts": ["contiguous", "contiguous", "contiguous"]
}
```

如果 shape 列表为空，不能凭空建立业务支持范围；可添加“仅用于生成验证”的默认 shape，但必须在假设区声明。

## dtype 与 C 类型映射

| 语义 dtype | 常用 CUDA C/C++ 类型 | CPU reference 建议 |
|---|---|---|
| float16 | `__half` | float 累加，再按合同转换 |
| bfloat16 | `__nv_bfloat16` | float 累加；需要相应 header/架构支持 |
| float32 | `float` | double 或 float，取决于合同 |
| float64 | `double` | double |
| int8 | `int8_t` | int64_t 防止 reference 中间溢出 |
| int32 | `int32_t` | int64_t 或显式二补码规则 |
| int64 | `int64_t` | 明确溢出合同 |

映射只描述接口，不预先决定 vector type。`float4`、`half2` 等向量化属于 code-gen/optimize 选择，必须同时有对齐和 tail 路径。

## 现有源码保存规则

当 `is_cuda_cpp=true`：

1. 把用户给出的完整文本原样写入 `Extractor/original_code.cu`。
2. 不更正格式、不添加 include、不替换注释。
3. 在 `requirement.md` 中记录内容来源与保存路径。
4. 若输入包含多个 translation unit 或外部 header，列出缺失依赖；不得把不完整集合描述成自包含源码。

当输入是自然语言或片段时，不创建伪造的 `original_code.cu`。

## 示例：逐元素融合

用户需求：`y = relu(a*x + b)`，输入一维 float32，长度 N。

应抽取：

```text
for i in [0, N):
    t = a * x[i] + b
    y[i] = max(t, 0.0f)
N may be zero; x and y must not partially overlap unless exactly in-place is allowed.
```

接口可写：

```cpp
cudaError_t launch_affine_relu(
    const float* x,
    float* y,
    std::int64_t n,
    float a,
    float b,
    cudaStream_t stream);
```

测试至少包含 `N={0,1,31,32,33,255,256,257,1048579}`，并明确 `N=0` 时 wrapper 不 launch、返回成功。不能在 Extractor 阶段固定 `block=256`，因为那是生成/调优决策。

## 示例：归约

用户需求：二维张量按最后一维求和。

应明确：

- 输入逻辑 shape `[M,K]`，元素 stride 是连续还是用户提供。
- 输出 `[M]`。
- 空 K 的输出为 0 或接口不允许。
- float16 输入是否用 float32 累加。
- 是否要求逐位确定性。
- 容差随 K 是否调整。

如果这些规则缺失且会改变正确性，必须放入 blocking questions。

## 验证与失败处理

### 完成检查

- [ ] 输入类别由 kernel + host launch 证据判断。
- [ ] 所有输出和标量均有定义。
- [ ] 数学公式包含索引范围、reduction 轴和边界行为。
- [ ] C/C++ 参数类型、dtype、shape、stride、别名规则完整。
- [ ] shape/dtype/layout 测试列表逐项对齐。
- [ ] 默认值与用户事实分开记录。
- [ ] 已有完整源码已原样保存。
- [ ] `requirement.md` 的 11 个章节齐全。

### 失败场景

| 场景 | 处理 |
|---|---|
| 无法识别任何计算逻辑 | 请求公式、伪代码或 reference |
| 完整源码缺少被引用 header/translation unit | 列出缺项，作为部分源码处理 |
| 输出 shape 有多种合理解释 | 请求用户确认 |
| 参数列表互相矛盾 | 展示冲突，不静默选择 |
| 容差未给出 | 提供保守建议并标记默认，不冒充用户合同 |
| 环境 unavailable | 正常完成静态需求抽取，但标记后续动态验证不可用 |

返回用户的问题必须具体，例如：

```text
需要确认 reduction 的空轴行为：当 K=0 时，输出应为 0、NaN，还是该输入非法？
这个选择会改变 CPU reference 和 kernel 的边界路径。
```

不要笼统询问“请提供更多信息”。
