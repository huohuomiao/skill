# Reduce Max 轴分析例子

## 示例代码

```cpp
#include <cuda_runtime.h>
#include <cfloat>

__inline__ __device__ float warp_max(float v) {
  unsigned mask = __activemask();
  for (int offset = warpSize / 2; offset > 0; offset >>= 1)
    v = fmaxf(v, __shfl_down_sync(mask, v, offset));
  return v;
}

__global__ void row_max(
    const float* __restrict__ x,
    float* __restrict__ out,
    int rows, int cols) {
  int row = blockIdx.x;
  if (row >= rows) return;

  float local = -CUDART_INF_F;
  for (int col = threadIdx.x; col < cols; col += blockDim.x)
    local = fmaxf(local, x[(long long)row * cols + col]);

  __shared__ float warp_partial[32];
  local = warp_max(local);
  int lane = threadIdx.x & 31;
  int warp = threadIdx.x >> 5;
  if (lane == 0) warp_partial[warp] = local;
  __syncthreads();

  if (warp == 0) {
    int warp_count = (blockDim.x + 31) / 32;
    float v = lane < warp_count ? warp_partial[lane] : -CUDART_INF_F;
    v = warp_max(v);
    if (lane == 0) out[row] = v;
  }
}
```

## 轴与 launch

| 轴 | extent | 来源 | 类型 |
| --- | --- | --- | --- |
| row | rows | blockIdx.x | grid parallel |
| col | cols | threadIdx.x + k*blockDim.x | thread reduction |
| lane | 32 | threadIdx.x & 31 | warp |
| warp | ceil(block.x/32) | threadIdx.x >> 5 | block partial |

建议 launch：

```cpp
dim3 block(256);
dim3 grid(rows);
row_max<<<grid, block, 0, stream>>>(x, out, rows, cols);
```

## 归约语义

- operator：max
- identity：`-CUDART_INF_F`
- scope：一个 block 对一行
- 算法：线程局部 → warp shuffle → shared warp partial → 首 warp
- atomic：无
- barrier：写 warp_partial 后一次 block barrier

注意事项：

1. `blockDim.x` 应是 32 的倍数，且不超过共享平台门禁；否则 active mask 与部分 warp 需要更谨慎处理。
2. NaN 语义取决于 `fmaxf` 与 reference 的契约，不能假设一致。
3. shared array 上限 32 个 warp，正常 CUDA block 最多 1024 threads。
4. `row*cols` 在乘法前提升到 64-bit。
5. barrier 不在只允许部分线程进入的分支中。

## 结构化输出

```json
{
  "kernel_name": "row_max",
  "launch": {
    "grid_expr": ["rows", "1", "1"],
    "block_expr": ["256", "1", "1"]
  },
  "axes": [
    {"name": "row", "extent": "rows", "source": "blockIdx.x", "kind": "grid_parallel"},
    {"name": "col", "extent": "cols", "source": "threadIdx.x+k*blockDim.x", "kind": "thread_reduce"}
  ],
  "reduction": {
    "present": true,
    "operator": "max",
    "identity": "-inf",
    "axis": "col",
    "scope": "block",
    "algorithm": "warp_shuffle_plus_shared"
  },
  "control": {
    "barriers": ["after warp_partial store"],
    "warp_primitives": ["__shfl_down_sync"],
    "atomics": []
  }
}
```

## 优化门禁

可搜索 block size、每线程加载数和向量宽度，但必须保持 NaN/边界语义。只有真实 RTX 3090 correctness、安全检查和相同 flags benchmark 通过时保留。
