# Spec 示例：转置与逐元素运算融合

## 需求

对连续 row-major float32 输入 `x[M,N]` 和长度 N 的 `bias` 计算连续输出 `y[N,M]`：

```text
y[n,m] = relu(scale * x[m,n] + bias[n])
relu(v) = v > 0 ? v : 0
```

`x`、`bias`、`y` 不重叠。M/N 非负，任一为 0 时不 launch。scale 为 runtime float。NaN 行为由比较式定义：当 v 为 NaN 时 `v > 0` 为 false，输出 `0.0f`；因此 CPU reference 必须采用相同条件而非 `std::fmax`。

## 融合目标

若先 transpose 再单独执行 affine+ReLU，会写入并再次读取中间矩阵。本规格将 arithmetic 放在 shared tile 的 load 阶段：

```text
v = scale * x[m,n] + bias[n]
tile[local_m][local_n] = v > 0 ? v : 0
barrier
y[n,m] = tile[local_m][local_n] through transposed indices
```

每个 x 读一次、bias 读一次、y 写一次，无中间 global buffer。bias 的相邻 n 由相邻 lane 读取，访问连续。

## 实现规格

```json
{
  "schema_version": 1,
  "operator_name": "transpose_bias_relu_f32",
  "translation_unit": {
    "language": "CUDA C++17",
    "headers": ["cuda_runtime.h", "cstdint", "limits", "cmath"]
  },
  "build": {
    "flags": ["-std=c++17", "-O3", "-DNDEBUG", "-lineinfo", "-arch=sm_86"],
    "fast_math": false
  },
  "constants": {
    "tile_dim": 32,
    "block_rows": 8,
    "threads_per_block": 256
  },
  "kernels": [
    {
      "name": "transpose_bias_relu_f32_kernel",
      "parameters": [
        {"type": "const float* __restrict__", "name": "x"},
        {"type": "const float* __restrict__", "name": "bias"},
        {"type": "float* __restrict__", "name": "y"},
        {"type": "std::int64_t", "name": "m"},
        {"type": "std::int64_t", "name": "n"},
        {"type": "float", "name": "scale"}
      ],
      "grid": ["ceil_div(n,32)", "ceil_div(m,32)", 1],
      "block": [32, 8, 1],
      "dynamic_shared_bytes": 0,
      "shared_memory": [
        {
          "declaration": "__shared__ float tile[32][33]",
          "bytes": 4224,
          "purpose": "transpose fused values with padded rows"
        }
      ],
      "load_compute_loop": {
        "j_values": [0, 8, 16, 24],
        "predicate": "input_col < n && input_row+j < m",
        "body": [
          "v = scale * x[(input_row+j)*n+input_col] + bias[input_col]",
          "tile[threadIdx.y+j][threadIdx.x] = v > 0.0f ? v : 0.0f"
        ]
      },
      "barriers": [
        {
          "primitive": "__syncthreads()",
          "position": "after all predicated fused loads",
          "participants": "all 256 threads",
          "early_return_before": false
        }
      ],
      "store_loop": {
        "j_values": [0, 8, 16, 24],
        "predicate": "output_col < m && output_row+j < n",
        "body": "y[(output_row+j)*m+output_col] = tile[threadIdx.x][threadIdx.y+j]"
      },
      "warp_intrinsics": [],
      "atomics": []
    }
  ],
  "wrappers": [
    {
      "name": "launch_transpose_bias_relu_f32",
      "return_type": "cudaError_t",
      "preconditions": [
        "m >= 0 && n >= 0",
        "m*n fits allocation/index range",
        "x, bias, y are non-null and pairwise non-overlapping for non-empty input",
        "grid dimensions fit selected device"
      ],
      "zero_size": "return cudaSuccess before pointer checks",
      "launch": "transpose_bias_relu_f32_kernel<<<grid,block,0,stream>>>(x,bias,y,m,n,scale)",
      "post_launch": "return cudaGetLastError()",
      "host_synchronization": "none"
    }
  ],
  "memory_accesses": [
    {
      "tensor": "x",
      "mode": "read",
      "lane_delta_elements": 1,
      "classification": "coalesced"
    },
    {
      "tensor": "bias",
      "mode": "read",
      "lane_delta_elements": 1,
      "classification": "coalesced and reused across four row iterations per thread"
    },
    {
      "tensor": "y",
      "mode": "write",
      "lane_delta_elements": 1,
      "classification": "coalesced after shared transpose"
    }
  ],
  "tests": {
    "correctness": [
      {"id": "C01", "m": 0, "n": 9, "purpose": "empty"},
      {"id": "C02", "m": 1, "n": 1, "purpose": "minimum"},
      {"id": "C03", "m": 5, "n": 7, "purpose": "small_both_tails"},
      {"id": "C04", "m": 32, "n": 32, "purpose": "exact_tile"},
      {"id": "C05", "m": 33, "n": 65, "purpose": "multi_tile_tails"},
      {"id": "C06", "m": 127, "n": 257, "purpose": "rectangular"}
    ],
    "scalars": [
      {"scale": 0.0, "purpose": "bias_only"},
      {"scale": 1.25, "purpose": "positive_scale"},
      {"scale": -0.75, "purpose": "negative_scale"}
    ],
    "special_values": ["threshold_neighbors", "NaN", "positive_infinity", "negative_infinity"],
    "comparison": {"atol": 0.000001, "rtol": 0.000001, "nan_output": "zero_by_contract"},
    "benchmark": {
      "m": 4096,
      "n": 4096,
      "warmup": 20,
      "iterations": 100,
      "method": "CUDA Event",
      "logical_bytes": "m*n*sizeof(float) read + n*sizeof(float) logical bias read + m*n*sizeof(float) write"
    },
    "sanitizer": ["memcheck", "racecheck", "synccheck"]
  },
  "unresolved": [],
  "ready_for_code": true
}
```

## 对应 CUDA C++ 核心

```cpp
template <int TileDim, int BlockRows>
__global__ void transpose_bias_relu_f32_kernel(
    const float* __restrict__ x,
    const float* __restrict__ bias,
    float* __restrict__ y,
    std::int64_t m,
    std::int64_t n,
    float scale) {
    __shared__ float tile[TileDim][TileDim + 1];
    const std::int64_t input_col =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.x;
    const std::int64_t input_row =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.y;

    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (input_col < n && input_row + j < m) {
            const float value =
                scale * x[(input_row + j) * n + input_col] + bias[input_col];
            tile[threadIdx.y + j][threadIdx.x] =
                value > 0.0f ? value : 0.0f;
        }
    }
    __syncthreads();

    const std::int64_t output_col =
        static_cast<std::int64_t>(blockIdx.y) * TileDim + threadIdx.x;
    const std::int64_t output_row =
        static_cast<std::int64_t>(blockIdx.x) * TileDim + threadIdx.y;
    #pragma unroll
    for (int j = 0; j < TileDim; j += BlockRows) {
        if (output_col < m && output_row + j < n) {
            y[(output_row + j) * m + output_col] =
                tile[threadIdx.x][threadIdx.y + j];
        }
    }
}
```

## 融合正确性

对每个合法 input `(m,n)`，load 阶段计算且唯一写入 `tile[local_m][local_n]`；barrier 后 store 阶段把该位置唯一写入 output `(n,m)`。arithmetic 只依赖 x[m,n]、bias[n] 和 uniform scale，不依赖其它元素，因此移动到 transpose tile 内不会改变数据依赖。

NaN 规则是这个示例的重要部分：C/C++ 条件表达式 `value > 0.0f ? value : 0.0f` 对 NaN 返回 0。不能用 `fmaxf(value,0)` 替换而不先验证两者 NaN 行为是否与合同相同。

## 资源与性能门禁

- block 256 threads，shared memory 4224 bytes，需用共享平台规则确认合法。
- bias 在每个 j 循环重复读取相同值；编译器通常可保存在寄存器，但代码可以在循环前用 predicated scalar `bias_value` 缓存。必须保证 input_col 越界时不读 bias。
- 初始实现不使用 `float4`，因为接口未保证 16-byte alignment 且 tile tail 需要 scalar path。
- logical bandwidth 的 bias 项只按 N 个独特元素计还是按实际 kernel load 次数计必须在报告中明确；这里建议同时报告算子逻辑字节与 NCU 实际 memory 指标，不混淆二者。
