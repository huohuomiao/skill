# CUDA Grid 与 Launch 优化

## 职责

优化 CUDA C/C++ kernel 的 `dim3 grid`、`dim3 block`、grid-stride 覆盖和可选 persistent launch。普通逻辑 grid 与 persistent grid 是两种不同语义；禁止只裁剪 grid 而漏算数据。

本策略只修改 launch/覆盖方式。block 内 tiling、归约树、数学函数和编译 flags 由其他策略处理。

## Step 1：提取所有 Launch

从 host wrapper 和目标 kernel 读取：

- `<<<grid, block, dynamic_shared, stream>>>`
- `cudaLaunchKernel`
- `dim3` 构造与宏/模板参数
- x/y/z 逻辑 tile 数
- kernel 内的 blockIdx/threadIdx/gridDim/blockDim
- grid-stride/thread-stride loop
- 每个输出是否恰好一次写入
- reduction、atomic、barrier 和跨 block 依赖
- dynamic shared bytes

多 kernel pipeline 必须分别分析，不能把一个 kernel 的 grid 套到另一个。

## Step 2：分类

### A. 无法恢复 Launch

函数指针、外部框架或宏使 launch 不可确定时，不修改代码；输出 `not_applicable`，见 [modify_grid_without_grid.md](./references/modify_grid_without_grid.md)。

### B. 普通一维 Grid

```cpp
long long logical_blocks = ceil_div(n, BLOCK);
dim3 grid((unsigned)logical_blocks);
```

这是合法普通调度。grid 可以远大于 SM 数；尾波不是漏算。除非 kernel 已有 grid-stride loop，否则禁止裁剪。

见 [modify_grid_1d.md](./references/modify_grid_1d.md)。

### C. 普通二维/三维 Grid

各维均合法且与数据轴自然对应时可保留。只有以下情况才建立 flatten 候选：

- y/z 可能超过平台上限。
- 展平能简化 host launch 或改善负载均衡。
- kernel 可无损恢复原 block 坐标。
- 64-bit 乘法和总 tile 数安全。

见 [modify_grid_3d.md](./references/modify_grid_3d.md)。

### D. 固定单 block 或小 Grid

先确认计算是否确实只有一个逻辑 tile。若逻辑数据更大但 kernel 没有 grid-stride，固定 grid=1 可能是 bug，不是性能基线。见 [modify_grid_constexpr.md](./references/modify_grid_constexpr.md)。

### E. 跨 Block 归约

改变 grid 会改变 partial 数量、atomic 次序或第二阶段输入。必须保持 identity、累加 dtype、初始化和阶段间同步。见 [modify_grid_reduce.md](./references/modify_grid_reduce.md)。

## Step 3：普通 Grid 候选

### 3.1 无损展平

原 grid：

```cpp
dim3 grid(gx, gy, gz);
```

候选 host：

```cpp
long long logical = (long long)gx * gy * gz;
dim3 grid((unsigned)logical);
```

candidate kernel：

```cpp
long long linear = blockIdx.x;
long long bx = linear % gx;
long long q = linear / gx;
long long by = q % gy;
long long bz = q / gy;
```

必须检查 `logical <= grid_x_limit`，否则使用 grid-stride 处理 linear tile 或分批 launch。不能静默截断为 unsigned。

### 3.2 Grid-stride

```cpp
for (long long tile = blockIdx.x;
     tile < logical_tiles;
     tile += gridDim.x) {
  // 从 tile 恢复逻辑坐标并完整处理
}
```

只有每个 tile 相互独立、或写冲突/atomic 语义被证明安全时使用。循环体中含 `__syncthreads` 时，全 block 必须以一致迭代次数到达 barrier；尾部通常用 block-uniform `tile < logical_tiles` 控制外层循环。

## Step 4：Persistent 候选准入

必须同时满足：

1. 普通版本 correctness 和 safety 已通过。
2. kernel 可表达为 grid-stride，覆盖全部逻辑 tile。
3. 各 tile 独立，或 atomic/归约语义明确。
4. 无跨 block barrier 假设。
5. NCU 显示 launch/tail/调度是实际瓶颈，不能仅凭经验使用。
6. kernel duration 足够大，避免把计时噪声误认为收益。
7. 每个 block 的资源来自实际编译。

运行时属性：

```cpp
cudaDeviceProp prop{};
CUDA_CHECK(cudaGetDeviceProperties(&prop, device));

int active_blocks_per_sm = 0;
CUDA_CHECK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
    &active_blocks_per_sm, target_kernel, block_threads, dynamic_shared_bytes));

long long cap =
    (long long)prop.multiProcessorCount * active_blocks_per_sm;
long long launch_blocks = std::min(logical_tiles, cap);
```

规则：

- 不硬编码 SM 数。
- occupancy API 使用目标 kernel、实际 block 和 dynamic shared bytes。
- `active_blocks_per_sm <= 0` 时拒绝候选。
- occupancy cap 是候选起点，不是最优答案。
- 普通 kernel 不使用 cap。
- persistent loop 必须使用实际 `gridDim.x` 作为 stride。
- 修改 block 后重新计算 occupancy。

## Step 5：边界和类型

- grid/block 维度遵守共享平台规则。
- `block.x * block.y * block.z` 不超过 threads/block 上限。
- logical tile 乘法先提升到 64-bit。
- 转为 `dim3` 的 unsigned 前检查范围。
- dynamic shared bytes 与 kernel 声明和 occupancy API 一致。
- `cudaFuncSetAttribute` 等 opt-in 必须检查返回值。
- 保留调用方 stream，不偷偷使用 default stream。
- launch 后检查错误，并在测试边界同步捕获异步错误。

## Step 6：验证与决策

建立最多两个独立候选：

1. normal/flatten candidate。
2. 有 NCU 证据时的 persistent candidate。

每个候选分别从同一输入生成，不把两个改动混在一轮。遵守 Optimizer：

- 相同 flags 编译并收集 ptxas。
- correctness 覆盖小于 block、非整 grid、大 grid 和极端 shape。
- 修改循环/barrier/atomic 时运行适用 sanitizer。
- 相同 RTX 3090 benchmark。
- 对比 resources、waves、tail、SM/DRAM throughput。
- 只有无回退且收益超出噪声时 keep。

报告明确 `grid_before`、`grid_after`、`coverage_proof`、`occupancy_api_result`、`logical_tiles`、`launch_blocks` 和回退原因。

## 禁止项

- `grid = min(logical_blocks, sm_count)`，但 kernel 没有 grid-stride loop。
- 用 CUDA core 数替代 SM 数。
- 用硬编码 RTX 3090 SM 数替代 runtime property。
- 跨 block 用 `__syncthreads`。
- flatten 后用 32-bit 乘法导致溢出。
- 改变归约 partial/atomic 数量却不重新验证数值语义。
- 用 occupancy 估算替代 benchmark。

## Launch 解析细则

### Triple-Chevron

以下写法等价地包含四个配置槽：

```cpp
kernel<<<grid, block>>>(...);
kernel<<<grid, block, shared_bytes>>>(...);
kernel<<<grid, block, shared_bytes, stream>>>(...);
```

省略值分别表示动态 shared=0、default stream。优化时保留调用方 stream 语义；不能为方便 benchmark 把 non-default stream 改成 0。

### cudaLaunchKernel

```cpp
void* args[] = {&x, &y, &n};
CUDA_CHECK(cudaLaunchKernel(
    reinterpret_cast<const void*>(kernel), grid, block,
    args, shared_bytes, stream));
```

解析参数数组的地址层级、顺序和生命周期。修改 kernel signature 时同步更新 args；本策略默认不改 signature。

### 模板 Kernel 与 Occupancy API

occupancy API必须指向实际实例：

```cpp
auto kernel_ptr = target_kernel<BLOCK, ITEMS>;
CUDA_CHECK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
    &active, kernel_ptr, BLOCK, shared_bytes));
```

不同模板参数产生不同 register/shared 资源，不能复用另一个实例的 active 数。

## Dim3 边界

记录设备实际 `maxGridSize[]`、`maxThreadsDim[]` 和 `maxThreadsPerBlock`。共享平台文档提供 sm_86 门禁，但 runtime property 是当前设备真值。

检查表达式：

```cpp
long long gx64 = ceil_div(n, work_per_block);
if (gx64 <= 0 || gx64 > prop.maxGridSize[0]) {
  // 选择合法 grid-stride cap，或报告不支持。
}
dim3 grid(static_cast<unsigned>(gx64));
```

n=0 的接口可选择不 launch 并返回成功；不能构造 grid.x=0 launch。策略保持原接口的空输入行为。

## Grid-Stride 正确模板

### Elementwise

```cpp
__global__ void k(const float* x, float* y, long long n) {
  long long i =
      (long long)blockIdx.x * blockDim.x + threadIdx.x;
  long long stride = (long long)gridDim.x * blockDim.x;
  for (; i < n; i += stride) y[i] = op(x[i]);
}
```

要求：stride>0，乘法在 64-bit，元素独立，无重复写。

### Tiled

```cpp
for (long long tile = blockIdx.x;
     tile < logical_tiles;
     tile += gridDim.x) {
  long long start = tile * TILE;
  long long i = start + threadIdx.x;
  if (i < n) ...;
}
```

如果循环体包含 barrier，外层条件是 block-uniform（只依赖 blockIdx/gridDim/logical_tiles），同一 block threads 执行相同 tile 次数。不要让 `threadIdx` 参与外层是否进入。

### 多维恢复

```cpp
long long bx = tile % gx;
long long q = tile / gx;
long long by = q % gy;
long long bz = q / gy;
```

gx/gy 必须非零；空维在 host 处理。恢复次序必须与原 x-fastest 线性化一致。div/mod 成本可能抵消 flatten，需要基准。

## Persistent 负载均衡

固定 `tile += gridDim.x` 是静态分配，tile 成本不均时产生长尾。允许的动态调度候选通常需要 atomic work queue：

```cpp
__device__ unsigned long long next_tile;

while (true) {
  unsigned long long tile = 0;
  if (threadIdx.x == 0) tile = atomicAdd(&next_tile, 1ull);
  tile = __shfl_sync(0xffffffffu, tile, 0);
  if (tile >= logical_tiles) break;
  // block-uniformly process tile
}
```

这是高风险独立候选：

- queue 初始化/reset。
- 全 block 获取同一 tile。
- break block-uniform。
- atomic contention。
- device symbol/指针生命周期。
- benchmark 包含 reset。

一般优先静态 grid-stride；没有 NCU 长尾证据不引入动态 queue。

## Occupancy 候选计算

运行时：

```cpp
cudaDeviceProp prop{};
CUDA_CHECK(cudaGetDeviceProperties(&prop, device));

int active = 0;
CUDA_CHECK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
    &active, target_kernel<BLOCK>, BLOCK, dynamic_smem));
if (active <= 0) return configuration_error;

long long capacity =
    (long long)prop.multiProcessorCount * active;
long long launch_blocks = min(logical_tiles, capacity);
```

可额外试少量邻域，例如一倍 capacity 与两倍 capacity，以检查多 wave 是否隐藏不均衡；但每项独立测量。occupancy API 未计入数据相关 cache/branch/atomic，不能直接选最优。

若 kernel 使用超过默认 opt-in 阈值的动态 shared，先按平台规则调用并检查适用属性；occupancy API 和实际 launch 使用相同 shared bytes。

## Block 维调整

Grid 优化可调整 block，但不能同时改变 kernel 内 tiling 算法。适合参数化 elementwise/grid-stride：

```text
block ∈ current 的小邻域
grid  = ceil_div(n, block*items)
```

每个 block 候选重新编译、读取 ptxas、correctness/safety/benchmark。Reduction block 改变归约树，应路由 reduce/config 策略，不在 grid 策略直接修改。

## 多 Stream 与并发

目标 wrapper 可能在调用方 stream 上与其他工作并发。单独 kernel benchmark 不等于应用并发性能。保持：

- stream 参数。
- event 记录在同 stream。
- 无新增全局 device queue/状态导致跨 stream 冲突。
- workspace 与 stream 生命周期。

若 persistent kernel 长时间占满所有 SM，可能伤害并发；报告单列“单 kernel latency”与已提供的并发 guardrail。没有应用并发测试时，不声称系统吞吐改善。

## Cooperative Launch

使用 cooperative groups/grid sync 的 kernel 有严格 launch 和 residency 条件；普通 triple-chevron 改写可能破坏语义。识别到 cooperative launch：

- 保留 `cudaLaunchCooperativeKernel`。
- 检查设备支持和最大 cooperative blocks。
- 任何 grid cap都满足全 grid resident 要求。
- 不把普通 persistent 公式直接套用。
- 缺少专门测试时标记不适用。

本 Skill 的常规 modify-grid 不主动引入 cooperative launch。

## 归约/Atomic Grid

改变 block 数会改变每 output 的 partial/atomic 数和浮点顺序。报告：

```json
{
  "logical_tiles": 1000,
  "launch_blocks_before": 1000,
  "launch_blocks_after": 164,
  "tiles_per_block_expected": 6.1,
  "atomic_updates_per_output_before": 1000,
  "atomic_updates_per_output_after": 164,
  "reset_method": "..."
}
```

示例数字是 schema。性能测量包含 atomic 输出初始化，并运行重复一致性和原 tolerance。

## 覆盖测试

为 normal/flatten/grid-stride/persistent 分别构造覆盖计数 debug 候选（仅测试）：每个逻辑 tile 原子增加计数数组，完成后检查每项恰为1。此 debug instrumentation 不进入性能 binary。若无法构建计数测试，至少用带唯一 tile 值的输出验证无遗漏/重复。

测试：

- logical tiles=0、1、grid-1、grid、grid+1。
- 大于一 wave、多 wave、非整数 waves。
- 多维 gx/gy/gz 含1和非整 tile。
- 极大 logical 的 64-bit 恢复。
- tile 成本均匀/不均匀。
- boundary mask。

## 性能与 NCU

比较：

| 指标 | normal | candidate | 解释 |
| --- | ---: | ---: | --- |
| launch blocks | | | 逻辑/物理 |
| waves/SM | | | tail |
| block threads | | | launch |
| registers/thread | | | ptxas/NCU |
| shared/block | | | ptxas/NCU |
| achieved occupancy | | | signal |
| SM/DRAM throughput | | | bottleneck |
| median/p20/p80 | | | 最终决策 |

只在 correctness、安全和 no-regression 门禁通过时 keep。更整齐的 waves 或更高 occupancy 而 latency 未改善时回退。

## 决策示例

### 保留 Normal

```text
decision=revert
reason=persistent median slower; normal grid already supplies multiple waves
output=input.cu
```

### 保留 Flatten

```text
decision=keep
reason=all grid dimensions legal, coverage test passes, same flags benchmark improves beyond threshold
```

### 无目标设备

```text
decision=not_measured
reason=RTX 3090 unavailable
output=input.cu
```

不得把静态合法的 candidate 在 not_measured 情况下输出为最终优化版。
