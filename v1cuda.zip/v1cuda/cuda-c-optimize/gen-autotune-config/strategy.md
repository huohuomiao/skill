# CUDA 外部配置生成与冻结

## 职责

为 CUDA C/C++ kernel 生成有限、可解释的 block/tile/vector/unroll/shared 配置集合；每个配置独立编译、正确性/安全验证和 RTX 3090 benchmark，最后把最佳有效配置冻结到交付源码。目录名中的 autotune 仅作工作流兼容，交付 binary 不依赖运行时自动调优。

## 工作流程

### Step 1：提取配置轴

读取：

- 当前 `input.cu`
- [get-tensor-axis-info.md](./references/get-tensor-axis-info.md)
- `kernel_info.json`
- 全部真实测试 shape/dtype/stride/alignment
- 共享 RTX 3090 平台规则
- ptxas baseline 资源

可调轴：

| 参数 | 适用情况 | 风险 |
| --- | --- | --- |
| block.x/y/z | 所有显式 launch | threads、warp mapping、tail |
| tile M/N/K | tile 或矩阵/邻域 | register/shared、边界 |
| items/thread | streaming/ILP | register、并行度 |
| vector width | 对齐连续地址 | alignment、tail、alias |
| unroll | 小固定循环 | code size、register |
| shared staging | 有复用 | bytes、barrier、bank |
| grid-stride cap | persistent 候选 | 覆盖、负载均衡 |

只包含源码真实支持或本轮可最小改写支持的轴。

### Step 2：构建配置清单

先独立筛选，再小规模组合。默认硬约束：

- 目标 `sm_86`。
- threads/block 合法。
- grid 各维合法。
- dynamic/static shared 初筛合法。
- warp primitive 对 block 和 active mask 合法。
- vector 对齐证据完整。
- tile 能覆盖所有 shape，尾部 predicate 正确。
- 不启用更新架构专属能力。
- 不默认启用 `--use_fast_math`。
- 不用 `-maxrregcount` 隐藏源码 register 问题。

示例清单：

```json
{
  "schema_version": 1,
  "objective": "weighted_median",
  "guardrail": "no_test_case_regression",
  "configs": [
    {"id": "baseline", "block": [256, 1, 1], "items": 1, "vec": 1, "unroll": 1},
    {"id": "b128", "block": [128, 1, 1], "items": 1, "vec": 1, "unroll": 1},
    {"id": "b512", "block": [512, 1, 1], "items": 1, "vec": 1, "unroll": 1}
  ]
}
```

baseline 必须在列表中。候选数量以执行预算为上限；不要生成无界笛卡尔积。

### Step 3：实例化候选

推荐模板：

```cpp
template<int BLOCK, int ITEMS, int VEC, int UNROLL>
__global__ void target_kernel(...);

template<int BLOCK, int ITEMS, int VEC, int UNROLL>
void launch_target(..., cudaStream_t stream) {
  long long work_per_block = (long long)BLOCK * ITEMS * VEC;
  long long logical = ceil_div(n, work_per_block);
  target_kernel<BLOCK, ITEMS, VEC, UNROLL>
      <<<dim3((unsigned)logical), dim3(BLOCK), 0, stream>>>(...);
}
```

每个 candidate 源码选择一个显式实例化。交付版本只保留获胜实例化和必要 fallback，不保留运行时 benchmark 选择逻辑。

### Step 4：公平编译

公共 flags：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  -Xptxas=-v candidate.cu -o candidate
```

配置宏/模板值是实验变量，其他 flags、链接、include 和 host compiler 保持一致。保存：

- 完整 command。
- nvcc stdout/stderr。
- registers/thread。
- static/dynamic shared memory。
- spill stores/loads。
- binary/source hash。

编译失败是候选失败，不能删测试或改 flags 迁就。

### Step 5：Correctness 与 Safety

对每个编译成功候选运行完整测试：

- 所有 shape/dtype/stride 和随机种子。
- 原 atol/rtol。
- 小于 tile、非整 tile、最大合法尺寸。
- vector aligned/fallback。
- CUDA API 与 launch error。
- 涉及 shared/barrier/atomic 时的适用 sanitizer。

任何失败立即淘汰；不测性能。

### Step 6：RTX 3090 Benchmark

- 目标设备身份严格验证。
- 相同 stream、输入和计时区域。
- JIT 不存在，但需排除 context/module 初始化和 cold cache 偏差。
- 固定 warmup/repeat，交错候选次序。
- 记录 median/p20/p80，而非单次最小值。
- 多 shape 的权重和 guardrail 在运行前冻结。
- 观察温度、功耗、其他进程导致的异常；污染轮次作废重测。

没有真实 RTX 3090 时停止在静态有效候选，`decision=not_measured`，最终源码回退 baseline。

### Step 7：选择 Best-so-Far

候选必须满足：

- compile pass
- correctness pass
- safety pass
- 所有关键 shape no regression
- 聚合目标优于 baseline 且超过噪声

排序后若前两名统计区间重叠，选择更接近 baseline、register/shared 更低或源码更简单者。不得把最后执行配置当作获胜配置。

### Step 8：冻结单一配置

输出 `cuda_optimized.cu`：

- kernel 与 wrapper 完整。
- 配置为模板常量/显式 launch。
- correctness 和 benchmark 保留。
- 非必要搜索代码移除。
- 如果需要 shape dispatch，每个分支都必须有独立证据和 fallback；否则只冻结一个稳健配置。
- 报告保存完整候选清单和失败原因。

## 关键禁止项

- 用 occupancy calculator 直接指定“最优”配置而不 benchmark。
- 把其他 GPU 的赢家称为 RTX 3090 最优。
- 只跑成功候选，隐藏编译/精度/安全失败。
- 测完后更改 shape 权重。
- 将 fast math 与 block 搜索混为同一配置轴。
- 无对齐证明搜索 vector width。
- 原子或原地 kernel 在多候选重复运行时不 reset。
- 交付时保留首次运行自动 benchmark，造成生产抖动。

## 输出

当前策略目录生成：

```text
configs.json
candidate_results.json
candidate_<id>/
cuda_optimized.cu
cuda_optimized.md
result.json
```

报告至少包含环境、公共 flags、测试分布、候选表、资源、correctness、安全、性能统计、评分口径、获胜配置和回退条件。

## 配置空间设计细则

### 1. Elementwise / Streaming

候选通常围绕：

```text
BLOCK ∈ {128, 256, 512}
ITEMS ∈ {1, 2, 4}
VEC   ∈ {1, 2, 4}  # 仅对齐得到证明时
```

不要直接取 27 项笛卡尔积。建议分阶段：

1. 固定 ITEMS/VEC 为 baseline，筛 BLOCK。
2. 固定获胜 BLOCK，筛 ITEMS。
3. 有对齐 fast path 时再筛 VEC。
4. 最后只验证少量组合，确认参数交互。

每阶段都保留原 baseline，任一关键 shape 回退即淘汰。小 N 对大 BLOCK/ITEMS 很敏感，应作为 guardrail。

### 2. 二维 Elementwise / Transpose

候选 block 形状必须让连续数据轴映射到 warp 内相邻线程：

```text
(BX, BY) ∈ {(32,4), (32,8), (32,16), (16,16)}
```

这里只是小集合示例；实际候选由目标 shape、shared tile、threads/block 和地址式过滤。若使用 shared transpose，tile 与 block 未必一一相等，应显式记录 cooperative load 的每线程元素数。

检查：

- `BX*BY` 合法。
- warp 在线性 thread id 中如何跨 x/y。
- shared padding 和字节数。
- 边界 tile 的分支与 barrier。
- 输入/输出两侧 coalescing。
- register/spill。

### 3. Reduction

BLOCK 影响 reduce tree 和浮点顺序；候选前过滤：

- block reduction 实现是否支持该 BLOCK。
- partial warp mask 是否正确。
- shared partial 数是否足够。
- reduce_size 与 BLOCK/ITEMS 的覆盖。
- argmax pair、NaN/tie 和 determinism。
- atomic/multi-pass 初始化。

若不同 BLOCK 产生不同但在容差内的值，仍必须保存每个 candidate 的 max error，不只保存 pass 布尔值。

### 4. Matrix/Shared Tile

CUDA C 通用 Skill 不应声称任意 tile 会自动使用 Tensor Core。候选维度可包括 TM/TN/TK、线程布局、每线程 accumulator tile 和 shared padding；但只有源码已实现相应算法，或当前策略能做一个受控最小改写时才生成。

检查：

- 输入 dtype 与目标指令路径。
- global→shared 合并访问。
- shared→register bank conflict。
- `__syncthreads` 次数。
- accumulator register 数。
- K 尾部和 M/N mask。
- TF32/FP16/BF16 精度契约。
- 不使用 RTX 3090 不支持的新架构能力。

### 5. Shape Dispatch

多 shape 明显需要不同配置时，可生成离线 dispatch 表：

```cpp
if (n <= 4096) {
  launch<128, 2>(...);
} else {
  launch<256, 4>(...);
}
```

约束：

1. 分桶规则由公开 shape 特征决定，不依赖隐藏测试。
2. 每个桶有足够测试证据。
3. 边界值两侧均测试。
4. 未知 shape 有稳健 fallback。
5. dispatch host overhead 包含在端到端口径。
6. 表规模保持小；若收益不明确，冻结单一配置。

## 候选构建清单

每个配置生成前建立记录：

```json
{
  "id": "b256_i2",
  "parent": "baseline",
  "single_parameter_family": "items_per_thread",
  "values": {"block_x": 256, "items": 2, "vec": 1, "unroll": 1},
  "compile_defines": ["-DBLOCK=256", "-DITEMS=2"],
  "preconditions": ["scalar aligned path", "grid coverage"],
  "rejection_reason": null
}
```

如果源码模板参数不可由 `-D` 安全替换，生成 candidate 源码的显式实例化；不要用文本全局替换误改无关常量。

## 编译结果解析

从 ptxas 输出记录每个 entry function：

```text
Used N registers, S bytes smem, C bytes cmem
spill stores / spill loads
```

多 kernel binary 不能把辅助 kernel 的资源当成目标 kernel。解析失败时资源字段为 null，并保留原 stderr。资源初筛：

- 编译/launch 超限立即淘汰。
- spill 新增是风险，不一定单独决定淘汰；结合耗时和 NCU。
- registers 降低但性能不变不构成收益。
- shared 增加导致 residency 降低时保留实际证据。

## Correctness 结果矩阵

每配置按 case 输出：

| case | shape | dtype | stride | atol | rtol | max abs | max rel | NaN/Inf | pass |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- | --- |

规则：

- 用户 case 全部保留。
- 非整 tile 和最小/最大边界补充为安全 case，但不代替用户 case。
- 浮点 reduction 记录误差分布。
- 随机输入固定 seed，且 baseline/candidate 使用完全相同 buffer。
- 原地/atomic kernel 每个配置与 repeat 前 reset。
- candidate 不能改 reference。

## 性能结果矩阵

```json
{
  "candidate": "b256_i2",
  "target_verified": true,
  "cases": [
    {
      "case": "large_contiguous",
      "samples": 100,
      "median_ms": 0.0,
      "p20_ms": 0.0,
      "p80_ms": 0.0,
      "baseline_median_ms": 0.0,
      "speedup": 1.0,
      "guardrail_pass": true
    }
  ]
}
```

上面数字仅为 schema，占位结果必须由真实执行替换，未测量用 null。评分不能使用编译时间、occupancy 或带宽估算代替耗时。

## 搜索顺序与缓存

- 以源码哈希、完整 flags、nvcc/host compiler、目标 CC 和配置作为 cache key。
- 不跨 driver/Toolkit/GPU 身份复用性能结果。
- 编译产物可缓存，输入数据和 GPU 状态仍需本轮确认。
- 候选顺序随机/轮换，避免后执行候选因温度固定偏置。
- 若预算中止，best-so-far 只能来自已经完成全部门禁的候选。

## Persistent 配置

若配置轴包含 grid-stride/persistent：

1. normal grid 始终保留为 baseline。
2. 使用 `cudaOccupancyMaxActiveBlocksPerMultiprocessor` 获取候选 cap。
3. 额外测试 cap 的小邻域（例如 1×/2× active capacity）仅在预算允许时。
4. kernel 使用 `gridDim` stride 完整覆盖。
5. 改 BLOCK/shared 后重新计算 occupancy。
6. 输出每候选 logical tiles、launch blocks、waves 和负载不均。

不能在普通 kernel 上只调 launch cap。

## Fast Math 与配置搜索隔离

`--use_fast_math`、特定 `__expf/__fdividef` 或 flush-to-zero 会同时改变多个运算语义，必须作为独立数学实验，不能加入 BLOCK/TILE 配置矩阵。只有数学策略先证明精度和收益后，才能以该数学版本为新的明确 baseline 开启下一轮配置搜索。

## 失败分类

| 类别 | 含义 | 是否继续其它候选 |
| --- | --- | --- |
| invalid_config | 静态硬约束失败 | 是 |
| compile_failed | nvcc/ptxas 失败 | 是，保留 stderr |
| launch_failed | 资源/API 错误 | 是，候选淘汰 |
| accuracy_failed | 原容差不通过 | 是，候选淘汰 |
| safety_failed | sanitizer/race/sync | 是，候选淘汰 |
| performance_regressed | 目标实测回退 | 是 |
| noisy | 无法区分 | 可重测一次，仍 noisy 则淘汰 |
| infrastructure | 环境/worker/tool 错误 | 停止性能搜索 |

基础设施错误后不得把未测候选选为赢家。
