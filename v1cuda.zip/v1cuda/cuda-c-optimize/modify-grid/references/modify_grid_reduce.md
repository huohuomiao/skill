## 跨 Block 归约的 Grid 修改

### 初始两阶段实现

```cpp
partial_reduce<<<grid1, block, smem, stream>>>(x, partial, n);
final_reduce<<<grid2, block, smem, stream>>>(partial, out, grid1.x);
```

改变 `grid1.x` 会改变 partial 长度和第二阶段输入，host 分配、初始化和 launch 都必须同步更新。

### Atomic 候选

```cpp
__global__ void reduce_atomic(const float* x, float* out, long long n) {
  float local = 0.0f;
  for (long long i =
           (long long)blockIdx.x * blockDim.x + threadIdx.x;
       i < n; i += (long long)blockDim.x * gridDim.x)
    local += x[i];

  float block_value = block_reduce_sum(local);
  if (threadIdx.x == 0) atomicAdd(out, block_value);
}
```

必须：

- 在同一 stream 正确初始化 out。
- atomic dtype 在 sm_86 合法。
- 接受浮点累加次序变化并通过原容差。
- 无确定性要求冲突。
- 处理空输入和 identity。
- 实测 atomic contention。

### Persistent Grid

occupancy cap 只控制并发 block；grid-stride loop负责完整输入。不能把 grid 裁小后仍只处理一个 tile/block。

### 验证

- 两阶段与 atomic 分开候选。
- correctness 覆盖非整 block、大输入、极值。
- safety 检查初始化、race、同步。
- 性能同时包含所需初始化和所有 kernel，避免只计最后一阶段。
