# CUDA C/C++ troubleshooting

Use the earliest failing gate and the first root diagnostic. Preserve full commands and raw output in the report before editing.

## Environment and compiler

| Evidence | Likely cause | Action |
| --- | --- | --- |
| `nvcc` not found | Toolkit missing or PATH incomplete | Re-run EnvConfig; do not edit source. |
| unsupported host compiler | Toolkit/host compiler incompatibility | Select a supported compiler in EnvConfig; do not add an undocumented bypass by default. |
| insufficient driver / no CUDA device | driver or Worker environment | Treat as blocked; do not repair kernel. |
| exact device is not RTX 3090 / CC is not 8.6 | wrong target device | Other-GPU run may be labeled diagnostic only; do not declare target validation. |
| unsupported architecture feature | code requires newer SM | Replace with an `sm_86` implementation or explicitly reject the requirement. |

## NVCC and PTXAS

For a compiler cascade, repair the first source-location error and rebuild. Check includes, namespace qualification, kernel/wrapper signatures, templates, and host/device annotations.

PTXAS reports registers, constant memory, stack/local memory, spills, and resource failures. A spill is not automatically a correctness error, but it invalidates unsupported performance claims. A resource overflow may require a smaller tile, fewer simultaneously live values, or less staging; keep semantics fixed and confirm with a rebuild.

Never change `-arch=sm_86` to hide use of a newer feature.

## Runtime and launch

| CUDA result or symptom | Investigation |
| --- | --- |
| `cudaErrorInvalidConfiguration` | zero/oversized grid or block, threads/block product, dynamic shared bytes |
| `cudaErrorInvalidValue` | null pointer, byte count, launch argument, API parameter |
| `cudaErrorLaunchOutOfResources` | registers, shared memory, block size, launch bounds |
| `cudaErrorIllegalAddress` | run memcheck; trace wide index, bound, stride, lifetime |
| `cudaErrorMisalignedAddress` | vector/typed access alignment and byte offset |
| unspecified launch failure | inspect the first checked launch/sync and sanitizer output; do not attribute it to a later API |
| hang/timeout | grid-stride progress, divergent barrier, excessive work, watchdog |

Check the launch immediately and completion separately. Clear neither error blindly nor continue benchmarking after a CUDA context-destroying failure.

## Compute Sanitizer

Run in the order `memcheck → initcheck → racecheck → synccheck`.

### Memcheck

- Map the reported access size, address, thread, block, and source line to a logical index.
- Check both allocation extent and logical extent; padding does not authorize a logically invalid result.
- For a vector access, validate every lane and alignment.
- Fix memcheck errors before trusting other sanitizer output.

### Initcheck

- Identify whether a global-memory value was never initialized by host copy/memset or device write.
- Verify conditional stores cover all output elements.
- Keep poison initialization in tests; do not zero output merely to conceal missing writes.

### Racecheck

- RAW: consumer can read before producer completes.
- WAR: a writer can overwrite before a reader completes.
- WAW: multiple writes are unordered.
- Racecheck focuses on shared memory; absence of a report is not proof against global logical races.

Use a barrier only when all required threads can reach it. Recheck shared indices as a barrier cannot fix two threads intentionally addressing the same slot.

### Synccheck

Inspect divergent block barriers, invalid warp masks, cooperative-groups contracts, and asynchronous-copy pipeline sequencing. For a partial warp, use a participation mask that matches the executing lanes.

## Correctness

First locate the smallest failing case and first wrong logical output. Compare:

1. block/thread-to-output mapping
2. flattened index and stride arithmetic
3. tail predicate and vector lanes
4. initialization and output coverage
5. reduction identity, ordering, and accumulator dtype
6. alias/in-place ordering
7. special values and signed-zero behavior required by the contract

Do not reduce shapes, drop cases, relax tolerance, alter seeds after seeing failure, or copy the CUDA result into the reference.

Floating reductions can differ by order. Use the tolerance frozen by the requirement and reference; if it was never specified, stop and obtain/derive a conservative contract before applying approximate math.

## Performance

Performance is considered only after correctness and safety pass.

- Use `-O3 -DNDEBUG -lineinfo -arch=sm_86` for both baseline and candidate.
- Use CUDA events in the same stream, with warmup and repeated samples.
- Record median and dispersion; interleave baseline/candidate when possible.
- Do not time under Compute Sanitizer or use NCU replay duration for acceptance.
- Inspect PTXAS/NCU for registers, spills, shared memory, occupancy, SM/DRAM throughput, cache, and warp stalls.
- Higher occupancy alone is not proof of higher performance.

If no exact RTX 3090 is available, retain the last verified baseline and label all generated tuning variants unvalidated.
