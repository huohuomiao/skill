# Code 示例：分层 block reduction 的完整 CUDA C++ 程序

该程序对连续 `[rows,cols]` float32 输入按最后一维求和。每个 block 负责一行，先 warp shuffle，再经 shared memory 汇总 warp 结果。

```cpp
#include <cuda_runtime.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <random>
#include <vector>

static bool check(cudaError_t s, const char* e, int line) {
    if (s == cudaSuccess) return true;
    std::fprintf(stderr, "CUDA_ERROR line=%d expr=%s name=%s message=%s\n",
                 line, e, cudaGetErrorName(s), cudaGetErrorString(s));
    return false;
}
#define CHECK(expr) check((expr), #expr, __LINE__)

__device__ __forceinline__ float warp_sum(float v) {
    constexpr unsigned mask = 0xffffffffu;
    v += __shfl_down_sync(mask, v, 16);
    v += __shfl_down_sync(mask, v, 8);
    v += __shfl_down_sync(mask, v, 4);
    v += __shfl_down_sync(mask, v, 2);
    v += __shfl_down_sync(mask, v, 1);
    return v;
}

__global__ void row_sum_kernel(const float* __restrict__ x,
                               float* __restrict__ y,
                               std::int64_t cols) {
    __shared__ float warp_sums[8];
    const std::int64_t row = static_cast<std::int64_t>(blockIdx.x);
    float local = 0.0f;
    for (std::int64_t col = threadIdx.x; col < cols; col += blockDim.x)
        local += x[row * cols + col];
    local = warp_sum(local);
    const unsigned lane = threadIdx.x & 31u;
    const unsigned warp = threadIdx.x >> 5u;
    if (lane == 0) warp_sums[warp] = local;
    __syncthreads();
    if (warp == 0) {
        float total = lane < 8 ? warp_sums[lane] : 0.0f;
        total = warp_sum(total);
        if (lane == 0) y[row] = total;
    }
}

cudaError_t launch_row_sum(const float* x, float* y,
                           std::int64_t rows, std::int64_t cols,
                           cudaStream_t stream) {
    if (rows < 0 || cols < 0) return cudaErrorInvalidValue;
    if (rows == 0) return cudaSuccess;
    if (y == nullptr || (cols > 0 && x == nullptr))
        return cudaErrorInvalidDevicePointer;
    if (static_cast<std::uint64_t>(rows) > std::numeric_limits<unsigned>::max())
        return cudaErrorInvalidConfiguration;
    row_sum_kernel<<<static_cast<unsigned>(rows), 256, 0, stream>>>(x, y, cols);
    return cudaGetLastError();
}

static bool checked_count(std::int64_t rows, std::int64_t cols,
                          std::size_t* count) {
    if (rows < 0 || cols < 0 || count == nullptr) return false;
    const std::uint64_t r = static_cast<std::uint64_t>(rows);
    const std::uint64_t c = static_cast<std::uint64_t>(cols);
    if (r != 0 && c > std::numeric_limits<std::size_t>::max() / r) return false;
    *count = static_cast<std::size_t>(r * c);
    return *count <= std::numeric_limits<std::size_t>::max() / sizeof(float);
}

static void cpu_reference(const std::vector<float>& x, std::vector<float>* y,
                          std::int64_t rows, std::int64_t cols) {
    y->assign(static_cast<std::size_t>(rows), 0.0f);
    for (std::int64_t row = 0; row < rows; ++row) {
        double total = 0.0;
        for (std::int64_t col = 0; col < cols; ++col)
            total += static_cast<double>(x[static_cast<std::size_t>(row * cols + col)]);
        (*y)[static_cast<std::size_t>(row)] = static_cast<float>(total);
    }
}

static bool run_case(std::int64_t rows, std::int64_t cols, unsigned seed) {
    std::size_t count = 0;
    if (!checked_count(rows, cols, &count)) return false;
    if (rows == 0) return launch_row_sum(nullptr, nullptr, rows, cols, 0) == cudaSuccess;
    std::vector<float> x(count), expected, actual(static_cast<std::size_t>(rows));
    std::mt19937 rng(seed);
    std::uniform_real_distribution<float> dist(-1.0f, 1.0f);
    for (float& v : x) v = dist(rng);
    for (std::size_t i = 0; i < x.size(); ++i)
        if ((i & 15u) == 0u) x[i] *= 100.0f;
    cpu_reference(x, &expected, rows, cols);
    float* dx = nullptr;
    float* dy = nullptr;
    cudaStream_t stream = nullptr;
    bool ok = CHECK(cudaStreamCreate(&stream));
    if (count > 0) {
        ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dx), count * sizeof(float)));
        ok = ok && CHECK(cudaMemcpyAsync(dx, x.data(), count * sizeof(float),
                                         cudaMemcpyHostToDevice, stream));
    }
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dy),
                                static_cast<std::size_t>(rows) * sizeof(float)));
    ok = ok && CHECK(launch_row_sum(dx, dy, rows, cols, stream));
    ok = ok && CHECK(cudaStreamSynchronize(stream));
    ok = ok && CHECK(cudaMemcpy(actual.data(), dy,
                                static_cast<std::size_t>(rows) * sizeof(float),
                                cudaMemcpyDeviceToHost));
    double max_abs = 0.0;
    std::size_t bad = actual.size();
    if (ok) {
        const double atol = 1e-5 * std::max<std::int64_t>(1, cols);
        for (std::size_t i = 0; i < actual.size(); ++i) {
            const double diff = std::abs(static_cast<double>(actual[i]) - expected[i]);
            max_abs = std::max(max_abs, diff);
            if (diff > atol + 1e-5 * std::abs(static_cast<double>(expected[i]))) {
                bad = i;
                break;
            }
        }
        ok = bad == actual.size();
    }
    if (!ok && bad != actual.size())
        std::fprintf(stderr, "ACCURACY_FAIL row=%zu expected=%.9g actual=%.9g\n",
                     bad, expected[bad], actual[bad]);
    if (dx) ok = CHECK(cudaFree(dx)) && ok;
    if (dy) ok = CHECK(cudaFree(dy)) && ok;
    if (stream) ok = CHECK(cudaStreamDestroy(stream)) && ok;
    std::printf("CASE_RESULT rows=%lld cols=%lld passed=%s max_abs_error=%.9g\n",
                static_cast<long long>(rows), static_cast<long long>(cols),
                ok ? "true" : "false", max_abs);
    return ok;
}

static bool benchmark() {
    constexpr std::int64_t rows = 8192, cols = 4096;
    constexpr std::size_t input_count = static_cast<std::size_t>(rows * cols);
    constexpr std::size_t in_bytes = input_count * sizeof(float);
    constexpr std::size_t out_bytes = static_cast<std::size_t>(rows) * sizeof(float);
    constexpr int warmup = 20, iterations = 100;
    float* dx = nullptr;
    float* dy = nullptr;
    cudaStream_t stream = nullptr;
    cudaEvent_t start = nullptr, stop = nullptr;
    bool ok = CHECK(cudaStreamCreate(&stream));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dx), in_bytes));
    ok = ok && CHECK(cudaMalloc(reinterpret_cast<void**>(&dy), out_bytes));
    ok = ok && CHECK(cudaMemsetAsync(dx, 0, in_bytes, stream));
    ok = ok && CHECK(cudaEventCreate(&start));
    ok = ok && CHECK(cudaEventCreate(&stop));
    for (int i = 0; ok && i < warmup; ++i)
        ok = CHECK(launch_row_sum(dx, dy, rows, cols, stream));
    ok = ok && CHECK(cudaStreamSynchronize(stream));
    ok = ok && CHECK(cudaEventRecord(start, stream));
    for (int i = 0; ok && i < iterations; ++i)
        ok = CHECK(launch_row_sum(dx, dy, rows, cols, stream));
    ok = ok && CHECK(cudaEventRecord(stop, stream));
    ok = ok && CHECK(cudaEventSynchronize(stop));
    float total_ms = 0.0f;
    ok = ok && CHECK(cudaEventElapsedTime(&total_ms, start, stop));
    if (ok) {
        const double ms = total_ms / iterations;
        const double gbps = (in_bytes + out_bytes) / (ms * 1.0e6);
        std::printf("BENCHMARK_RESULT kernel_ms=%.6f effective_gbps=%.3f warmup=%d iterations=%d\n",
                    ms, gbps, warmup, iterations);
    }
    if (start) ok = CHECK(cudaEventDestroy(start)) && ok;
    if (stop) ok = CHECK(cudaEventDestroy(stop)) && ok;
    if (dx) ok = CHECK(cudaFree(dx)) && ok;
    if (dy) ok = CHECK(cudaFree(dy)) && ok;
    if (stream) ok = CHECK(cudaStreamDestroy(stream)) && ok;
    return ok;
}

int main() {
    cudaDeviceProp prop{};
    if (!CHECK(cudaGetDeviceProperties(&prop, 0))) return 2;
    if (prop.major != 8 || prop.minor != 6) {
        std::fprintf(stderr, "TARGET_MISMATCH name=%s cc=%d.%d expected=8.6\n",
                     prop.name, prop.major, prop.minor);
        return 2;
    }
    const std::int64_t cases[][2] = {
        {0, 7}, {5, 0}, {1, 1}, {7, 31}, {9, 256}, {17, 1003}, {33, 4097}
    };
    for (unsigned i = 0; i < 7; ++i)
        if (!run_case(cases[i][0], cases[i][1], 20260813u + i)) return 1;
    if (!benchmark()) return 1;
    std::puts("FINAL_RESULT accuracy_pass=true benchmark_pass=true fast_math=false");
    return 0;
}
```

构建命令：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 reduce_sum.cu -o reduce_sum
```

该 block 固定 256 线程，所以每个 warp 的 32 lane 都执行同一 shuffle 序列，full mask 合法。正式评审应运行 memcheck、racecheck、synccheck 和 initcheck；任何 sanitizer 错误都使候选失败。
