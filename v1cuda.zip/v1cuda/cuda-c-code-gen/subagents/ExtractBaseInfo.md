# ExtractBaseInfo

## 任务

把 `requirement.md` 转换为严格、可机读的 `step1_base_info.json`。本阶段只规范化事实，不选择 CUDA grid/block、不生成代码、不改变用户数值合同。

## 输入

- `requirement_path`
- `output_path`：固定为 `{output_dir}/KernelGen/step1_base_info.json`

完整读取 requirement，尤其是数学合同、接口、shape/stride、数值规则、测试用例、已有实现追踪和未决问题。

## 抽取顺序

1. 确认算子名、来源、目标 GPU/架构和环境状态。
2. 建立所有参数清单；区分 input、output、inout、scalar、shape、stride、stream。
3. 标准化 C/C++ 类型和逻辑 dtype，不把 `const float*` 与 `float*` 混为同一权限。
4. 记录每个 tensor 的符号 shape、元素 stride、layout、alignment 和 aliasing。
5. 将数学公式拆为逐元素域、归约域、广播关系和输出写入规则。
6. 记录累加 dtype、容差、NaN/Inf、舍入、确定性和 fast-math 许可。
7. 对齐 correctness/performance 测试矩阵。
8. 如有已有 CUDA 源码，抽取 kernel、wrapper、launch、同步和已知风险，但不把当前实现当作唯一设计。
9. 检查 blocking questions；非空时标记 `ready_for_mapping=false`。

## JSON Schema

```json
{
  "schema_version": 1,
  "operator": {
    "name": "affine_relu",
    "summary": "y[i] = max(a*x[i] + b, 0)",
    "input_kind": "natural_language",
    "source_path": null
  },
  "target": {
    "gpu": "NVIDIA GeForce RTX 3090",
    "compute_capability": "8.6",
    "arch": "sm_86",
    "execution_backend": "local"
  },
  "interface": {
    "wrapper_name": "launch_affine_relu",
    "return_type": "cudaError_t",
    "stream_parameter": "stream",
    "parameters": [
      {
        "name": "x",
        "role": "input",
        "c_type": "const float*",
        "dtype": "float32",
        "symbolic_shape": ["N"],
        "strides": [1],
        "layout": "contiguous",
        "alignment_bytes": null,
        "nullable": false,
        "aliasing": "may_exactly_alias_y"
      },
      {
        "name": "y",
        "role": "output",
        "c_type": "float*",
        "dtype": "float32",
        "symbolic_shape": ["N"],
        "strides": [1],
        "layout": "contiguous",
        "alignment_bytes": null,
        "nullable": false,
        "aliasing": "may_exactly_alias_x"
      },
      {
        "name": "n",
        "role": "shape",
        "c_type": "std::int64_t",
        "value_domain": "n >= 0"
      },
      {
        "name": "a",
        "role": "scalar",
        "c_type": "float"
      },
      {
        "name": "b",
        "role": "scalar",
        "c_type": "float"
      },
      {
        "name": "stream",
        "role": "stream",
        "c_type": "cudaStream_t"
      }
    ],
    "zero_size_behavior": "return cudaSuccess without launching"
  },
  "math": {
    "iteration_domain": ["0 <= i < N"],
    "expression": "y[i] = max(a * x[i] + b, 0.0f)",
    "reduction_axes": [],
    "broadcasts": ["a and b are scalar"],
    "write_multiplicity": "exactly_once",
    "empty_reduction_identity": null
  },
  "numerics": {
    "input_dtype": "float32",
    "accumulation_dtype": "float32",
    "output_dtype": "float32",
    "atol": 1e-6,
    "rtol": 1e-6,
    "nan_policy": "propagate through arithmetic; max behavior follows contract",
    "inf_policy": "IEEE",
    "determinism": "required",
    "fast_math_allowed": false
  },
  "tests": {
    "correctness": [
      {
        "id": "C01",
        "symbols": {"N": 1},
        "dtypes": {"x": "float32"},
        "layouts": {"x": "contiguous", "y": "contiguous"},
        "values": "fixed_edge_values",
        "purpose": "minimum"
      },
      {
        "id": "C02",
        "symbols": {"N": 257},
        "dtypes": {"x": "float32"},
        "layouts": {"x": "contiguous", "y": "contiguous"},
        "values": "seeded_random",
        "purpose": "non_multiple_tail"
      }
    ],
    "performance": [
      {
        "id": "P01",
        "symbols": {"N": 16777216},
        "dtypes": {"x": "float32"},
        "layouts": {"x": "contiguous", "y": "contiguous"}
      }
    ],
    "seed": 20260813
  },
  "existing_cuda": {
    "present": false,
    "kernels": [],
    "launches": [],
    "synchronization": [],
    "risks": []
  },
  "build": {
    "language_standard": "c++17",
    "default_flags": ["-std=c++17", "-O3", "-DNDEBUG", "-lineinfo", "-arch=sm_86"],
    "libraries": [],
    "fast_math_default": false
  },
  "assumptions": [],
  "blocking_questions": [],
  "ready_for_mapping": true
}
```

示例字段展示结构，不得复制示例值覆盖真实需求。

## 参数规则

### 指针与 const

- 只读输入使用 `const T*`。
- 输出或 inout 使用 `T*`。
- 指针是 host 还是 device 由 wrapper 合同说明；默认 launcher 接收 device pointer。
- `restrict` 不能凭空添加。只有 aliasing 合同保证不重叠时，后续代码阶段才可使用 `__restrict__`。

### shape 和 stride

- 用符号字符串保存 shape，例如 `M`、`N`、`K`。
- stride 以元素为单位；若需求给的是字节 stride，保留原单位并显式标记。
- 乘积可能超过 32 位时，保留 64 位索引要求。
- 零维、零长度和负值是否合法必须明确。

### dtype

不要仅从变量名猜 dtype。将接口类型和逻辑 dtype 同时保存：

| C/C++ 类型 | dtype | 注意 |
|---|---|---|
| `float` | float32 | IEEE 特殊值 |
| `double` | float64 | RTX 3090 FP64 吞吐较低，但语义优先 |
| `__half` | float16 | 记录运算/累加是否提升为 float |
| `__nv_bfloat16` | bfloat16 | 记录所需 header 与架构 |
| `std::int32_t` | int32 | 明确溢出语义 |
| `std::int64_t` | int64 | 适合大索引/计数 |

### 标量

所有标量必须有类型和值域。例如除数要说明能否为 0，epsilon 要说明是否非负。没有固定值时不要写虚构默认值；保留为 runtime parameter。

## 数学结构分类

`math` 可增加以下分类字段，便于后续 mapping：

```json
{
  "pattern": "elementwise | reduction | transpose | gather | scatter | stencil | matmul | composite",
  "parallel_axes": ["M"],
  "serial_or_reduction_axes": ["K"],
  "output_axes": ["M"],
  "read_footprints": {
    "x": "x[m*K + k] for k in [0,K)"
  }
}
```

scatter 或多线程写同一地址时，`write_multiplicity` 不能写 `exactly_once`；必须说明 atomic、分段唯一性或未解决冲突。

## 测试矩阵一致性

对每个 test id：

- 所有符号 shape 参数都有值。
- 每个必需 tensor 有 dtype/layout。
- stride 与 shape 的 rank 一致。
- 值模式可由 C++ harness 构造。
- performance case 不替代 correctness 的尾部/特殊值用例。

不要把 JSON 写成带注释的伪 JSON。所有数值、布尔和 null 必须符合标准 JSON。

## 已有 CUDA 源码字段

如果 requirement 指向 `original_code.cu`，补充：

```json
{
  "existing_cuda": {
    "present": true,
    "source_path": ".../Extractor/original_code.cu",
    "kernels": [
      {
        "name": "op_kernel",
        "qualifier": "__global__",
        "parameters": ["..."],
        "index_builtins": ["blockIdx.x", "blockDim.x", "threadIdx.x"],
        "shared_memory": "none",
        "barriers": [],
        "atomics": []
      }
    ],
    "launches": [
      {
        "kernel": "op_kernel",
        "grid_expression": "(n + threads - 1) / threads",
        "block_expression": "threads",
        "dynamic_shared_bytes": "0",
        "stream": "stream"
      }
    ],
    "risks": ["..."]
  }
}
```

源码无法证明的 alignment、aliasing 或数值承诺保持 null/unspecified。

## 验证

输出前逐项检查：

- JSON 能被标准 parser 解析。
- `schema_version`、`operator`、`target`、`interface`、`math`、`numerics`、`tests`、`build` 均存在。
- 每个参数名唯一，role 与 C type 不冲突。
- 每个输出都在数学表达式中被定义。
- reduction 有 axis、identity 与 accumulation dtype。
- test case 的符号/类型/layout 完整。
- `fast_math_default=false`。
- blocking questions 非空时 `ready_for_mapping=false`。
- 没有 grid、block 或向量宽度等后续阶段决策混入事实层。

## 失败处理

如果 requirement 关键信息缺失，仍可输出 JSON，但必须：

```json
{
  "blocking_questions": [
    "K=0 时 reduction 输出是什么？"
  ],
  "ready_for_mapping": false
}
```

不得用示例或经验值悄悄补足会改变语义的信息。调用方应回到 Extractor/用户确认后重新运行本步骤。
