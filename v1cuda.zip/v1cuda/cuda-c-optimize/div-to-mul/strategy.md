# Div-to-Mul：CUDA 除法候选

## 功能

只对有明确语义和性能证据的除法生成一个 reciprocal/multiply 候选。整数除法、浮点除法、编译期常量除数和 CUDA fast intrinsic 必须分开处理。

## Step 1：扫描与分类

记录每个热路径除法：

| 类别 | 示例 | 默认动作 |
| --- | --- | --- |
| 整数常量除数 | `i / 32` | 保持；nvcc 通常自行强度削减 |
| 整数 runtime 除数 | `i / n` | 保持，除非有严格等价算法 |
| 浮点常量除数 | `x / 3.0f` | 先查看生成代码 |
| 浮点 runtime 除数 | `x / denom` | 可尝试预计算 reciprocal |
| host 不变量 | 每线程重复同一 denom | 可在 host 或 kernel 外层计算 |
| fast intrinsic | `__fdividef` / `__frcp_rn` | 仅近似预算明确时 |

## Step 2：语义门禁

在替换 `x / d` 为 `x * rcp` 前确认：

- 除数不为 0，或 ±0/Inf/NaN 行为与契约一致。
- 舍入差异落在用户原始容差内。
- `d` 对整个复用范围确实不变。
- 不改变整数截断、负数除法或余数语义。
- 不把 double 静默降成 float。
- fast intrinsic 只用于明确允许近似的 FP32。
- 编译器没有已经生成等价指令。

候选示例：

```cpp
float inv = 1.0f / denom;
#pragma unroll
for (int k = 0; k < ITEMS; ++k)
  out[k] = value[k] * inv;
```

若 reciprocal 本身每次只使用一次，替换通常没有依据。

## Step 3：验证

1. 只改变这一处除法。
2. 相同 flags 编译，记录 PTX/SASS 或 NCU 指令证据。
3. correctness 覆盖普通值、极小/极大除数、±0、Inf、NaN 和 subnormal（契约适用时）。
4. 不放宽 atol/rtol。
5. RTX 3090 公平 benchmark 的 median 未提升或落在噪声内时回退。
6. fast 候选性能提升但精度失败时仍回退。

输出 `cuda_optimized.cu` 与完整 keep/revert 报告。禁止把“乘法一般比除法快”当作结果。
