#!/usr/bin/env python3
"""Route shared Nsight Compute JSON to one conservative CUDA-C strategy.

NCU metrics select the next experiment; they never prove speedup. Final
keep/revert decisions remain with the unchanged CUDA Event benchmark.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


RTX_3090 = re.compile(r"^(?:NVIDIA\s+)?GeForce\s+RTX\s+3090$", re.IGNORECASE)


@dataclass(frozen=True)
class Candidate:
    strategy: str
    priority: int
    evidence: tuple[str, ...]
    action: str
    risk: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "strategy": self.strategy,
            "priority": self.priority,
            "evidence": list(self.evidence),
            "action": self.action,
            "risk": self.risk,
        }


def finite_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("top-level JSON must be an object")
    return data


def require_target(data: dict[str, Any]) -> dict[str, Any]:
    env = data.get("environment", {})
    if not isinstance(env, dict):
        raise ValueError("profile environment must be an object")
    name = str(env.get("gpu_name", "")).strip()
    cc = str(env.get("compute_capability", "")).strip()
    operating_system = str(env.get("operating_system", "")).strip()
    sm_count = finite_number(env.get("multiprocessor_count"))
    verified = env.get("target_verified")

    if operating_system != "Linux":
        raise ValueError(f"profile does not identify Linux: {operating_system or 'missing'}")
    if not name or not RTX_3090.fullmatch(" ".join(name.split())):
        raise ValueError(f"profile does not identify an exact RTX 3090: {name or 'missing'}")
    if sm_count != 82:
        raise ValueError(f"profile does not identify 82 SMs: {sm_count if sm_count is not None else 'missing'}")
    if cc not in {"8.6", "86", "sm_86"}:
        raise ValueError(f"profile does not identify compute capability 8.6: {cc or 'missing'}")
    if verified is not True:
        raise ValueError("Linux / RTX 3090 identity is not explicitly verified")
    return env


def get_kernels(data: dict[str, Any]) -> list[dict[str, Any]]:
    rows = data.get("kernels")
    if not isinstance(rows, list):
        raise ValueError("JSON must contain a kernels list")
    kernels = [row for row in rows if isinstance(row, dict)]
    if not kernels:
        raise ValueError("kernels list is empty")
    return kernels


def select_kernel(
    kernels: list[dict[str, Any]], requested: str | None
) -> dict[str, Any]:
    if requested:
        exact = [k for k in kernels if str(k.get("kernel_name", "")) == requested]
        if len(exact) == 1:
            return exact[0]
        if not exact:
            names = ", ".join(str(k.get("kernel_name", "?")) for k in kernels)
            raise ValueError(f"kernel {requested!r} not found; available: {names}")
        raise ValueError(f"kernel {requested!r} is not unique")
    if len(kernels) != 1:
        names = ", ".join(str(k.get("kernel_name", "?")) for k in kernels)
        raise ValueError(
            "multiple kernels were profiled; pass --kernel-name: " + names
        )
    return kernels[0]


def value(metrics: dict[str, Any], name: str) -> float | None:
    return finite_number(metrics.get(name))


def maybe_add(
    output: list[Candidate],
    condition: bool,
    strategy: str,
    priority: int,
    evidence: Iterable[str],
    action: str,
    risk: str,
) -> None:
    if condition:
        output.append(
            Candidate(
                strategy,
                priority,
                tuple(evidence),
                action,
                risk,
            )
        )


def derive_candidates(kernel: dict[str, Any]) -> list[Candidate]:
    metrics = kernel.get("metrics", {})
    if not isinstance(metrics, dict):
        metrics = {}

    registers = value(metrics, "registers_per_thread")
    shared = value(metrics, "shared_memory_per_block_bytes")
    achieved = value(metrics, "achieved_occupancy_percent")
    theoretical = value(metrics, "theoretical_occupancy_percent")
    waves = value(metrics, "waves_per_sm")
    sm = value(metrics, "sm_throughput_percent")
    dram = value(metrics, "dram_throughput_percent")
    grid = value(metrics, "grid_blocks")
    block = value(metrics, "block_threads")
    output: list[Candidate] = []

    resource_evidence: list[str] = []
    if registers is not None:
        resource_evidence.append(f"registers/thread={registers:.0f}")
    if shared is not None:
        resource_evidence.append(f"shared/block={shared / 1024:.1f} KiB")
    if theoretical is not None:
        resource_evidence.append(f"theoretical occupancy={theoretical:.1f}%")
    maybe_add(
        output,
        (registers is not None and registers >= 128)
        or (shared is not None and shared > 48 * 1024)
        or (theoretical is not None and theoretical < 50),
        "config-tuner",
        90,
        resource_evidence or ["resource limiter reported"],
        "compile a small neighborhood of lower tile/items/unroll/shared candidates",
        "lower resources can also lower ILP or reuse; benchmark every candidate",
    )

    maybe_add(
        output,
        achieved is not None
        and theoretical is not None
        and theoretical - achieved >= 20,
        "config-tuner",
        75,
        (
            f"achieved occupancy={achieved:.1f}%",
            f"theoretical occupancy={theoretical:.1f}%",
        ),
        "inspect stalls before changing block, tile or unroll",
        "occupancy is a signal, not the optimization objective",
    )

    maybe_add(
        output,
        dram is not None and dram >= 70 and (sm is None or sm < dram - 10),
        "retiling",
        80,
        (
            f"DRAM throughput={dram:.1f}%",
            "SM throughput unavailable"
            if sm is None
            else f"SM throughput={sm:.1f}%",
        ),
        "inspect lane addresses; test coalescing, proven vector access, or reuse",
        "shared staging without reuse and unproven vector alignment are unsafe",
    )

    maybe_add(
        output,
        sm is not None and sm >= 70 and (dram is None or sm > dram + 10),
        "config-tuner",
        65,
        (
            f"SM throughput={sm:.1f}%",
            "DRAM throughput unavailable"
            if dram is None
            else f"DRAM throughput={dram:.1f}%",
        ),
        "inspect instruction mix, dependency stalls, unroll and per-thread work",
        "do not enable fast math in a config-only experiment",
    )

    maybe_add(
        output,
        waves is not None and (waves < 1.0 or abs(waves - round(waves)) >= 0.15),
        "modify-grid",
        70,
        (
            f"waves/SM={waves:.2f}",
            "grid unavailable" if grid is None else f"grid blocks={grid:.0f}",
            "block unavailable" if block is None else f"block threads={block:.0f}",
        ),
        "compare normal launch choices; persistent needs grid-stride coverage",
        "cropping a normal grid to SM count loses work",
    )

    maybe_add(
        output,
        sm is not None and dram is not None and sm < 40 and dram < 40,
        "index-computation-simplify",
        50,
        (f"SM throughput={sm:.1f}%", f"DRAM throughput={dram:.1f}%"),
        "inspect small launch, serialization, divergence and integer address work",
        "low throughput alone does not prove index arithmetic is the cause",
    )

    upstream = kernel.get("suggestions", [])
    if isinstance(upstream, list):
        for item in upstream:
            if not isinstance(item, dict):
                continue
            evidence = str(item.get("evidence", "")).strip()
            action = str(item.get("action", "")).strip()
            joined = (evidence + " " + action).casefold()
            if "atomic" in joined or "barrier" in joined or "reduction" in joined:
                output.append(
                    Candidate(
                        "reduce-opt",
                        85,
                        (evidence or "shared analyzer reduction signal",),
                        action or "inspect warp/block reduction and contention",
                        "preserve order, mask, barrier and determinism semantics",
                    )
                )
            elif "division" in joined or "divide" in joined:
                output.append(
                    Candidate(
                        "div-to-mul",
                        40,
                        (evidence or "shared analyzer division signal",),
                        action or "inspect repeated runtime floating-point division",
                        "integer and IEEE division cannot be mechanically replaced",
                    )
                )
            elif "math" in joined or "special function" in joined:
                output.append(
                    Candidate(
                        "libdevice-opt",
                        35,
                        (evidence or "shared analyzer math signal",),
                        action or "compare one CUDA math/intrinsic candidate",
                        "fast intrinsics require an explicit approximation budget",
                    )
                )

    best: dict[str, Candidate] = {}
    for candidate in output:
        current = best.get(candidate.strategy)
        if current is None or candidate.priority > current.priority:
            best[candidate.strategy] = candidate
    return sorted(best.values(), key=lambda item: (-item.priority, item.strategy))


def make_report(
    kernel: dict[str, Any],
    candidates: list[Candidate],
    environment: dict[str, Any],
    source: Path,
) -> tuple[dict[str, Any], str]:
    selected = candidates[0] if candidates else Candidate(
        "none",
        0,
        ("no sufficiently specific bottleneck was identified",),
        "stop deep optimization and inspect the full NCU report",
        "forcing a rewrite would create an unsupported guess",
    )
    result = {
        "schema_version": 1,
        "source": str(source.resolve()),
        "environment": environment,
        "kernel_name": kernel.get("kernel_name"),
        "selected_strategy": selected.strategy,
        "selected": selected.as_dict(),
        "candidates": [item.as_dict() for item in candidates],
        "performance_claim": False,
        "decision_scope": (
            "NCU triage only; keep/revert requires the unchanged CUDA Event "
            "benchmark on a verified RTX 3090"
        ),
    }

    lines = [
        "# CUDA C/C++ NCU 策略路由",
        "",
        f"- source: {result['source']}",
        f"- kernel: {result['kernel_name']}",
        f"- selected_strategy: {selected.strategy}",
        "- performance_claim: false",
        "",
        "## 目标环境",
        "",
        f"- operating_system: {environment.get('operating_system')}",
        f"- gpu_name: {environment.get('gpu_name')}",
        f"- gpu_uuid: {environment.get('gpu_uuid')}",
        f"- compute_capability: {environment.get('compute_capability')}",
        f"- multiprocessor_count: {environment.get('multiprocessor_count')}",
        f"- target_verified: {str(environment.get('target_verified')).lower()}",
        "",
    ]
    lines.extend(["## 选择证据", ""])
    lines.extend(f"- {item}" for item in selected.evidence)
    lines.extend(
        [
            "",
            "## 单一下一步",
            "",
            f"- action: {selected.action}",
            f"- risk: {selected.risk}",
            "",
            "## 候选优先级",
            "",
            "| priority | strategy | evidence |",
            "| ---: | --- | --- |",
        ]
    )
    for item in candidates:
        evidence = "; ".join(item.evidence).replace("|", "/")
        lines.append(f"| {item.priority} | {item.strategy} | {evidence} |")
    if not candidates:
        lines.append("| 0 | none | no specific route |")
    lines.extend(
        [
            "",
            "> 本报告只选择下一项实验，不证明性能提升。最终版本必须通过相同",
            "> nvcc flags、输入、stream、warmup、repeat 的 RTX 3090 CUDA Event",
            "> correctness+safety+no-regression 门禁。",
            "",
        ]
    )
    return result, "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary_json", type=Path)
    parser.add_argument("--kernel-name")
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--markdown-out", type=Path)
    args = parser.parse_args()

    try:
        data = load_json(args.summary_json)
        environment = require_target(data)
        kernel = select_kernel(get_kernels(data), args.kernel_name)
        candidates = derive_candidates(kernel)
        result, markdown = make_report(kernel, candidates, environment, args.summary_json)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if args.json_out:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    if args.markdown_out:
        args.markdown_out.parent.mkdir(parents=True, exist_ok=True)
        args.markdown_out.write_text(markdown, encoding="utf-8")
    if not args.json_out and not args.markdown_out:
        print(markdown, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
