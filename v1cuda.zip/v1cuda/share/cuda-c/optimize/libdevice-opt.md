# CUDA Device Math / libdevice 优化策略（RTX 3090）

目标：只保留有 CUDA Math API 依据、满足用户数值契约、并在 RTX 3090 上实测不回退的数学替换。CUDA C++ 通常直接调用 device math 或 intrinsic，由 `nvcc` 降低到硬件指令、编译器实现或 NVVM libdevice；不要手写内部 `__nv_*` 符号。

执行前读取：

- `share/cuda-c/references/platform-rules.md`
- `share/cuda-c/references/libdevice.md`
- 目标项目的 correctness、误差阈值、build flags 和 benchmark 入口

## 1. 不可违反的边界

1. 目标代码必须是 CUDA C/C++：`.cu`、`__global__` kernel、CUDA Runtime launcher；禁止残留 Triton import、`tl.*` 或 MLU 扩展。
2. 只调用当前 Toolkit CUDA Math API/头文件实际存在的函数。禁止臆造 `__fast_gelu`、`__fast_silu`、`__fast_sigmoid`、`__fast_sqrt` 或 `__ultra_*`。
3. 不把 `expf/logf/sqrtf/sinf/cosf` 机械替换为 intrinsic。先证明语义允许，再比较生成代码、误差和性能。
4. `__expf` 等快速 intrinsic 是 FP32 近似候选，不是精确函数别名。用户未允许近似、没有误差预算或未测试特殊值时不得使用。
5. FP16/BF16 输入的转换与累加类型由接口决定；不得静默引入 double，也不得用 FP32 结果掩盖要求逐步半精度舍入的契约。
6. RTX 3090 无原生 FP8 Tensor Core。数学函数替换不能绕过该硬件门禁。
7. 默认 build 不含 `--use_fast_math`。若评估该 flag，必须生成独立 binary 并披露它改变的全部数值模式。

## 2. 冻结 baseline

修改前保存完整 `.cu`、build 命令、设备/编译器信息、输入 shape/dtype/stride/seed、精度阈值、CUDA Event 性能分布以及 ptxas/NCU 资源。baseline 必须同时包含 launcher、reference、correctness 和 benchmark。

可复现 baseline 示例：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  -Xptxas=-v operator.cu -o operator_baseline
```

同轮比较固定输入、stream、同步和设备。温度、boost 或后台负载明显漂移时标记该轮无效，不挑选最有利单次结果。

## 3. 候选 A：数值稳定的专用函数

这些替换有明确数学目的，但仍需实测；收益可能是精度改善而非速度。

| 原模式 | CUDA 候选 | 主要目的 | 必测点 |
| --- | --- | --- | --- |
| `logf(1.0f + x)` | `log1pf(x)` | 小 `x` 避免相消 | 0 邻域、`x=-1`、`x<-1` |
| `expf(x) - 1.0f` | `expm1f(x)` | 小 `x` 避免相消 | 0 邻域、overflow/underflow |
| `1.0f - erff(x)` | `erfcf(x)` | 正尾部避免相消 | ±large、NaN/Inf |
| `sinf(pi * x)` | `sinpif(x)` | argument reduction | integer/half-integer/large `x` |
| `cosf(pi * x)` | `cospif(x)` | argument reduction | integer/half-integer/large `x` |
| `sqrtf(x*x + y*y)` | `hypotf(x, y)` | 降低 overflow/underflow | 极大/极小/0/Inf |
| `powf(x, 1.0f/3.0f)` | `cbrtf(x)` | 保留负数实根 | 负数、±0、极值 |

先确认原接口的 NaN、rounding 和异常值语义允许替换。若稳定函数更准确但略慢，应由用户的精度优先级决定，不能谎称性能优化。

## 4. 候选 B：缺失的特殊函数

当普通表达式没有合适实现时，可使用当前 Toolkit 确认存在的特殊函数，例如 `atan2f`、`erfcf`、`erfinvf`、`normcdff`、`lgammaf`、`j0f`、`ldexpf`、`fmodf`。这属于实现选择，不自动代表优化；用可信 reference 验证 domain、pole、tail 和特殊值，最终以用户接口契约为准。

## 5. 候选 C：局部快速 FP32 intrinsic

只有三项同时成立才尝试：

1. 需求明确允许近似，并在修改前确定 `rtol`/`atol`/ULP 预算。
2. 输入 domain 有界，测试包含生产分布与 adversarial 边界。
3. 当前 CUDA Math API 和 `sm_86` 编译确认目标 intrinsic 存在。

常见候选：

```cpp
__sinf(x);        __cosf(x);       __tanf(x);
__expf(x);        __exp10f(x);
__logf(x);        __log2f(x);      __log10f(x);
__powf(x, y);     __fdividef(x, y);
```

一次只替换一个表达式。例如：

```cpp
// baseline
float y = logf(x);

// candidate：仅在 FP32 近似预算明确时
float y = __logf(x);
```

检查 PTX/SASS，确认候选确实改变目标指令；若编译器已生成相同路径，则不保留增加认知负担的源码改动。不得从函数命名规律推造不存在的 intrinsic。

## 6. 候选 D：全局 fast-math build

仅当项目允许整个 translation unit 改变数值模式时，构建独立候选：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  --use_fast_math operator.cu -o operator_fast_math
```

`--use_fast_math` 会联动 FTZ、单精度除法/平方根精度和超越函数 lowering，不是局部开关。对 translation unit 中所有受影响 kernel 执行完整 correctness，覆盖 subnormal、NaN/Inf 和 signed zero，并报告完整 flags。只有一个热点允许近似时优先局部 intrinsic。`--ftz`、`--prec-div`、`--prec-sqrt`、`--fmad` 也必须一次只改变一个。

## 7. 候选 E：明确舍入与 FMA

需要可证明的定向舍入或 nearest rounding 时，可评估：

- `__fadd_*`、`__fmul_*`、`__fdiv_*`
- `__frcp_*`、`__fsqrt_*`
- `__fmaf_*`

后缀为 `rn/rz/rd/ru`。这些候选的主要目标是语义，不是速度。

- `a*b+c` 与 `fmaf(a,b,c)` 的舍入次数不同，数值可能不同。
- 编译器默认可能 contraction；接口要求禁止或强制 FMA 时，同时控制 `--fmad` 并检查 SASS。
- directed rounding 可能阻碍优化。语义必需时可接受性能下降，但报告必须说明。

## 8. 实施流程

### 8.1 扫描和排序

1. 找出普通 math、复合失稳表达式、已有 intrinsic、隐式 double promotion 和 build flags。
2. 先识别较长稳定模式（如 `logf(1+x)`），再考虑内部单函数；避免提前改写子表达式。
3. 每轮只选一个候选，记录位置、原语义、目标 API、dtype/domain、预期收益和回退条件。
4. 若没有数值或性能假设，不为产生 diff 而替换。

### 8.2 最小修改

仅加入需要的 CUDA header 并替换目标表达式，不同时改 block、grid、tile、unroll、shared memory 或布局；每个候选维持可独立回退。

### 8.3 编译和静态证据

1. 使用与 baseline 相同的 `nvcc`、host compiler、`-arch=sm_86` 和其他 flags。
2. 保存 stdout/stderr、退出码和 `-Xptxas=-v` 资源信息。
3. 用 `cuobjdump --dump-sass` 或 `nvdisasm` 检查目标函数的实际 lowering；函数名变化不等于指令变化。
4. 若编译失败、符号/overload 不存在或资源显著恶化，立即回退该候选。

### 8.4 correctness 门禁

覆盖生产 shape/dtype/stride、非整 block、±0、正常数/subnormal 边界、最大有限值、NaN/±Inf、函数定义域和 overflow/underflow 邻域，并加入随机与真实分布。输出 max absolute/relative error、必要时 ULP、失败样本和预设阈值；不得事后放宽。

### 8.5 sanitizer 门禁

依次运行 Compute Sanitizer 的 `memcheck`、`initcheck`、`racecheck`、`synccheck`，保存真实命令和退出码。数学替换可能改变分支或执行路径，不能跳过。

### 8.6 性能门禁

1. baseline/candidate 分别 warmup，随后交错执行以降低温度和 boost 漂移。
2. 用 CUDA Event 测同一 stream 的 kernel time；端到端时间另行记录。
3. 报告 median 和分位数，不用单次最小值。
4. 短 kernel 可在一次计时中重复多次，但两边循环、同步和状态恢复必须相同。
5. 用 NCU 确认 instruction/throughput 改变，并观察 registers、spill、occupancy 和 memory workload。

默认保留条件：correctness 与 sanitizer 全部通过，且 candidate median 不慢于 baseline。若用户要求显著收益，可在运行前固定如 `candidate_median <= 0.98 * baseline_median`；不得看到结果后修改门槛。

## 9. 回退条件

任一情况发生即只回退当前候选：

- API/overload 在当前 Toolkit 不存在，或 `sm_86` 编译/link/launch 失败。
- 数值、特殊值、domain 或 sanitizer 不合格。
- 性能回退，或收益落在测量噪声内且代码复杂度增加。
- register spill、shared memory 或 occupancy 恶化抵消收益。
- fast-math 影响到不允许改变语义的其他函数。

保留 baseline、命令和失败证据，继续评估下一个独立候选。所有候选失败时，最终输出必须保持原实现。

## 10. 结果格式

每个候选输出一行决策：

| 字段 | 内容 |
| --- | --- |
| location | 文件、kernel、表达式 |
| baseline / candidate | 精确代码或 build 差异 |
| dtype/domain | 实际输入范围 |
| API evidence | Toolkit 版本、CUDA Math symbol/文档 |
| accuracy | abs/rel/ULP 与预设阈值 |
| sanitizer | 四个工具的命令与状态 |
| performance | median、p20/p80、speedup |
| resources | registers/shared/spills/occupancy |
| decision | keep/revert 与原因 |

最终文件仍包含完整 kernel、launcher、correctness 与 benchmark。不要为了保留修改而留下无收益替换。

## 官方依据

- CUDA Math API：<https://docs.nvidia.com/cuda/cuda-math-api/>
- CUDA C++ Programming Guide：<https://docs.nvidia.com/cuda/cuda-c-programming-guide/>
- NVVM libdevice User's Guide：<https://docs.nvidia.com/cuda/libdevice-users-guide/>
- NVCC Options：<https://docs.nvidia.com/cuda/cuda-compiler-driver-nvcc/#nvcc-command-options>
- Compute Sanitizer：<https://docs.nvidia.com/compute-sanitizer/ComputeSanitizer/>
- Nsight Compute CLI：<https://docs.nvidia.com/nsight-compute/NsightComputeCli/>
