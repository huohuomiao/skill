## 情况 D：固定单 Block / 小 Grid

### 可疑代码

```cpp
kernel<<<1, 256, 0, stream>>>(x, y, n);
```

先判断 kernel 是否只处理一个 256 元素 tile。如果 `n>256` 且没有 thread/grid-stride loop，这是覆盖错误。

### 普通修复基线

```cpp
long long logical = (n + BLOCK - 1) / BLOCK;
kernel<<<dim3((unsigned)logical), dim3(BLOCK), 0, stream>>>(x, y, n);
```

kernel：

```cpp
long long i = (long long)blockIdx.x * blockDim.x + threadIdx.x;
if (i < n) { /* 原计算 */ }
```

### 合法单 Block

以下情况可能合法：

- n 明确不超过 block 并有边界。
- 一个 block 完成需要 block-wide barrier 的小归约。
- cooperative/persistent 算法明确设计为一个 block。

即便合法，也不自动扩 grid；先看 NCU 和算法依赖。

### 要点

- 固定配置是源码事实，不代表最优。
- 修改 grid 前证明输出覆盖和同步语义。
- 从 1 block 改多 block 的归约常需 atomic 或第二阶段，不能直接套 elementwise 模板。
