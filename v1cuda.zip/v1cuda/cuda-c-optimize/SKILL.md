---
name: cuda-c-optimize
description: 面向 Linux 与 NVIDIA RTX 3090（sm_86）的 CUDA C/C++ Kernel 性能优化工作流。用于优化完整的 .cu 算子实现，串行执行线程块映射、归约、Grid、索引和配置搜索，再依据 Nsight Compute 数据做受控迭代；只保留正确、安全且在真实 RTX 3090 上无性能回退的候选。
---

# CUDA C/C++ Kernel Optimize

## 概述

本 Skill 优化一个完整、可独立编译运行的 CUDA C/C++ 算子文件。公共流程保持“输入检查 → 开箱策略 → 性能分析驱动迭代 → 汇总输出”的结构；设备限制、编译环境、数学函数和 NCU 采集统一读取 `.claude/skills/share/cuda-c/`，不得在本 Skill 中复制或臆测硬件事实。

目标平台固定为 Linux、NVIDIA GeForce RTX 3090 与 Compute Capability 8.6。没有真实 RTX 3090 执行证据时，只允许静态分析和记录后续建议；不生成或提升无法验证的性能候选，不得填写伪造耗时、带宽、occupancy 或加速比。

## 用法

```text
/cuda-c-optimize <cuda_code> [output_dir]
```

| 参数 | 说明 |
| --- | --- |
| `cuda_code` | 完整 `.cu` 文件路径，或可落盘为 `.cu` 的代码文本 |
| `output_dir` | 可选；默认当前目录下的 `output/` |

输入必须同时包含：

1. 至少一个 `__global__` kernel。
2. host wrapper 或 launch 入口，包含 `<<<grid, block, shared_bytes, stream>>>` 或 `cudaLaunchKernel`。
3. 可自动判定失败的 correctness 测试。
4. CUDA Event 或等价、可重复的 kernel benchmark。
5. CUDA API 和 launch 错误检查；正确性失败必须非零退出。

任一部分缺失时停止优化并报告缺失项，不临时虚构 reference、shape 或容差。

## 全局执行契约

### 环境与编译

从当前策略工作目录逐级向上读取最近的：

```text
{output_dir}/EnvConfig/config.md
```

接受其中明确记录的 `execution_backend=local`、`execution_backend=worker` 或 `execution_backend=unavailable`。同时读取输入旁最近的 `KernelGen/cuda_report.md`：

- `local`/`worker` 且上游 `passed=true, blocked=false, target_verified=true` 时进入动态优化；编译、运行、正确性和性能测量必须沿用该后端，不在策略间切换。
- `unavailable` 或上游 `blocked=true` 时进入 `static_only`：不编译、不运行、不调用 NCU、不执行策略 subagent；将输入逐字节复制为最终输出，仅记录静态限制与后续建议。
- 上游 `passed=false, blocked=false` 表示已确认的代码失败；停止优化，不以优化修复正确性。

默认编译基线：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  -Xptxas=-v input.cu -o input
```

- 所有候选使用相同 nvcc 路径、host compiler、标准、优化级别、宏、架构、链接参数和输入。
- `-Xptxas=-v` 的 register、shared memory、constant memory、spill 信息必须保存。
- `--use_fast_math`、`-maxrregcount`、LTO、额外 `-Xptxas` 选项均属于候选变化，不能偷偷加入公共基线。
- 编译失败、环境失败或工具缺失不是 kernel 性能问题；不得据此修改算法并声称优化成功。

### Baseline

进入第一个策略前，复制原始输入为只读基线并采集：

- 源码哈希与完整编译命令。
- GPU name、UUID、CC、driver、Toolkit、nvcc、host compiler。
- 每组测试的 shape、dtype、stride、seed、stream、warmup、repeat。
- correctness：`accuracy_pass`、`atol`、`rtol`、`max_abs_error`、`max_rel_error`。
- safety：CUDA API/launch 错误；若已运行 Compute Sanitizer，记录实际工具和结果。
- performance：CUDA Event 的 median、p20、p80；可选端到端时间单列。
- resource：register/thread、static/dynamic shared memory、spill 和 launch 配置。
- bandwidth 只有在读写字节口径明确时计算，否则记录 `N/A`。

### 候选保留门禁

每个策略先保留 `input.cu`，生成独立 candidate，再按完全相同的方法编译和测试。候选只有同时满足下列条件才能写为 `cuda_optimized.cu`：

1. 编译成功且目标架构为 `sm_86`。
2. 所有 correctness 用例通过，且不放宽原始容差。
3. CUDA API、launch 和同步检查通过；已有 sanitizer 基线时不得新增错误。
4. 相同 flags、输入、stream、warmup、repeat 和统计方法下，RTX 3090 median 不回退。
5. 性能差异落在噪声内且代码更复杂时回退。
6. 变更作用与本策略一致；一轮只改变一个可归因因素。

任何门禁失败时，`cuda_optimized.cu` 必须回退为该轮 `input.cu`，报告记录真实原因和日志。禁止让失败候选进入下一策略。

## 工作流程

### 步骤 1：输入检查与基线

1. 将文件路径或代码文本规范化为单个 `.cu`。
2. 检查 kernel、launch、correctness、benchmark 和错误处理是否完整。
3. 读取 `.claude/skills/share/cuda-c/references/platform-rules.md`。
4. 按 EnvConfig 和上游 review 选择 `dynamic` 或 `static_only`。
5. `dynamic`：编译并运行基线，保存 baseline 源码和机器可读/人类可读结果，后续策略不得覆盖。
6. `static_only`：记录 `performance_status=not_measured`，跳过步骤 2 和 3；将原输入逐字节复制为 `cuda_oob_optimized.cu`、`cuda_advanced_optimized.cu` 和 `cuda_optimized.cu`，分别生成对应 `.md`。三份报告均写入 `decision=not_measured`、`blocked=true`、`target_verified=false`，性能/资源写 N/A，且明确未运行任何策略候选，然后进入最终一致性检查。

### 步骤 2：开箱优化

严格按序串行处理以下策略：

| 序号 | 目录/策略名 | CUDA C/C++ 目标 | 是否检查 |
| ---: | --- | --- | --- |
| 1 | `retiling` | thread/block tiling、coalesced/vector load、shared-memory tiling | 是 |
| 2 | `reduce-opt` | warp shuffle、shared-memory 分层归约、合法 atomic | 是 |
| 3 | `modify-grid` | `dim3`、grid-stride、occupancy 和受控 persistent launch | 是 |
| 4 | `index-computation-simplify` | 地址式简化、循环不变量外提、强度削减 | 是 |
| 5 | `gen-autotune-config` | 外部编译运行 block/tile/vector/unroll/shared 候选并冻结 | 是 |

每轮建立：

```text
{output_dir}/Optimizer/{序号}_{策略名}/
├── input.cu
├── kernel_info.json
├── candidate.cu
├── cuda_optimized.cu
├── cuda_optimized.md
├── compile.stdout.txt
├── compile.stderr.txt
└── result.json
```

每轮必须先将当前 best-so-far 写为该目录的 `input.cu`，再按 `.claude/skills/cuda-c-optimize/kernel-info/strategy.md` 从这份输入重新生成同目录 `kernel_info.json`。不得复用上一轮源码的结构信息；多 kernel 时沿用上游报告明确的目标 kernel，仍有歧义则本轮回退。

调用策略 subagent：

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
## 任务文档
读取 .claude/skills/cuda-c-optimize/utils/Optimizer.md，作为 CUDA C/C++ 优化器执行指定策略。

## 输入
策略名称：{strategy_name}
策略文档：.claude/skills/cuda-c-optimize/{strategy_name}/strategy.md
工作目录：{strategy_workdir}

严格遵守 baseline、correctness+safety、公平 benchmark、no-regression 回退与 best-so-far 契约。
首先对工作目录 input.cu 执行 kernel-info/strategy.md，生成当轮 kernel_info.json，再执行指定策略。
"""
)
```

每个 subagent 返回后检查 `cuda_optimized.cu`、`cuda_optimized.md` 和 `result.json`。缺少产物最多重试两次；仍失败则把 `input.cu` 原样复制为 `cuda_optimized.cu`，生成最小失败报告，保证链路不断。

所有 OOB 策略完成后：

- 汇总为 `{output_dir}/Optimizer/cuda_oob_optimized.md`。
- 把最后一个经过门禁的 best-so-far 写入 `cuda_oob_optimized.cu`。
- 若没有可证明收益，文件内容必须等于原始输入。

### 步骤 3：性能分析驱动优化

只有真实 RTX 3090 可用且 OOB 产物正确、安全时进入本阶段。创建：

```text
{output_dir}/Optimizer/Advanced_Optimization/iter_{i}/
```

每轮执行：

1. 把上一轮 best-so-far 复制为 `input.cu`，按 `kernel-info/strategy.md` 生成当轮 `kernel_info.json`。
2. 读取 `.claude/skills/cuda-c-optimize/perf-analyzer/strategy.md`，对目标 binary 中明确指定的 kernel 运行 NCU。
3. 依据实际瓶颈只选择一个策略：
   - `libdevice-opt`：读取 `.claude/skills/share/cuda-c/optimize/libdevice-opt.md`，评估 CUDA math/fast intrinsic。
   - `config-tuner`：调整 block、tile、vector width、unroll、shared staging。
   - `div-to-mul`：仅在语义允许时处理除法或 reciprocal。
4. 生成一个独立候选并执行统一门禁。
5. 保留通过且无回退的候选；否则输出仍为该轮 `input.cu`。
6. 报告中记录 NCU 证据、源码变化、正确性、安全性、资源和性能。

终止条件：

- 连续三轮没有超出噪声的收益。
- NCU 报告没有可执行建议。
- 所有建议都因 correctness、safety、资源或 no-regression 门禁被回退。
- 达到执行预算或用户给出的最大轮数。

最终从所有通过门禁的轮次中选择最低 median 的 best-so-far；median 相同或区间重叠时选择修改更小、资源更稳的版本。不得把“最后一轮”自动当作最佳版本。

### 步骤 4：最终输出

最终产物：

```text
{output_dir}/Optimizer/
├── cuda_oob_optimized.cu
├── cuda_oob_optimized.md
├── cuda_advanced_optimized.cu
├── cuda_advanced_optimized.md
├── cuda_optimized.cu
└── cuda_optimized.md
```

选择规则：

1. `static_only`：三份 `.cu` 均必须与原始输入逐字节相同，对应报告均为 not_measured，不进入性能候选选择。
2. 深度优化实际执行且存在通过门禁的 best-so-far：选择 `cuda_advanced_optimized.cu`。
3. 深度优化未执行或没有更优候选：选择 `cuda_oob_optimized.cu`。
4. 任何不确定情况：选择原始输入。
5. `cuda_optimized.cu` 必须是选中版本的逐字副本。
6. `cuda_optimized.md` 汇总基线、所有策略、最终决策和证据。

## 报告字段

```markdown
## CUDA C/C++ 优化结果

### 环境
- execution_backend:
- workflow_mode: dynamic | static_only
- blocked: true | false
- target_verified: true | false
- gpu_name / uuid / compute_capability:
- nvcc / host_compiler:
- compile_command:

### 正确性与安全性
- accuracy_pass:
- atol / rtol:
- max_abs_error / max_rel_error:
- cuda_error_check:
- sanitizer_status:

### 公平性
- same_flags:
- same_inputs:
- same_stream:
- warmup / repeat:
- timing_method:

### 性能
| 版本 | median_ms | p20_ms | p80_ms | bandwidth_gbps | 相对基线 |
| --- | ---: | ---: | ---: | ---: | ---: |
| baseline | | | | | 1.0x |
| selected | | | | | |

### 资源
| 版本 | registers/thread | static_smem | dynamic_smem | spills | block | grid |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| baseline | | | | | | |
| selected | | | | | | |

### 决策
- selected_strategy:
- decision: keep / revert / not_measured
- evidence:
- final_code:
```

未在真实 RTX 3090 上测量时，性能与资源字段写 `N/A（原因：未取得目标设备实测）`，不得从其他 GPU、CPU、静态估算或单次计时推导 3090 性能。

## 编排状态机

主流程维护一个只增不减的状态记录，避免报告和源码发生错配：

| 状态 | 进入条件 | 可进行的动作 | 下一状态 |
| --- | --- | --- | --- |
| `INPUT_READY` | `.cu` 已落盘且 dynamic 门禁通过 | 静态输入检查 | `BASELINE_BUILD` |
| `INPUT_READY` | EnvConfig 不可用或上游 blocked | 原样复制输入，性能/资源写 N/A | `STATIC_ONLY` |
| `STATIC_ONLY` | 无目标动态证据 | 写 not_measured 汇总，不执行策略 | `FINALIZE` |
| `BASELINE_BUILD` | EnvConfig 后端为 local/worker 且上游 passed | 编译、保存 ptxas | `BASELINE_TEST` 或 `STOPPED` |
| `BASELINE_TEST` | 编译成功 | correctness、安全、benchmark | `OOB_READY` 或 `STOPPED` |
| `OOB_READY` | baseline 正确 | 依序执行五个 OOB 策略 | `OOB_DONE` |
| `OOB_DONE` | 固定产物齐全 | 汇总 best-so-far | `ADVANCED_READY`/`FINALIZE` |
| `ADVANCED_READY` | 真实 3090 且可 profile | NCU→单策略→门禁循环 | `ADVANCED_DONE` |
| `ADVANCED_DONE` | 达终止条件 | 比较所有有效轮次 | `FINALIZE` |
| `FINALIZE` | dynamic 有已验证 baseline，或 static_only 有完整但未验证的原始源码 | 复制最终源码与报告；static_only 保持 blocked | `COMPLETE` |
| `STOPPED` | dynamic 后端中途失效，或 baseline 已确认编译/正确性失败 | 保留证据，不编造产物 | 终态 |

每次状态变化写入 `{output_dir}/Optimizer/workflow_state.json`：

```json
{
  "schema_version": 1,
  "state": "OOB_READY",
  "input_source": "/abs/path/input.cu",
  "baseline_hash": "sha256:...",
  "execution_backend": "worker",
  "target_verified": true,
  "last_completed_strategy": null,
  "best_source": "baseline",
  "best_hash": "sha256:...",
  "performance_measured": true,
  "stop_reason": null
}
```

路径、哈希和布尔值必须来自实际状态。状态文件是恢复依据，不替代各策略日志。

## 产物完整性规则

### Source Provenance

每份输出源码附带外部 manifest，而不是向 `.cu` 强插可能改变构建的宏：

```json
{
  "source": "cuda_optimized.cu",
  "sha256": "...",
  "parent_source": "05_gen-autotune-config/input.cu",
  "parent_sha256": "...",
  "strategy": "gen-autotune-config",
  "decision": "keep",
  "target_gpu_uuid": "...",
  "compile_command": "..."
}
```

若策略回退，输出源码哈希必须等于 input 哈希；若 keep，parent/候选/输出哈希链必须可追溯。

### 最小失败产物

策略基础设施失败时仍生成：

```markdown
## 策略：<name>
- status: failed
- decision: revert
- accuracy_pass: N/A
- safety_pass: N/A
- performance: N/A
- reason: <真实错误>
- output: cuda_optimized.cu（与 input.cu 相同）
```

不得把 `N/A` 写成 `false` 来暗示 kernel 本身错误，也不得把未运行写成 pass。

### 汇总一致性

最终汇总前验证：

1. 每个策略目录的 output 与 result.json 的 hash 一致。
2. 下一策略 input hash 等于上一策略 output hash。
3. 被标记 keep 的轮次具有完整 compile/correctness/safety/performance 证据。
4. not_measured 或 revert 轮次不能成为性能赢家。
5. final source hash 等于 selected source hash。
6. 报告中的数值来自同一个 result，不从不同轮拼接最好值。

## Baseline Harness 要求

本 Skill 不重写用户测试，但会拒绝无法公平优化的 harness。合格 harness 至少应做到：

```cpp
#define CUDA_CHECK(call) do {                                      \
  cudaError_t status_ = (call);                                    \
  if (status_ != cudaSuccess) {                                    \
    std::fprintf(stderr, "CUDA error %s:%d: %s\n",                \
                 __FILE__, __LINE__, cudaGetErrorString(status_)); \
    std::exit(1);                                                   \
  }                                                                \
} while (0)
```

launch 后：

```cpp
target<<<grid, block, shared_bytes, stream>>>(...);
CUDA_CHECK(cudaGetLastError());
```

正确性读取结果前通过 event/synchronize 建立完成边界。性能使用同 stream events：

```cpp
CUDA_CHECK(cudaEventRecord(start, stream));
for (int i = 0; i < repeats_per_sample; ++i)
  launch_target(..., stream);
CUDA_CHECK(cudaEventRecord(stop, stream));
CUDA_CHECK(cudaEventSynchronize(stop));
float elapsed_ms = 0.0f;
CUDA_CHECK(cudaEventElapsedTime(&elapsed_ms, start, stop));
float kernel_ms = elapsed_ms / repeats_per_sample;
```

若一个逻辑调用需要 reset 或多个 kernel，循环体必须包含完整逻辑调用。baseline 和 candidate 的 event 范围逐字等价。

## Correctness 结果规范

每个测试 case 输出机器可解析记录，例如：

```json
{
  "case": "shape_0",
  "shape": [1024, 2048],
  "dtype": "float32",
  "stride": [2048, 1],
  "atol": 0.0001,
  "rtol": 0.0001,
  "max_abs_error": 0.0,
  "max_rel_error": 0.0,
  "nan_mismatch": 0,
  "inf_mismatch": 0,
  "pass": true
}
```

示例数值是 schema，不得复用为结果。多输出分别统计，不用某个输出通过代表全部通过。整数/布尔输出用精确比较；argmax 同时比较 value（若接口返回）和 index/tie。

## 性能判定规范

### 预设阈值

在运行 candidate 前确定：

- absolute floor：用于极短 kernel 的计时分辨率。
- relative improvement threshold：例如用户指定的 2%。
- per-case no-regression guardrail。
- 多 case 聚合权重。

Skill 不硬编码“2% 永远显著”。如果没有用户阈值，利用 baseline 重复轮次估计噪声，并在报告中说明方法。测试后不得移动阈值。

### 样本处理

- 保留原始样本或至少保存数量、median、p20、p80。
- baseline/candidate 交错，避免顺序漂移。
- 不把首次 context 创建或 module load 计入 steady-state。
- 过短 kernel 可在 event 区间重复，但两侧次数一致。
- 发生 CUDA error 的样本无效并导致候选失败，而不是从分布删除。
- 温度、功耗或其他进程污染可使整轮无效；必须记录重测，不挑选有利样本。

### 多 Case 选择

候选必须先满足所有 must-not-regress case，再计算聚合目标。允许的目标：

```text
weighted arithmetic mean of latency
weighted geometric mean of speedup
maximum latency guardrail + average objective
```

目标在运行前写入配置。若某 candidate 只在一个 shape 很快、关键 shape 回退，则不能成为全局 best。需要 shape dispatch 时转入明确的离线配置策略。

## 安全性路由

| 代码变化 | 必需静态检查 | 可用时动态检查 |
| --- | --- | --- |
| global index/vector | 64-bit、alignment、tail | memcheck |
| shared tile | size、initialized range、barrier | memcheck/racecheck/synccheck |
| warp shuffle | mask、group、active lane | synccheck |
| atomic | dtype、alignment、reset、race语义 | racecheck + 重复一致性 |
| grid-stride/persistent | 完整覆盖、无重复冲突 | memcheck + coverage test |
| multi-kernel/workspace | size、stream、lifetime | memcheck/initcheck |
| math intrinsic | dtype、domain、特殊值 | adversarial correctness |

Compute Sanitizer 不可用不代表安全通过；此时依赖原有安全基线和强制边界测试，并显式记录 `sanitizer=not_run`。

## 深度优化轮次选择

NCU 报告可能给出多个信号。主流程按以下顺序选一个：

1. correctness/safety 风险：交 code-review，停止性能优化。
2. 明确资源超限/launch 问题：config 或 grid。
3. 明确非合并访问/交易浪费：retiling/index。
4. 明确 barrier/atomic/reduction 热点：reduce。
5. 明确数学或除法指令热点：math/div。
6. 证据不充分：停止，不生成“试试看”建议。

同一策略连续两次被回退且证据未变化时，不再重复选择它。新一轮只有在上一轮 keep 后重新 profile，或输入/配置/证据确实变化时进行。

## 最终报告审计清单

- 目标 GPU 名、UUID、CC 是否来自实际运行。
- 编译器和完整 flags 是否齐全。
- baseline 是否正确且安全。
- 所有 keep 是否为真实 RTX 3090 实测。
- 是否存在其他 GPU 数据；若有，是否明确仅诊断。
- 性能表是否使用同口径。
- 带宽是否有 bytes 公式。
- NCU 是否匹配正确 kernel。
- atomic/原地 replay 是否 reset。
- final 是否 best-so-far，而非最后一轮。
- 所有回退和失败是否保留。
- 没有数据时是否写 N/A 而不是空白或估算。
