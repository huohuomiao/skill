# CUDA 地址与索引计算简化

## 职责

减少 kernel 热路径中的重复地址计算、整数除法/取模和循环不变量，同时保持完整覆盖、64-bit 地址安全、layout、alias 与边界语义。本策略不改变 block/grid、归约树、数学近似或编译 flags。

## Step 1：建立地址表达式

对每个 global/shared 访问，规范化：

```text
base + axis0*stride0 + axis1*stride1 + ... + constant
```

记录每个变量来自：

- `blockIdx/threadIdx`
- kernel scalar 参数
- 循环 induction variable
- 编译期模板常量
- runtime shape/stride
- 指针 offset

先检查 nvcc 是否已自动完成 common-subexpression elimination。只有 PTX/SASS/NCU 显示热路径仍存在重复整数指令或源码明显阻止优化时建立候选。

## Step 2：候选模式

### 2.1 循环不变量外提

```cpp
// before
for (int k = 0; k < K; ++k) {
  long long index = (long long)row * stride + k;
  acc += x[index];
}

// candidate
const long long row_base = (long long)row * stride;
for (int k = 0; k < K; ++k)
  acc += x[row_base + k];
```

编译器可能已完成该变换；没有生成代码差异时回退源码复杂化。

### 2.2 指针递增

```cpp
const float* p = x + (long long)row * stride;
for (int k = 0; k < K; ++k, ++p)
  acc += *p;
```

只有 alias、边界和步长语义明确时使用。不要让指针递增越过合法对象范围。

### 2.3 合并重复 div/mod

```cpp
long long q = linear / N;
int n = (int)(linear - q * N);
int m = (int)(q % M);
int b = (int)(q / M);
```

避免分别重复计算 `linear/N`。是否生成更少指令由编译结果确认。

### 2.4 编译期常量

固定 tile/stride 可通过模板参数或 `constexpr` 让 nvcc 强度削减。不得把 runtime shape 错误冻结成单一测试值。

### 2.5 32/64-bit 分层

grid、总元素数和全局地址在乘法前使用 `int64_t/long long`。局部 thread/lane、已证明范围内的 shared 下标可以用 32-bit。不能为减少指令把可能超过 2^31 的地址压成 int。

## Step 3：拒绝条件

- 变换依赖未证明的 shape、stride、整除或对齐。
- signed overflow、除零、负除法舍入或取模语义会变化。
- host 和 device 对 index 的类型不一致。
- in-place/alias 导致 load/store 顺序有语义。
- 简化改变 global 访问顺序并引入 race。
- 编译器已产生相同 PTX，而源码更难维护。
- 变换同时改变 block/grid 或数学计算。

## Step 4：验证

1. 保留原 `input.cu`。
2. 只修改地址/索引表达式生成 `candidate.cu`。
3. 使用相同 flags 编译；对比 ptxas 和相关 PTX/SASS 整数指令。
4. 运行所有 shape，特别是非整 tile、大尺寸、非连续 stride、边界 0/1。
5. 运行 CUDA error check；索引高风险时优先 memcheck。
6. 在 RTX 3090 相同 benchmark 下比较 median/p20/p80。
7. correctness、安全或 no-regression 任一失败即回退。

## 输出补充

报告记录：

- expression_before / expression_after
- assumptions and proofs
- integer widths
- generated-code evidence
- instruction-count evidence（若有）
- correctness/safety
- performance distribution
- keep/revert reason
