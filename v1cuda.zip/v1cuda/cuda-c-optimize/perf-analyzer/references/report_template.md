# CUDA C/C++ Kernel 性能分析报告

## 1. 环境与目标

- GPU name / UUID / CC：
- driver / Toolkit / nvcc / host compiler：
- execution_backend：
- source / binary：
- kernel match：
- program arguments：
- compile command：

## 2. 正确性前置条件

- accuracy_pass：
- safety_pass：
- input shape / dtype / stride：
- stream / warmup / repeat：

## 3. NCU 产物

- report：
- raw CSV：
- JSON summary：
- replay mode：
- reset method：

## 4. Launch 与资源

| grid | block | registers/thread | static smem | dynamic smem | spills | waves/SM | theoretical/achieved occupancy |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |

## 5. 吞吐与访存

| SM throughput | DRAM throughput | read bytes | write bytes | L1/L2 | sectors/coalescing | 关键 stalls |
| ---: | ---: | ---: | ---: | --- | --- | --- |

## 6. 下一步建议

- strategy：`retiling | reduce-opt | modify-grid | index-computation-simplify | config-tuner | libdevice-opt | div-to-mul | none`
- evidence：
- single change：
- expected effect：
- correctness/safety risk：
- revert condition：

> NCU 指标只用于定位，不证明加速。最终决策必须由相同 flags、输入、stream、warmup、repeat 的 RTX 3090 CUDA Event benchmark 给出；缺少实测时填写 N/A。
