# CUDA C/C++ review report

## Source and environment

- Input: `[absolute .cu path]`
- Output: `[absolute _fix.cu path]`
- Execution backend: `local | worker | unresolved`
- Device: `[name, logical index, UUID, CC]`
- Compiler: `[nvcc and host compiler versions]`
- Validation flags: `[exact EnvConfig validation_flags]`
- Compile command: `[complete nvcc command]`
- Target: `sm_86`

## Original gates

| Gate | Command | Exit | Result | Evidence |
| --- | --- | ---: | --- | --- |
| Integrity scan | `[scan]` | N/A | PASS / FAIL | `[custom kernel, launch, reference, synchronization, progress, residues]` |
| Compile/link | `[nvcc ...]` | `[code]` | PASS / FAIL / BLOCKED / NOT_RUN | `[first error or PTXAS resources]` |
| Runtime/API | `[binary]` | `[code]` | PASS / FAIL / BLOCKED / SKIPPED_UNSAFE / NOT_RUN | `[CUDA error, timeout, or preflight reason]` |
| Correctness | `[binary cases]` | `[code]` | PASS / FAIL / BLOCKED / NOT_RUN | `[cases, tolerance, max error, or dependency]` |
| Memcheck | `[command]` | `[code]` | PASS / FAIL / BLOCKED / NOT_RUN | `[summary or dependency]` |
| Initcheck | `[command]` | `[code]` | PASS / FAIL / BLOCKED / NOT_RUN | `[summary or dependency]` |
| Racecheck | `[command]` | `[code]` | PASS / FAIL / BLOCKED / NOT_RUN | `[summary or dependency]` |
| Synccheck | `[command]` | `[code]` | PASS / FAIL / BLOCKED / NOT_RUN | `[summary or dependency]` |

When preflight proves a launch unsafe, record `original_run=skipped_unsafe`, use `SKIPPED_UNSAFE` for Runtime/API, and use `NOT_RUN` for dependent original gates. These are not passes; after repair, a separate full-gate result must cover every dynamic row.

## Static review

### Extracted contract

| Item | Value |
| --- | --- |
| Kernels and launches | `[names and source locations]` |
| Inputs/outputs | `[dtype, shape, stride, ownership]` |
| Grid/block/shared/stream | `[expressions]` |
| Reference and tolerance | `[independent reference, atol, rtol]` |

### Findings

| Severity | Location | Class | Evidence | Repair or required confirmation |
| --- | --- | --- | --- | --- |
| error / warning / note | `[file:line]` | `[class]` | `[why]` | `[minimal edit or dynamic gate]` |

### Static edits

- `[exact change, or: no definite static repair]`

## Dynamic repair iterations

### Iteration `[N]`

- Failing gate and normalized signature: `[value]`
- Root-cause hypothesis: `[value]`
- Minimal edit: `[value]`
- Targeted rerun: `[command and result]`
- Full-gate result: `[result]`
- Candidate retained or reverted: `[decision and reason]`

## Final result

- Last passing gates: `[list]`
- Last failing/blocked gate: `[value or none]`
- Accuracy: `[cases, atol, rtol, max error, or N/A with reason]`
- Sanitizers: `[four results]`
- PTXAS resources: `[register/shared/spill summary or N/A]`
- Remaining limitations: `[list]`

```text
passed: true|false
blocked: true|false
target_verified: true|false
final_code_path: [absolute path]
```
