# CUDA Kernel 信息提取

## 职责

从一个完整 `.cu` 文件中提取目标 `__global__` kernel、host launch、输入 shape/stride、线程映射、访存、同步、资源和归约信息，为 retiling、reduce、grid、索引与配置策略提供统一结构化输入。本策略只分析，不修改源码。

## 输入与输出

- 输入：当前策略工作目录的 `input.cu`。
- 输出：当前工作目录的 `kernel_info.json`。
- 多 kernel 文件：必须由调用方指定目标 kernel；未指定且无法唯一确定时返回错误，禁止默认选择第一个 kernel。

```json
{
  "schema_version": 1,
  "kernel_name": "reduce_rows",
  "kernel_signature": {
    "pointers": ["x", "out"],
    "scalars": ["rows", "cols"],
    "qualifiers": ["__global__"]
  },
  "launch": {
    "syntax": "triple_chevron",
    "grid_expr": ["rows", "1", "1"],
    "block_expr": ["256", "1", "1"],
    "dynamic_shared_bytes": "block.x * sizeof(float)",
    "stream": "stream"
  },
  "axes": [
    {
      "name": "row",
      "extent": "rows",
      "source": "blockIdx.x",
      "kind": "grid_parallel"
    },
    {
      "name": "col",
      "extent": "cols",
      "source": "threadIdx.x + k * blockDim.x",
      "kind": "thread_reduce"
    }
  ],
  "memory": {
    "loads": [],
    "stores": [],
    "coalesced_dimension": "col",
    "vector_width_bytes": 4,
    "alignment_proven": false
  },
  "control": {
    "grid_stride_loops": [],
    "thread_stride_loops": [],
    "barriers": [],
    "warp_primitives": [],
    "atomics": []
  },
  "resources": {
    "static_shared_bytes_expr": "0",
    "dynamic_shared_bytes_expr": "block.x * sizeof(float)",
    "registers_per_thread": null,
    "spill_bytes": null,
    "source": "static_only"
  },
  "reduction": {
    "present": true,
    "operator": "sum",
    "identity": "0",
    "axis": "col",
    "scope": "block",
    "algorithm": "shared_tree",
    "determinism_required": false
  }
}
```

未知字段使用 `null`，不得猜测。

## 分析流程

### Step 1：定位 kernel 和 launch

识别：

- `__global__ void name(...)`
- 模板化 kernel 和显式实例化
- `name<<<grid, block, shared_bytes, stream>>>(...)`
- `cudaLaunchKernel` / driver API launch
- wrapper 中构造的 `dim3`
- 函数指针或宏包装导致的间接 launch

建立 kernel 形参到 launch 实参的映射。参数数量、顺序、指针/标量和动态 shared bytes 不一致时记录错误。模板参数与宏展开无法静态确定时保留原表达式并标为待编译确认。

### Step 2：确定实际测试规格

从 correctness/benchmark 入口提取每组：

- shape、dtype、stride、alignment、contiguous。
- batch/row/column/reduction extent。
- 输入输出 alias、in-place 语义。
- stream、warmup、repeat。
- 用户给定的 `atol`、`rtol`。

不以示例常量替代用户实际输入。若 shape 由命令行传入，记录参数名和值来源。无法确定时用符号表达式，不生成任意数字。

### Step 3：恢复 Grid 和 Block

展开 `dim3` 和中间变量，分别记录 x/y/z：

```cpp
dim3 block(BX, BY, BZ);
dim3 grid(ceil_div(N, BX), M, batch);
kernel<<<grid, block, shared_bytes, stream>>>(...);
```

提取：

- 每 block 线程数表达式 `BX * BY * BZ`。
- 逻辑 tile 数与 grid 上限。
- 是否存在 `grid = min(logical_grid, sm_count * k)`。
- dynamic shared bytes 是否依赖 block/tile。
- launch 是否在循环中、是否对不同 shape 使用不同配置。

### Step 4：恢复线程到数据轴映射

追踪 CUDA builtins：

- `threadIdx.{x,y,z}`
- `blockIdx.{x,y,z}`
- `blockDim.{x,y,z}`
- `gridDim.{x,y,z}`
- `warpSize`、lane、warp id

把每个地址表达式规范化为：

```text
base pointer + Σ(axis_index * stride) + constant
```

例：

```cpp
long long row = blockIdx.y;
long long col = (long long)blockIdx.x * blockDim.x + threadIdx.x;
x[row * x_stride0 + col * x_stride1]
```

记录 `row`、`col` 的来源、extent、mask 和对应 stride。若 `x_stride1 == 1`，连续线程访问 col 才可判为连续候选；不能只凭变量名判断 coalescing。

### Step 5：分析循环

区分：

- grid-stride：`i += blockDim.x * gridDim.x`
- thread-stride：`i += blockDim.x`
- tile loop：每线程处理多个连续/跨距元素
- reduction loop：更新 accumulator，最终聚合
- host launch loop：多个 kernel 阶段
- unrolled loop：pragma 或模板常量展开

对每个循环记录上下界、步长、是否可能溢出、是否有条件 break、是否跨 barrier。循环消除只有在所有迭代被等价覆盖且资源安全时才是候选。

### Step 6：访存与对齐

对每个 global/shared/local 访问记录：

- base pointer、index、字节宽度。
- read/write、cache/reuse。
- warp 内地址增量。
- 边界 predicate。
- 指针对齐证据：allocation、offset、类型、runtime assert。
- vector type 或 `reinterpret_cast`。
- shared memory layout、padding 和可能的 bank stride。

除非证明地址满足 `alignof(T_vector)` 且尾部安全，否则 `float4/int4` 只标为候选，不能直接推荐。

### Step 7：同步、warp 和 atomic

记录：

- `__syncthreads`、`__syncwarp(mask)`。
- `__shfl_*_sync`、`__ballot_sync` 等 active mask。
- cooperative groups（如有）。
- atomic 操作、dtype、地址空间和返回值是否被使用。
- barrier 是否可能位于 thread-divergent 分支。

静态分析无法证明安全时标为高风险并交给 synccheck/racecheck，不进行自动改写。

### Step 8：归约语义

若存在 accumulator 或 atomic 聚合，提取：

- operator：sum/max/min/and/or/xor 或自定义。
- identity 和 NaN/tie 行为。
- 输入/累加/输出 dtype。
- scope：thread、warp、block、grid、multi-kernel。
- 当前算法：serial、warp shuffle、shared tree、atomic、multi-pass。
- 是否需要确定性次序。

浮点加法不满足严格结合律；改变归约树可能改变舍入。仅在用户容差允许且 correctness 全部通过时保留。

### Step 9：资源来源

静态阶段只记录表达式。实际 registers、shared bytes 和 spill 必须来自同一编译 flags 下的 ptxas/NCU：

```text
-Xptxas=-v
```

禁止由局部变量数量估算 register。报告来源字段：

- `static_only`
- `ptxas`
- `ncu`

### Step 10：校验输出

确认：

1. kernel 与 launch 一一对应。
2. grid/block 三个维度齐全。
3. 所有主要输入/输出指针有地址表达式。
4. 每个数据轴有 extent 与线程来源。
5. reduction、barrier、atomic 不遗漏。
6. 未知信息明确为 null。
7. JSON 可解析。

## 参考例子

- 多维 flatten：[flatten-axis-example.md](./references/flatten-axis-example.md)
- 行归约 max：[reducemax-axis-example.md](./references/reducemax-axis-example.md)
- softmax：[softmax-axis-example.md](./references/softmax-axis-example.md)
