# 三维数据归约的二维 Thread Mapping 示例

## 需求

输入 row-major `x[B,M,K]`，输出 `y[B,M]`：

```text
y[b,m] = sum_k x[b,m,k]
```

B/M 是 outer axes，K 是 reduce axis。

## 基线：一维 Block 对一行

```cpp
template<int BLOCK>
__global__ void reduce_bmk_1d(
    const float* x, float* y, int B, int M, int K) {
  long long row = blockIdx.x;
  long long rows = (long long)B * M;
  if (row >= rows) return;

  float acc = 0.0f;
  for (int k = threadIdx.x; k < K; k += BLOCK)
    acc += x[row * K + k];

  float total = block_sum<BLOCK>(acc);
  if (threadIdx.x == 0) y[row] = total;
}
```

launch：

```cpp
dim3 grid((unsigned)((long long)B * M));
dim3 block(BLOCK);
```

这是清晰基线，K 连续访问。

## 候选：二维 Block 处理多行

当 K 较小、B*M 较大时，可让 block.y 表示多个 row，block.x 在每行内归约：

```cpp
template<int BX, int BY>
__global__ void reduce_bmk_2d(
    const float* x, float* y, int B, int M, int K) {
  int lane_x = threadIdx.x;
  int row_in_block = threadIdx.y;
  long long row =
      (long long)blockIdx.x * BY + row_in_block;
  long long rows = (long long)B * M;

  float acc = 0.0f;
  if (row < rows) {
    for (int k = lane_x; k < K; k += BX)
      acc += x[row * K + k];
  }

  // 每个 threadIdx.y 是独立归约组。
  // shared 或 shuffle 的索引必须包含 row_in_block，
  // 不能让不同 row 的 partial 混合。
  float total = row_group_reduce<BX, BY>(acc, row_in_block);
  if (lane_x == 0 && row < rows) y[row] = total;
}
```

launch：

```cpp
static_assert(BX * BY <= 1024);
dim3 block(BX, BY);
dim3 grid((unsigned)(((long long)B * M + BY - 1) / BY));
```

## 关键推导

- `threadIdx.x` 对 K，保持同组连续读取。
- `threadIdx.y` 选择不同 outer row。
- 总线程数为 BX*BY。
- 每个 row 的 active mask 和 shared 区域独立。
- row 越界线程仍要以 block 一致方式处理 barrier；不能提前 return 后让其他线程进入 `__syncthreads`。
- K 小于 BX 时部分 lane 不参与数值，但仍参与必要同步。
- 输出每个 row 仅 lane_x=0 写一次。

## Shared 布局示例

若每组写 warp partial：

```text
partial[row_in_block][warp_in_row]
```

建议 padding 需由 bank 分析决定，不机械添加。dynamic/static shared bytes 随 BX/BY 计算并与 launch/occupancy API一致。

## 何时可能有益

- K 较小，一行一个大 block 浪费线程。
- B*M 足够大，多个 row/block 改善 block 利用。
- BX 可保持 K 访问合并。
- register/shared 增长受控。

## 何时回退

- K 很大，BX 太小导致循环过长。
- BX 非 warp 友好，active mask/共享归约复杂。
- BY 增加 shared/register，residency 下降。
- 二维 block 改写造成 bank conflict。
- 浮点次序超出容差。
- RTX 3090 median 无提升或落在噪声内。

## Layout Fusion 场景

若旧 pipeline 先把 `[B,K,M]` transpose 为 `[B,M,K]` 再归约，可尝试直接按原 stride 读取：

```cpp
long long index =
    ((long long)b * K + k) * M + m;
```

这消除中间 buffer/launch，但 K 方向地址 stride=M，可能不合并。必须比较完整 pipeline：

- transpose + contiguous reduce
- direct strided reduce

只计第二个 kernel 会错误归因。

## 验证集合

- B/M/K 包含 1、非 block 整倍数、大尺寸。
- 全负、极值、NaN/Inf（契约适用）。
- FP16/BF16 输入时按契约使用 FP32 accumulator。
- 非连续 stride（若接口支持）。
- CUDA error、memcheck/synccheck。
- 相同 flags、输入、stream、warmup、repeat 的 RTX 3090 benchmark。
