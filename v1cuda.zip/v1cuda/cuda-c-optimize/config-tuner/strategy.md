# Config-Tuner：CUDA 配置微调

## 职责

依据 correctness 基线与 NCU 证据，对一个已确定的 CUDA kernel 小范围调整 block、tile、items/thread、vector width、unroll 或 shared staging。每轮只选择一个参数族，外部编译运行候选，保留真实 RTX 3090 上正确、安全且无回退的版本。

## Step 1：提取信息

读取：

- 当前 `input.cu`
- [get-tensor-axis-info.md](./references/get-tensor-axis-info.md)
- `kernel_info.json`
- 最新 `perf_analysis.md`
- 共享 RTX 3090 平台规则
- baseline 的编译、correctness、安全和 benchmark 数据

没有 NCU 时只允许小范围 OOB 配置搜索，不得声称已定位瓶颈。

## Step 2：选择一个参数族

| NCU/源码证据 | 参数族 |
| --- | --- |
| block 太小、waves 不足 | block x/y/z |
| register 限制 residency | 较小 tile、items 或 unroll |
| shared 限制 residency | 较小 shared tile/stage |
| streaming 地址开销高 | items/thread 或 vector width |
| reuse 明显且 DRAM 高 | shared staging/tile |
| loop overhead 明显 | unroll |
| tail wave/小 grid | block 与 grid 组合 |

同轮禁止同时调整多个族。例如调整 BLOCK 时固定 ITEMS、VEC、UNROLL 和算法。

## Step 3：生成有限候选

候选从当前值邻域产生，不使用笛卡尔爆炸。示例：

```text
block.x: current/2, current, current*2
items:   current, 2*current
unroll:  current/2, current, 2*current
```

每个值先通过：

- threads/block 与 grid 上限。
- shared bytes。
- warp primitive active-mask 约束。
- vector alignment 和 tail。
- 逻辑覆盖。
- 归约/atomic 语义。

候选通过模板参数或构建宏实例化；不得把 runtime shape 冻结为测试常量。

## Step 4：外部编译运行

每个候选建立独立目录：

```text
candidate_<id>/
├── candidate.cu
├── binary
├── compile.stdout.txt
├── compile.stderr.txt
└── result.json
```

统一基线 flags：

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 \
  -Xptxas=-v candidate.cu -o candidate
```

配置值变化可以通过源码模板实例化或仅用于该配置的 `-D` 定义；报告列出完整命令。其余 flags 不变。

按顺序：

1. compile/resource。
2. correctness。
3. CUDA error/safety。
4. RTX 3090 CUDA Event benchmark。
5. 必要时复核 NCU。

失败候选不运行性能或进入下一轮。

## Step 5：选择与冻结

评分口径在搜索前确定：

- 单 shape：最低 median 且无回退。
- 多 shape：用户指定权重；同时满足每个 shape 的 guardrail。
- 无权重：优先不使任一关键 shape 回退，再比较聚合 median。
- 区间重叠：选择当前配置，避免无证据复杂化。

把获胜参数冻结为模板实例化或明确 launch 常量，删除搜索 harness 对交付路径的运行时依赖。保留测试/benchmark，输出完整 `cuda_optimized.cu`。

没有真实 RTX 3090、没有候选超过噪声或任一门禁失败时回退 `input.cu`。

## 报告

记录候选表：

| id | 参数 | compile | correctness | safety | regs | smem | spill | median/p20/p80 | decision |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | --- | --- |

并说明评分口径、selected id、冻结位置、no-regression 与回退原因。禁止只报告最快成功候选而隐藏失败或回退候选。
