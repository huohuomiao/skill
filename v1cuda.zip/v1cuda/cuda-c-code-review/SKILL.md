---
name: cuda-c-code-review
description: Review, compile, test, and minimally repair self-contained NVIDIA CUDA C/C++ kernel files for Linux and RTX 3090 (sm_86). Use when validating generated or user-supplied .cu code, diagnosing nvcc, CUDA Runtime, correctness, memory-safety, race, synchronization, or launch failures, and producing a checked xxx_fix.cu plus an evidence report.
---

# CUDA C/C++ code review

## Goal

Validate one self-contained `.cu` file on Linux with an NVIDIA GeForce RTX 3090. Require a custom `__global__` kernel, host launch code, an independent correctness reference, and an executable test harness. Run a lightweight deadlock preflight before the first launch, then compile and test; use full static review and bounded dynamic repair only when a gate fails, and preserve the requested operator semantics.

Read platform facts from:

- `.claude/skills/share/cuda-c/references/platform-rules.md`
- `.claude/skills/share/cuda-c/references/primitives.md`
- `.claude/skills/share/cuda-c/references/libdevice.md`

Read the execution backend selected by `.claude/skills/cuda-c-main/SKILL.md`. Do not infer an RTX 3090 result from another GPU.

## Invocation

```text
/cuda-c-code-review <input_code_path>
```

Accept only one existing `.cu` file path. Do not accept an inline snippet because compilation, linking, launch, reference comparison, and sanitizer evidence must cover the same artifact.

For input `xxx.cu`, write only:

| Output | Contract |
| --- | --- |
| `xxx_fix.cu` | Final candidate. Copy the input unchanged if every gate passes. It may be unverified when the report says `passed=false` or `blocked=true`. |
| `xxx_fix.md` | Commands, environment, compile/run/sanitizer evidence, static findings, repair iterations, and final status. |

Use a temporary build directory outside the source tree. Remove temporary binaries, objects, reports, and sanitizer logs after copying the evidence needed into `xxx_fix.md`.

## Non-negotiable rules

- Keep a custom CUDA kernel. Do not replace it with a CPU loop, cuBLAS/cuDNN/Thrust operation, another framework, or a precomputed answer.
- Do not delete tests, reduce shapes, weaken guard/canary checks, change the reference to match the kernel, or relax `atol`/`rtol` after seeing a failure.
- Do not add `--use_fast_math`, `-use_fast_math`, `-G`, architecture-specific code above `sm_86`, or an unsupported intrinsic merely to make a failure disappear.
- Preserve the public host-wrapper signature, shapes, strides, dtype, aliasing, stream, and in-place contract unless the requested interface explicitly allows a change.
- Check every CUDA Runtime call. Check a launch with `cudaGetLastError()` and check completion with the appropriate stream/device synchronization before consuming results.
- Treat compilation, execution, correctness, and Compute Sanitizer as separate gates. Exit code 0 is insufficient unless the harness encodes accuracy failure as a nonzero exit and every required sanitizer gate passes.
- When the target environment or a required tool is unavailable, report `blocked=true`; do not edit the kernel as if an environment error were a code error.
- Preserve the last fully passing baseline. A repair that worsens the failure class or creates a new sanitizer error must be reverted.

## Step 1: Resolve the execution contract

Starting at the input file's parent, search upward for the nearest `EnvConfig/config.md`. Read at least:

- `execution_backend`: `local` or `worker`
- exact device name and compute capability
- CUDA Toolkit and `nvcc` version
- host compiler
- validation and performance compile flags
- device selector and Worker task information, if applicable

If the file is absent or ambiguous, run the EnvConfig workflow first. An environment is eligible for a final pass only when the shared probes confirm an exact RTX 3090 and CC 8.6.

Local commands run directly. Worker commands must use the current `JOB_ID` and run synchronously:

```bash
python3 .claude/skills/cuda-c-main/subagents/scripts/submit_task_to_worker.py \
  --task-type accuracy \
  --workdir <absolute-repository-root> \
  --timeout-sec 1800 \
  --command "<compile-or-test-command>"
```

Worker exit code `2` means infrastructure failure. For a local command, classify by stderr and tool output rather than assigning a special meaning to numeric code `2`.

## Step 2: Read-only integrity scan

Before accepting a successful executable, confirm the source contains:

1. At least one `__global__` kernel.
2. A matching `<<<grid, block, shared_bytes, stream>>>` launch or `cudaLaunchKernel` call.
3. A correctness reference independent of the custom kernel.
4. A test that returns nonzero on mismatch and checks CUDA API/launch failures.
5. No executable Triton, PyTorch, MLU, Cambricon, NRAM, CNRT, CNDrv, or BangUtils path.
6. No library substitution that bypasses the requested custom kernel.
7. No barrier, collective, or cooperative-group synchronization that only a subset of the participating threads can reach.
8. Every grid-stride or polling loop makes provable forward progress and has no definite infinite path.

This is a lightweight preflight, not the full static review. If items 7 or 8 have a definite violation, do not launch the original binary: record `original_run=skipped_unsafe`, go directly to Step 6, then execute the repaired artifact through every dynamic gate. If any other condition fails, enter static review even if the binary exits 0.

## Step 3: Compile and execute the original

Use the EnvConfig compiler and its exact `validation_flags`. The canonical value is:

```bash
nvcc -std=c++17 -O3 -DNDEBUG -lineinfo -arch=sm_86 -Xptxas=-v <input>.cu -o <temporary-binary>
```

Do not use `-G` in the normal gate. Capture the complete command, exit code, stdout, stderr, and PTXAS resource summary. Then run the binary on the selected device with a hard 120-second executor timeout and capture its exit code and reported accuracy values. On Linux, a direct local invocation may use `timeout --signal=TERM --kill-after=5s 120s <binary>`; exit 124 is a timeout failure. The Worker must enforce an equal or stricter inner command timeout in addition to its outer task lease timeout.

Classify outcomes independently:

| Gate | Pass condition |
| --- | --- |
| Compile/link | `nvcc` returns 0 and produces the expected binary for `sm_86`. |
| Runtime/API | Binary returns 0; all CUDA calls, launch check, and synchronization report success. |
| Correctness | Every declared case passes the frozen reference and tolerance. |
| Target | Runtime probe reports exact RTX 3090 / CC 8.6. |

Do not infer correctness from the absence of a crash.

## Step 4: Run safety gates

After compile/runtime/correctness pass, run the same binary and cases under the tools in this order:

```bash
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 <binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool initcheck --error-exitcode 99 <binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool racecheck --racecheck-report all --racecheck-detect-level info --error-exitcode 99 <binary>
timeout --signal=TERM --kill-after=5s 600s compute-sanitizer --tool synccheck --error-exitcode 99 <binary>
```

- `memcheck` does not replace the other tools.
- `racecheck` covers shared-memory hazards, not every global-memory logical race.
- Run `racecheck` and `synccheck` especially for shared memory, barriers, warp collectives, cooperative groups, pipelines, or asynchronous copies; the default full review runs all four.
- Treat sanitizer errors, actionable warnings, timeouts, crashes, and unsupported required options as failures. A missing tool makes the final result blocked, not passed.
- Run sanitizers on the validation build, never use sanitizer timing as a performance number.

## Step 5: Fast path

If the integrity scan and all dynamic gates pass:

1. Copy the input byte-for-byte to `xxx_fix.cu`.
2. Write `xxx_fix.md` with `passed=true`, `blocked=false`, environment identity, exact commands, PTXAS resources, accuracy results, and four sanitizer results.
3. Stop. Do not refactor passing code.

## Step 6: Static repair

If a code gate fails, delegate the static pass using `StaticReviewer.md` and the original `.cu` file. Require it to create or update `xxx_fix.cu` and append its findings to `xxx_fix.md`.

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
Use .claude/skills/cuda-c-code-review/StaticReviewer.md.
Review {input_code_path} as one self-contained CUDA C++ artifact.
Write {fixed_code_path} and append {report_path}.
Only repair definite static defects; preserve the reference and tolerances.
""",
)
```

Do not run this subtask concurrently with another writer of the same files.

## Step 7: Dynamic repair

Delegate `xxx_fix.cu` to `DynamicFixer.md`. It recompiles and reruns the complete gate after each minimal edit, directly updating `xxx_fix.cu` and appending `xxx_fix.md`.

```python
agent = spawn_agent(
    agent_type="default",
    message=f"""
Use .claude/skills/cuda-c-code-review/DynamicFixer.md.
Repair {fixed_code_path} using the recorded EnvConfig backend.
Keep tests, reference, tolerances, compile architecture, and public interface fixed.
Stop on pass, a repeated identical failure, five iterations, or an environment block.
""",
)
```

The main reviewer must not claim success merely because `xxx_fix.cu` exists. Read the final status recorded by DynamicFixer.

## Report ownership

Append sections in this order:

1. Main reviewer: source identity, EnvConfig, original compile/run/sanitizer results.
2. StaticReviewer: static findings and exact edits.
3. DynamicFixer: each compile/run/sanitizer iteration and final result.

End with machine-readable fields:

```text
passed: true|false
blocked: true|false
target_verified: true|false
final_code_path: <absolute path>
```

Only `passed=true`, `blocked=false`, and `target_verified=true` means “validated on RTX 3090.”
