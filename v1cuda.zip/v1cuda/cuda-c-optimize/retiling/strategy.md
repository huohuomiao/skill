# Retiling：CUDA Thread/Block Tiling

## 职责

分析目标 CUDA kernel 的线程到数据映射，生成至多一个可归因的 tiling 候选。候选范围包括：

- block 维度与每线程工作量。
- 连续线程到 stride-1 轴的映射。
- 对齐得到证明后的 vector load/store。
- 有明确复用时的 shared-memory staging、padding 和双缓冲候选。

本策略不同时修改归约算法、persistent grid、数学近似或编译 flags。

## 前置输入

1. 当前工作目录 `input.cu`。
2. `kernel-info/strategy.md` 生成的 `kernel_info.json`。
3. `.claude/skills/share/cuda-c/references/platform-rules.md`。
4. 原 correctness、safety 和 benchmark 入口。

## 步骤 1：读取 Kernel Info

确认目标 kernel 唯一，提取：

- grid/block x/y/z。
- 每个数据轴的 extent、stride 和 block/thread 来源。
- global load/store 的 warp 内地址增量。
- 对齐和尾部边界证据。
- shared memory、barrier、warp primitive、atomic。
- ptxas register/shared/spill（如有）。
- 实际 shape 分布；不能只优化一个未声明的示例 shape。

若信息不足以证明改写等价，输出 `not_applicable` 并回退。

## 步骤 2：识别瓶颈候选

按证据优先级选择一个方向：

### A. Coalesced mapping

当同一 warp 的相邻线程访问非 stride-1 轴，而另一个等价映射可让其访问连续地址时，尝试交换 thread 轴或重排 block 形状。

准入条件：

- 输出所有元素仍被恰好一次覆盖。
- 输入广播和 stride 语义保持。
- 无写冲突。
- grid/block 各维合法。
- 变换不使 barrier 进入分歧分支。

### B. 每线程多元素

让每线程处理 `ITEMS_PER_THREAD` 个元素，以减少地址/launch 开销或增加 ILP。

准入条件：

- 生成完整边界 predicate。
- 地址使用足够位宽。
- register 和指令增长可由 ptxas 观测。
- 小 shape 不因并行度不足显著回退。

### C. Vector load/store

仅当下列事实均可证明时尝试 `float2`、`float4` 或等宽向量类型：

1. 基指针满足向量对齐。
2. 元素 offset 保持对齐。
3. stride-1 且向量不会跨非法行边界。
4. 尾部有标量或带边界的安全路径。
5. 输入输出 alias 不导致未定义行为。
6. 读写 dtype 与 vector reinterpret 等位宽。

禁止仅因 allocation 通常对齐就假设任意切片也对齐。

### D. Shared-memory tiling

仅在数据有跨线程复用、转置、邻域或矩阵 tile 时考虑：

- 设计 cooperative global load。
- 对 shared tile 增加必要 padding，降低 bank conflict。
- 所有参与线程以一致次数到达 barrier。
- dynamic shared bytes 与 launch 参数一致。
- 边界 tile 的无效元素不会污染计算。
- ptxas/NCU 资源和 residency 可接受。

没有复用的纯 streaming elementwise 不应为了“使用 shared memory”增加 staging。

## 步骤 3：构造单一候选

选择上述一个方向，不在同一轮混入其他优化。保留 host API、kernel 语义、测试和 benchmark。

普通一维候选：

```cpp
template<int BLOCK, int ITEMS>
__global__ void vector_op(const float* x, float* y, long long n) {
  long long first =
      ((long long)blockIdx.x * BLOCK + threadIdx.x) * ITEMS;
#pragma unroll
  for (int item = 0; item < ITEMS; ++item) {
    long long i = first + (long long)item * BLOCK;
    if (i < n) y[i] = /* same expression */ x[i];
  }
}
```

此布局让每个 item 的相邻线程访问连续元素。是否优于每线程连续 `ITEMS` 个元素取决于访存和指令，需实测。

二维 shared tile 候选：

```cpp
template<int TILE_X, int TILE_Y>
__global__ void transpose_tile(const float* x, float* y, int rows, int cols) {
  __shared__ float tile[TILE_Y][TILE_X + 1];

  int x_col = blockIdx.x * TILE_X + threadIdx.x;
  int x_row = blockIdx.y * TILE_Y + threadIdx.y;
  if (x_row < rows && x_col < cols)
    tile[threadIdx.y][threadIdx.x] = x[(long long)x_row * cols + x_col];

  __syncthreads();

  int y_col = blockIdx.y * TILE_Y + threadIdx.x;
  int y_row = blockIdx.x * TILE_X + threadIdx.y;
  if (y_row < cols && y_col < rows)
    y[(long long)y_row * rows + y_col] = tile[threadIdx.x][threadIdx.y];
}
```

只有当 block 形状使 shared 下标和线程范围合法时使用该模板；非方形 tile 需重新推导，不机械复制。

## 步骤 4：验证

遵守 `utils/Optimizer.md`：

1. 相同 flags 编译并保存 ptxas。
2. 全部 correctness 和边界 shape 通过。
3. CUDA error check 通过。
4. 改动涉及 shared/barrier/vector 时运行适用的 sanitizer（可用时）。
5. RTX 3090 上相同输入/stream/warmup/repeat 的 median 不回退。
6. 对齐分快路径需同时测试 aligned 与合法 fallback。
7. 检查 register、shared、spill、waves 与吞吐，解释而非替代 benchmark。

失败或未测量时输出输入源码。

## 报告补充字段

- mapping_before / mapping_after
- coalesced_axis_before / after
- block_before / after
- items_per_thread
- vector_width_bytes
- alignment_proof
- shared_layout / padding / bytes
- barrier_changes
- ptxas resources
- NCU memory evidence
- decision / revert reason

## 访存模式判定细则

### 连续访问

对 warp lane `l` 计算字节地址 `A(l)`。若所有有效相邻 lane 满足：

```text
A(l+1)-A(l) = sizeof(element)
```

且访问不跨非法对象/行边界，才标为 contiguous。尾 warp 的无效 lane 不参与结论；predicate 必须阻止实际越界 transaction。

### 广播

所有 lane 读取相同地址时是广播/缓存候选，不应为了“连续”把它复制为每 lane 不同地址。报告区分：

- block 内只读标量。
- 每 row/column 重用的小向量。
- 随 block 变化但 warp 内相同。

是否放 constant memory、shared 或依赖 cache 是独立候选；没有 NCU 证据时保持简单 global load。

### Strided/Gather

若 lane delta 是 `stride*sizeof(T)`，记录 stride 和实际 bytes。可能的候选：

1. 交换 thread 轴。
2. 先合并读取到 shared 后转置。
3. 改变输出 tile，使主流量一侧连续。
4. 保持原样，因为另一侧/写回更重要。

不能仅靠源码判断哪个候选优；用 NCU sector、cache 和 DRAM 指标路由，再用 benchmark决策。

### AoS / SoA

结构体数组的单字段访问可能使 warp 地址 stride 为 `sizeof(struct)`。转换为 SoA 会改变对外数据布局，通常超出本策略权限。允许的最小候选仅限：

- 使用合法 vector load 一次读取完整 struct，确有多个字段被使用。
- 在 kernel 内 unpack，不改变 host layout。
- 对齐、padding 和 C++ object representation 得到证明。

若只用一个字段，vector 读取可能增加 bytes，必须报告实际流量。

## Vector Load/Store 实施

### Host 分流

```cpp
bool aligned16(const void* p) {
  return (reinterpret_cast<uintptr_t>(p) & 15u) == 0;
}

void launch(..., long long n, cudaStream_t stream) {
  if (aligned16(x) && aligned16(y) && n >= 4) {
    long long vectors = n / 4;
    launch_vec4(x, y, vectors, stream);
    long long tail = vectors * 4;
    if (tail < n) launch_scalar_tail(x, y, tail, n, stream);
  } else {
    launch_scalar(x, y, n, stream);
  }
}
```

host 分流本身有开销；小 N 时可直接 scalar。尾 kernel/第二 launch 必须计入逻辑调用性能。

### 单 Kernel Vector+Tail

也可每线程处理 vector，并由最后 block 标量处理尾部，但不能对未对齐尾指针做 vector dereference。一个安全方式是 vector 主区间与标量尾区间使用不同条件和类型；编译器仍可能生成 predicated vector instruction，需检查生成代码。

### Alias 与 restrict

只有接口保证指针不重叠时添加 `__restrict__`。原地算子 `x==y` 或部分 overlap 时错误的 restrict 可能让编译器重排导致错算。restrict 属于单独候选，并需 alias 测试；不能为 vector 候选顺带加入。

### Vector Dtype

`float4`、`int4` 是四个 32-bit 分量；不等于任意 16-byte payload。half/bfloat16 使用对应合法 vector 类型或明确 bit container，并保证数值解释、alignment 和端序。禁止把不同 C++ 类型通过违反 strict alias 的指针直接解引用；需要时使用目标环境支持且语义明确的 load方式。

## Shared-Memory Tiling 实施

### Cooperative Load

将 tile 元素线性化，由所有 block threads grid-stride 填充 shared：

```cpp
int tid = threadIdx.x + blockDim.x * threadIdx.y;
int threads = blockDim.x * blockDim.y;
for (int linear = tid; linear < TILE_ELEMENTS; linear += threads) {
  int local_row = linear / TILE_COLS;
  int local_col = linear - local_row * TILE_COLS;
  int global_row = block_row + local_row;
  int global_col = block_col + local_col;
  tile[local_row][local_col] =
      (global_row < rows && global_col < cols)
          ? x[(long long)global_row * stride + global_col]
          : identity;
}
__syncthreads();
```

所有 threads 进入循环和 barrier。identity 由后续算法决定；copy/transpose 可用任意不被越界输出读取的值，reduction 必须使用正确幺元。

### Dynamic Shared 分区

```cpp
extern __shared__ unsigned char storage[];
float* tile = reinterpret_cast<float*>(storage);
size_t tile_bytes = tile_elems * sizeof(float);
size_t next = (tile_bytes + alignof(float4) - 1) &
              ~(alignof(float4) - 1);
float4* staging = reinterpret_cast<float4*>(storage + next);
```

host 计算完全相同的 aligned bytes。候选改变 tile/VEC 后同时更新第三 launch 参数和 occupancy API输入。

### Padding 与 Bank

二维 transpose 常见 `tile[T][T+1]`，但 padding 会增加 shared bytes。对每个访问写出 shared word index 与 lane，判断多个 lane 是否落同 bank；不同 dtype/vector 可能改变。最终用 NCU shared 指标和耗时证明，不能只保留 padding 因为它“通常有效”。

### 双缓冲

双缓冲/软件流水会增加 shared、barrier 和 register live range。RTX 3090 CUDA C候选可使用两个普通 shared tile并在循环中交替，但不得引入更新架构专属异步机制。只有 loop 跨多个 tile、有可重叠加载/计算证据且每阶段同步正确时尝试。

```text
load tile 0 → barrier → compute 0
load tile 1 → barrier → compute 1
```

普通代码的 load/compute 是否真正重叠由编译和硬件执行决定；源码双缓冲不自动产生重叠。

## Thread Coarsening

### 连续多元素

```cpp
long long first =
    ((long long)blockIdx.x * blockDim.x + threadIdx.x) * ITEMS;
#pragma unroll
for (int j = 0; j < ITEMS; ++j) {
  long long i = first + j;
  if (i < n) ...;
}
```

每线程连续，但 warp 第一项地址间隔 ITEMS，可能形成多段 transaction。

### Warp-Striped 多元素

```cpp
long long base =
    (long long)blockIdx.x * blockDim.x * ITEMS + threadIdx.x;
#pragma unroll
for (int j = 0; j < ITEMS; ++j) {
  long long i = base + (long long)j * blockDim.x;
  if (i < n) ...;
}
```

每个 j 的 warp 地址连续。两者的 cache、ILP 和指令不同，作为两个独立候选，不同时加入 vector/shared。

### Register Array

若每线程把 ITEMS 个值全部先加载到数组再计算，live range 增加。可流式 load→compute→store 缩短 live range；但多输入融合可能需要保留。ptxas spill 是实际证据。

## 二维/三维 Tiling

### Block Shape

候选 `(BX,BY,BZ)` 满足：

```text
threads = BX*BY*BZ
```

warp 的线性顺序先 x 后 y/z。让 x 映射到主 stride-1 轴通常有利；若 BX<32，warp 跨 row，需要确认每 row 独立算法不会错误 shuffle/共享。

### Flatten vs 独立轴

flatten 可减少 launch 维和某些边界，但增加 div/mod；独立二维 grid 可自然映射 row/col。只在以下证据下 flatten：

- grid y/z 上限风险。
- 负载均衡改进。
- 地址计算可被常量强度削减。
- benchmark 无回退。

不在 retiling 同时做 persistent cap；那属于 modify-grid。

### Batch

batch 可以用 blockIdx.z、flatten 到 grid，或 kernel 内 grid-stride。选择要考虑 grid z上限、每 batch shape/stride、cache 和负载不均。大总 tile 乘法使用 64-bit。

## Tiling Correctness 矩阵

| 风险 | 必测 case |
| --- | --- |
| block 尾部 | extent=BLOCK-1/BLOCK/BLOCK+1 |
| ITEMS | extent=BLOCK*ITEMS±1 |
| vector | aligned、合法未对齐、长度 VEC±1 |
| 2D tile | rows/cols 分别 tile±1 |
| shared | 边界 tile、identity、全部 barrier 分支 |
| transpose | 非方形、非连续 stride、in/out shape |
| 64-bit | product 超过 2^31 的合法尺寸/静态推导 |
| alias | x==y 或接口允许的 overlap |

高内存 shape 无法实际分配时，不能用溢出测试声称动态通过；至少静态检查地址类型，并在可行边界执行。

## NCU 与决策

记录变换前后：

- global sectors/request、load/store efficiency。
- DRAM bytes/throughput。
- L1/L2 hit。
- shared transactions/conflicts。
- registers、shared、spill。
- waves、occupancy、SM throughput。
- CUDA Event median/p20/p80。

NCU 指标改善而 latency 无改善时回退；latency 改善且门禁通过可以 keep，即使某个局部指标变差，但报告必须解释 trade-off。

## 独立候选命名

```text
retiling_coalesced_axis
retiling_items_warp_striped
retiling_vector_aligned
retiling_shared_tile
retiling_shared_padding
```

一次 Optimizer 调用只选择一个名字。若需要组合，先 keep 第一项成为新的 best-so-far，再重新 profile 后在下一轮尝试第二项，保证收益可归因。
