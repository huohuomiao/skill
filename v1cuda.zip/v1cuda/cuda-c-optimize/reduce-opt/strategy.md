# CUDA C/C++ Reduction 综合优化

## 职责

识别 CUDA kernel 中的归约语义，并在不改变接口、输出 shape/dtype、用户容差和安全性的前提下，选择一个可归因候选：

- 线程局部累积。
- warp shuffle 归约。
- shared-memory 的 block 分层归约。
- 多 block partial + 第二阶段。
- 目标架构与 dtype 合法时的 atomic 聚合。
- 合并访存、向量读取、冗余 load 消除。
- 受控的 grid-stride/persistent 归约。

本策略不假设任何改写一定更快。浮点归约树变化会改变舍入顺序；只有原始 correctness 全部通过且 RTX 3090 公平 benchmark 无回退时保留。

## 0. 全局前置条件

读取：

1. 当前工作目录 `input.cu`。
2. `kernel-info/strategy.md` 生成的 `kernel_info.json`。
3. `.claude/skills/share/cuda-c/references/platform-rules.md`。
4. `.claude/skills/share/cuda-c/references/primitives.md`。
5. 原 correctness、安全检查和 benchmark。
6. baseline ptxas/NCU（若有）。

提取：

- operator、identity、输入/累加/输出 dtype。
- reduce axis、outer axes、shape/stride。
- NaN、Inf、tie、signed-zero 和空输入语义。
- 确定性要求。
- 当前 scope：thread、warp、block、grid、multi-kernel。
- block/grid、shared、barrier、warp primitive、atomic。
- 每线程元素数、global 访问连续性。
- 当前初始化和阶段间依赖。

语义无法确定时，不改代码并返回 `not_applicable`。

## 1. 归约算子与 Identity

| operator | 常见 identity | 必查语义 |
| --- | --- | --- |
| sum | 0 | 累加 dtype、浮点次序、overflow |
| product | 1 | overflow/underflow、0/NaN |
| max | -∞ 或类型最低值 | NaN 传播、signed zero |
| min | +∞ 或类型最高值 | NaN 传播、signed zero |
| and | 全 1 | signedness、位宽 |
| or/xor | 0 | signedness、位宽 |
| argmax/argmin | value+index pair | tie-breaking、NaN、index width |

不能把 max 的越界值填 0；全负输入会错误。argmax 需要对 `(value,index)` 成对归约，且保持用户规定的 first/last tie。

## 2. Warp 归约基础

### 2.1 Active mask

`__shfl_down_sync` 的 mask 必须表示参与该 warp 归约的活跃 lane。对完整 warp：

```cpp
unsigned mask = 0xffffffffu;
```

对部分 warp，先在一致控制流中构造：

```cpp
bool participate = lane < count;
unsigned mask = __ballot_sync(0xffffffffu, participate);
```

mask 中的 lane 必须实际执行对应 shuffle。禁止用固定 full mask 让已退出线程“参与”。

### 2.2 Sum 示例

```cpp
__inline__ __device__
float warp_reduce_sum(float value, unsigned mask, int active_lanes) {
  int lane = threadIdx.x & 31;
  for (int offset = 16; offset > 0; offset >>= 1) {
    float other = __shfl_down_sync(mask, value, offset);
    if (lane + offset < active_lanes) value += other;
  }
  return value;
}
```

只有 lane 0 持有最终值。若 active lanes 不是连续前缀，需要重新映射或更一般算法，不机械套用。

### 2.3 Max/Min 与 Pair

max/min 使用与 reference 一致的 compare。argmax pair 示例逻辑：

```cpp
struct MaxPair { float value; int index; };

__device__ MaxPair combine(MaxPair a, MaxPair b) {
  if (b.value > a.value) return b;
  if (b.value < a.value) return a;
  return b.index < a.index ? b : a;  // only if first-index contract
}
```

NaN 行为必须显式实现，不能由普通比较偶然决定。

## 3. Block 分层归约

推荐结构：线程局部 → warp → shared warp partial → 首 warp。

```cpp
template<int BLOCK>
__device__ float block_reduce_sum(float value) {
  static_assert(BLOCK > 0 && BLOCK <= 1024);
  __shared__ float partial[(BLOCK + 31) / 32];

  int lane = threadIdx.x & 31;
  int warp = threadIdx.x >> 5;
  int warp_begin = warp * 32;
  int active = min(32, BLOCK - warp_begin);
  unsigned mask = __ballot_sync(0xffffffffu, lane < active);

  value = warp_reduce_sum(value, mask, active);
  if (lane == 0) partial[warp] = value;
  __syncthreads();

  float out = 0.0f;
  if (warp == 0) {
    int warps = (BLOCK + 31) / 32;
    bool take = lane < warps;
    unsigned first_mask = __ballot_sync(0xffffffffu, take);
    out = take ? partial[lane] : 0.0f;
    out = warp_reduce_sum(out, first_mask, warps);
  }
  return out;
}
```

调用约束：

- 整个 block 以一致控制流调用，确保 barrier 安全。
- 只有 `threadIdx.x==0` 使用返回值。
- runtime block 版本需处理实际 `blockDim.x`；模板 BLOCK 必须与 launch 一致。
- 二维/三维 block 若线性化 thread id，明确 lane/warp 计算。
- shared 数组大小覆盖 warp 数。
- BLOCK 候选改变浮点树和资源，必须重新验证。

## 4. 策略选择

每轮只选以下一个策略。若多个均匹配，按 NCU 证据和最小风险排序；没有证据时先选择结构最接近当前实现者。

### 策略 1：串行或 Shared Tree → Warp+Block 分层

#### 识别

- thread 0 串行遍历整条 reduce axis。
- shared memory 保存每线程值，并用多轮 `__syncthreads` 做树归约。
- warp 内归约仍通过 shared+barrier。

#### 候选

- 每线程 grid/thread-stride 加载多个元素到 local accumulator。
- warp shuffle 合并。
- 仅 warp partial 进入 shared。
- 一次 block barrier。
- 首 warp 完成最终归约。

#### 准入

- operator 可结合或用户容差允许浮点次序变化。
- identity 正确。
- block 范围与 active mask 已证明。
- shared/barrier 控制流一致。
- 一个 block 足以负责一个独立输出。

#### 风险

- partial warp。
- 非 32 倍 block。
- argmax tie 和 NaN。
- register 增长。
- 原算法依赖固定次序。

### 策略 2：归约循环与每线程工作量

#### 识别

```cpp
for (long long k = threadIdx.x; k < reduce_size; k += blockDim.x)
  acc = combine(acc, x[base + k * stride]);
```

#### 候选轴

- BLOCK。
- ITEMS/unroll。
- 连续读取或 vector width。
- 外层输出到 grid 的映射。

规则：

- reduce stride=1 才是直接 coalesced。
- vector 必须证明对齐与尾部。
- unroll 只针对固定/小界或可控 remainder。
- BLOCK 增大可能减少每线程循环，也可能增加资源和尾部。
- 不把 runtime reduce_size 冻结为单一测试常量。

详见 [reduce_dim_loop_opt_example.md](./references/reduce_dim_loop_opt_example.md)。

### 策略 3：多 Block Partial + 第二阶段

适合一个输出的 reduce axis 很大、单 block 并行不足或 persistent 调度需要多个 partial。

Pass 1：

```cpp
partial_reduce<<<grid1, block, smem, stream>>>(
    x, partial, n, chunks);
```

Pass 2：

```cpp
final_reduce<<<grid2, block, smem, stream>>>(
    partial, out, chunks);
```

必须计入：

- partial buffer 分配/复用。
- 两个 kernel 时间。
- 阶段间同 stream 次序。
- 第二阶段读取数量。
- 额外 global traffic。
- host 错误检查。

只有端到端候选优于原实现时保留，不能只计 Pass 2。

### 策略 4：Block Partial + Atomic

适合输出很少、partial 数量受控且目标 dtype/operator 的 atomic 合法。

```cpp
template<int BLOCK>
__global__ void full_sum_atomic(
    const float* x, float* out, long long n) {
  float local = 0.0f;
  for (long long i =
           (long long)blockIdx.x * BLOCK + threadIdx.x;
       i < n; i += (long long)BLOCK * gridDim.x)
    local += x[i];

  float block_value = block_reduce_sum<BLOCK>(local);
  if (threadIdx.x == 0) atomicAdd(out, block_value);
}
```

准入：

1. atomic operation 和 dtype 在 `sm_86` 合法；以共享原语门禁和实际编译为准。
2. 输出在同一 stream 正确初始化为 identity。
3. 无确定性要求冲突。
4. 返回旧值不被算法依赖，或语义已处理。
5. contention、partial 数量和数值次序通过实测。
6. empty input 不产生错误结果。
7. 输入输出 alias 合法。

atomic 快不快取决于竞争和工作量，不作预设。

### 策略 5：全维度 Reduce 的 Grid-Stride Atomic

对单一标量输出，可用有限 block grid-stride 扫描全部输入，再每 block 一次 atomic。launch block 数可用 occupancy API给出候选起点，但不能硬编码 SM 数。

覆盖证明：

```text
i = blockIdx.x*blockDim.x + threadIdx.x
stride = gridDim.x*blockDim.x
i += stride until i >= n
```

每个元素恰好被一个线程遍历。普通大 grid 和 occupancy-capped grid 分别 benchmark。

### 策略 6：冗余 Load 消除

#### 检测

同一线程在没有可能写入/alias 的区间内，多次从等价 global 地址 load。

#### 证明

- 地址表达式等价。
- 中间无可能修改该地址的 store/atomic/external call。
- pointer alias 关系允许复用。
- volatile/streaming 语义不要求重读。
- 值的 live range 不造成更严重 register spill。

候选把第一次 load 保存到 local register。ptxas 若产生相同代码，回退源码复杂化。

### 策略 7：布局变换与归约融合

当 host 或前一 kernel 只做 transpose/permute 为归约准备数据时，可尝试在归约地址中直接使用原 layout，消除中间 buffer/launch。

必须比较端到端 pipeline，并证明：

- 所有 stride、shape、输出轴不变。
- 新访问即使非合并也总体有收益。
- 中间 tensor 无外部消费者。
- stream 和生命周期正确。
- reference 测试覆盖非连续输入。
- 不是通过改变输入布局契约规避工作。

详见 [reduce_3d_to_2d_opt_example.md](./references/reduce_3d_to_2d_opt_example.md)。

## 5. Atomic 合法性门禁

不要把“API 名存在”当作合法。逐项检查：

- operator 与 atomic 函数一致。
- dtype 和 address alignment。
- global/shared address space。
- 目标 `sm_86` 支持。
- 编译器 Toolkit 版本支持。
- vector atomic 的元素级原子性是否符合需求。
- 浮点 NaN/Inf 和顺序。
- 初始化与重复 benchmark reset。
- 原地输出和 alias。
- contention 与 forward progress。

常见候选包括整数/FP32 的 add/min/max/cas 类操作；更低精度或特殊类型必须查共享门禁并真实编译。没有明确支持证据时不用 atomic。

## 6. Correctness 门禁

每个候选至少覆盖：

- reduce_size：0（接口允许时）、1、warp-1、warp、warp+1、block-1、block、block+1。
- 非 32 倍和非 block 整倍数。
- 小/大 outer size。
- 非连续 stride。
- 全正、全负、全相等、随机、极值。
- NaN/Inf/signed-zero（契约适用时）。
- argmax/min tie。
- 多次重复运行检查 race/atomic 非确定波动。
- 原用户所有 shape/dtype。

不得临时放宽 tolerance。若归约树变化造成允许范围外误差，候选失败。

## 7. Safety 门禁

- 每次 CUDA API 返回值检查。
- kernel launch 后立即检查 launch error。
- 测试同步点捕获异步错误。
- shared 数组和 dynamic bytes 匹配。
- 所有 block 线程一致到达 `__syncthreads`。
- shuffle mask 只含参与 lane。
- atomic 输出正确初始化，每个 benchmark iteration reset。
- multi-pass buffer 大小正确。
- 大 shape 地址用 64-bit。
- memcheck/racecheck/synccheck 可用时按变更类型运行。

sanitizer 不可用时记录 `not_run`；不能写 pass。

## 8. 性能门禁

在真实 RTX 3090 上：

1. baseline/candidate 使用相同 nvcc flags。
2. 同一输入、stream、warmup、repeat、CUDA Event timing。
3. atomic/multi-pass 计入初始化和全部必需 kernel；若报告 kernel-only，也单列端到端。
4. 交错运行并报告 median/p20/p80。
5. NCU 关注 registers、shared、spill、waves、barrier、atomic、SM/DRAM throughput。
6. 只有 correctness/safety 通过且 median 无回退、收益超过噪声时 keep。
7. 资源改善但耗时无改善不构成 keep。
8. 没有目标设备实测时回退 input，性能字段 N/A。

## 9. 策略执行顺序

在单次 `reduce-opt` 中依次检查，但最多保留一个候选：

1. 明确 correctness bug（identity、mask、barrier、初始化）应交给 code-review，不作为性能优化计功。
2. 冗余 load（低风险，需生成代码证据）。
3. warp+block 分层（当前 shared/barrier 过多时）。
4. thread loop/block 配置（NCU/shape 证据）。
5. multi-pass 或 atomic（大 reduction，语义风险更高）。
6. layout/pipeline fusion（端到端证据充分时）。

若第一项匹配的是 correctness bug，停止优化并报告，不在优化阶段偷偷修复后声称提速。

## 10. 输出

生成：

- `candidate.cu`
- `cuda_optimized.cu`
- `cuda_optimized.md`
- `result.json`
- 编译/测试/NCU/sanitizer 日志

报告补充：

```markdown
### Reduction 语义
- operator / identity:
- input / accumulator / output dtype:
- reduce axis / outer axes:
- NaN / tie / deterministic contract:

### 算法
- before:
- candidate:
- block / grid:
- shuffle mask:
- shared bytes / barriers:
- atomic / partial passes:
- coverage proof:

### 门禁
- compile / ptxas:
- correctness:
- safety / sanitizer:
- same flags and inputs:
- RTX 3090 median/p20/p80:
- resources / NCU:
- decision / revert reason:
```

任何失败或不确定时，`cuda_optimized.cu` 必须逐字等于 `input.cu`。

## 11. 算法实现细则

### 11.1 Block Sum：任意合法 Block Size

若 block.x 不是 32 的倍数，不能让最后一个 warp 使用 full mask。下面模板展示连续活跃 lane 的处理；调用点仍必须保证整个 block 到达 barrier：

```cpp
template<int BLOCK>
__device__ float reduce_sum_block(float value) {
  static_assert(BLOCK >= 1 && BLOCK <= 1024, "invalid block size");
  constexpr int WARPS = (BLOCK + 31) / 32;
  __shared__ float warp_values[WARPS];

  int tid = threadIdx.x;
  int lane = tid & 31;
  int warp = tid >> 5;
  int active = min(32, BLOCK - warp * 32);
  bool valid_lane = lane < active;
  unsigned mask = __ballot_sync(0xffffffffu, valid_lane);

  for (int delta = 16; delta > 0; delta >>= 1) {
    float other = __shfl_down_sync(mask, value, delta);
    if (lane + delta < active) value += other;
  }
  if (lane == 0) warp_values[warp] = value;
  __syncthreads();

  float result = 0.0f;
  if (warp == 0) {
    bool take = lane < WARPS;
    unsigned first_mask = __ballot_sync(0xffffffffu, take);
    result = take ? warp_values[lane] : 0.0f;
    for (int delta = 16; delta > 0; delta >>= 1) {
      float other = __shfl_down_sync(first_mask, result, delta);
      if (lane + delta < WARPS) result += other;
    }
  }
  return result;
}
```

适用条件：

- launch 的 block.x 必须等于模板 BLOCK；若 block 是二维/三维，先将 thread id 线性化，并相应重写共享槽位。
- 该函数不能在 `if (tid < n)` 内仅由部分线程调用。无效线程应贡献 identity，随后全 block 共同归约。
- BLOCK=1 时 shuffle 循环不改变值；WARPS=1 时首 warp 只读取一个 partial。
- `__ballot_sync` 的调用必须由 warp 中未退出的线程执行；若之前发生 thread return，模板不再安全。

### 11.2 Block Max 与 NaN 策略

CUDA `fmaxf` 对单个 NaN 与普通比较的处理可能与用户 reference 不同。必须先选择契约：

```cpp
__device__ float combine_max_ignore_nan(float a, float b) {
  return fmaxf(a, b);
}

__device__ float combine_max_propagate_nan(float a, float b) {
  if (isnan(a)) return a;
  if (isnan(b)) return b;
  return a > b ? a : b;
}
```

两者不是可互换优化。若 reference 使用框架 max，应通过含 NaN、±0、±Inf、全相等值的明确测试确定语义。identity 对 FP32 max 通常为 `-CUDART_INF_F`，整数则用相应类型最低值。

### 11.3 Argmax/Argmin Pair Shuffle

pair 归约不能只 shuffle value 而保留本 lane index。每轮同时 shuffle value/index，并用一个 combine 规则：

```cpp
struct Pair {
  float value;
  int index;
};

__device__ Pair combine_argmax_first(Pair a, Pair b) {
  bool b_wins = (b.value > a.value) ||
                ((b.value == a.value) && (b.index < a.index));
  return b_wins ? b : a;
}

__device__ Pair warp_argmax(Pair p, unsigned mask, int active) {
  int lane = threadIdx.x & 31;
  for (int delta = 16; delta > 0; delta >>= 1) {
    Pair q;
    q.value = __shfl_down_sync(mask, p.value, delta);
    q.index = __shfl_down_sync(mask, p.index, delta);
    if (lane + delta < active) p = combine_argmax_first(p, q);
  }
  return p;
}
```

若 index 可能超过 32-bit，使用可被 shuffle 的 64-bit 表示或拆成两个 32-bit word，并验证重组。空/无效 lane 的 pair identity 应为最低 value 和不会错误赢得 tie 的 index。

### 11.4 FP16/BF16 输入与 FP32 累加

典型候选先转 FP32：

```cpp
float acc = 0.0f;
for (long long i = start; i < end; i += stride)
  acc += __half2float(x[i]);
```

输出转换在最后一次写回进行。是否可以使用 half2/bfloat162 vector operations 取决于地址对齐、元素数、Toolkit API 和目标语义。不要将累加改回低精度以降低 register，除非用户接口允许且完整精度测试通过。

### 11.5 Welford 归约

variance/layer-normalization 不应机械转换为 sum 和 sum-of-squares；后者可能明显损失稳定性。Welford state：

```cpp
struct WelfordData {
  float mean;
  float m2;
  int count;
};

__device__ WelfordData combine_welford(WelfordData a, WelfordData b) {
  if (a.count == 0) return b;
  if (b.count == 0) return a;
  float delta = b.mean - a.mean;
  int count = a.count + b.count;
  float ratio = static_cast<float>(b.count) / count;
  return {
      a.mean + delta * ratio,
      a.m2 + b.m2 + delta * delta *
          (static_cast<float>(a.count) * b.count / count),
      count};
}
```

shuffle 时三个字段必须同步移动。population/sample variance 的除数、epsilon 位置和空输入语义均从需求继承。Welford 合并次序也有浮点差异，仍受原容差门禁。

### 11.6 LogSumExp 与 Softmax

稳定 logsumexp 通常归约 max，再归约 `exp(x-max)`。尝试 fused one-pass state 时需要稳定 combine：

```text
m = max(m_a, m_b)
s = s_a * exp(m_a - m) + s_b * exp(m_b - m)
```

候选需测试大正/负值、全 `-inf`、NaN、单元素和非整 block。数学函数精确/fast 选择是独立策略，reduce-opt 不同时启用 fast intrinsic。

### 11.7 整数与布尔归约

- 整数 sum/product 的 overflow 是语言/接口语义的一部分；不要静默提升或缩窄输出。
- bitwise and identity 是该位宽全 1，不是数值 1。
- bool all/any 可用 and/or，但输出表示和输入值规范化需匹配接口。
- `__shfl_down_sync` 的类型支持依 Toolkit overload；不支持的窄类型可显式扩展到 32-bit，再按契约转换。

## 12. Multi-Pass Host Orchestration

### 12.1 Workspace 规划

两阶段归约的 wrapper 必须明确 workspace 生命周期：

```cpp
size_t partial_count = static_cast<size_t>(grid1.x);
size_t bytes = partial_count * sizeof(float);
float* partial = nullptr;
CUDA_CHECK(cudaMallocAsync(&partial, bytes, stream));

partial_reduce<BLOCK><<<grid1, block, 0, stream>>>(x, partial, n);
CUDA_CHECK(cudaGetLastError());
final_reduce<BLOCK><<<grid2, block, 0, stream>>>(partial, out, partial_count);
CUDA_CHECK(cudaGetLastError());

CUDA_CHECK(cudaFreeAsync(partial, stream));
```

如果目标环境/契约不用 stream-ordered allocator，则使用调用方 workspace 或预分配缓存。不要把每次 `cudaMalloc/cudaFree` 隐藏在 kernel-only benchmark；端到端报告必须包含实际生产路径成本。

### 12.2 第二阶段递归

partial_count 仍大于单 block 覆盖范围时，第二阶段可能继续产生 partial。实现应：

1. 计算每轮输出数。
2. 在两个 workspace 间 ping-pong。
3. 保持同 stream 顺序。
4. 每个 launch 检查错误。
5. 最后一轮只写最终输出。
6. 防止 `partial_count==0/1` 的错误 launch。

递归轮数、每轮 grid、workspace bytes 和总 kernel 时间都要报告。

### 12.3 Atomic 初始化与重复测量

atomic 输出每次逻辑调用前必须初始化：

```cpp
CUDA_CHECK(cudaMemsetAsync(out, 0, sizeof(float), stream));
reduce_atomic<<<grid, block, 0, stream>>>(x, out, n);
CUDA_CHECK(cudaGetLastError());
```

benchmark 每个 repeat 都必须 reset；否则结果累加且 correctness/性能均无效。max/min identity 非零 bit pattern 时，不能用 `cudaMemsetAsync` 随意初始化，应使用小 init kernel 或 host-to-device copy，并计入端到端口径。

## 13. Atomic 具体审查

### 13.1 FP32 Sum

`atomicAdd(float*)` 是常见 `sm_86` 候选，但顺序非确定。检查：

- 用户是否要求 deterministic。
- 同一输出的 block 数和 contention。
- 初始值。
- NaN/Inf。
- repeat reset。
- 输出是否与其他 stream 并发访问。

### 13.2 FP64 与低精度

API/硬件可能支持某些类型，但性能和语义不同。必须以当前 Toolkit 编译、共享平台表和真实 launch 为准。不要由 FP32 atomic 推断 half/bfloat16/vector overload 自动合法；特别检查 alignment 和“每个元素原子”是否满足整体对象的期望。

### 13.3 Atomic Max/Min on Float

若使用 CAS loop 实现浮点 max/min，必须处理：

- NaN 的 compare 规则。
- signed zero。
- bit reinterpret 与 numeric ordering。
- CAS 重试。
- ABA 不影响最终 combine 的证明。
- 目标地址对齐。

这类候选风险高，优先多阶段归约，除非 atomic 方案有明确需求和实测证据。

### 13.4 Contention 分层

禁止每个元素一次 atomic 作为默认方案。通常先做 thread→warp→block 归约，使每 block 最多一个 atomic。若输出分桶很多，地址分布和热点需由 NCU atomic/serialization 指标确认。

## 14. Barrier 与 Race 审查

### 14.1 早退风险

错误：

```cpp
if (global_row >= rows) return;
// some valid threads later call __syncthreads()
```

若同一 block 中部分 thread 的 row 无效而其他有效，早退会使 barrier 未由全 block 到达。安全做法是无效线程贡献 identity，但继续到达 block barrier；最终 store 用 predicate。

### 14.2 Shared 初始化

每个随后被读取的 shared 元素必须由明确线程写入，或预先初始化。尤其是 `warps=ceil(block/32)` 时，首 warp 只读取有效 warp slots；无效 lane 使用 identity，不读未初始化 shared。

### 14.3 Warp-Synchronous 假设

Volta+ 独立线程调度下，不应依赖未使用 `_sync` primitive 的隐式 warp lockstep。warp 内 shared producer/consumer 若缺同步，应使用合适 `__syncwarp(mask)` 或 shuffle，并确保 mask 正确。

### 14.4 Sanitizer 路由

| 改动 | 优先工具 |
| --- | --- |
| global/shared 越界 | memcheck |
| shared/global data race | racecheck |
| barrier/shuffle mask | synccheck |
| 未初始化 global memory | initcheck |

工具运行命令和版本保存到当前工作目录。工具报告 error 即候选失败；工具缺失为 `not_run`，不能变成 pass。

## 15. Shape-Specific Dispatch

一个配置不一定覆盖所有 reduction size。允许最小 dispatch：

```cpp
if (cols <= 128) {
  row_sum<128><<<...>>>(...);
} else if (cols <= 512) {
  row_sum<256><<<...>>>(...);
} else {
  row_sum<512><<<...>>>(...);
}
```

只有每个分支都有 correctness、安全和目标设备性能证据时保留。分支阈值在评测前制定，不能看完结果任意挑阈值。未覆盖 shape 必须走正确 fallback。

## 16. Benchmark 口径细节

### Kernel-only

CUDA Event 放在同一 stream：

```cpp
cudaEventRecord(start, stream);
launch_reduction(..., stream);
cudaEventRecord(stop, stream);
cudaEventSynchronize(stop);
cudaEventElapsedTime(&ms, start, stop);
```

若 `launch_reduction` 含多个 kernel 和必要初始化，kernel-only 应包含完整 device pipeline。不能只计最有利的单一 kernel。

### End-to-end

单列 host dispatch、workspace 管理或数据布局转换。baseline/candidate 使用同一边界。若 workspace 可被调用方复用，报告“steady-state with preallocated workspace”和首次分配成本。

### 有效带宽

归约 bytes 至少包含实际输入读取和输出/partial 读写。缓存、重复读取、atomic traffic 使简单公式只是算法有效带宽；需标注口径，不能冒充 DRAM 实际字节。NCU 的 DRAM bytes 单列。

### 噪声控制

- 固定输入 buffer，避免随机生成进入计时。
- warmup 后交错 baseline/candidate。
- 记录样本数和分位数。
- 发现温度/功耗/其他进程异常时废弃该轮。
- 很短 kernel 可在每个 event 区间循环多次，但 baseline/candidate 次数相同，且 atomic 输出每次正确 reset。

## 17. NCU 证据到策略映射

| 证据组合 | 优先候选 | 不应直接做 |
| --- | --- | --- |
| DRAM 高、访问连续、SM 低 | 增加每线程元素或 vector（有对齐时） | 添加无复用 shared |
| DRAM 高、sector 差 | 重映射连续轴、shared transpose | 只增 block |
| Barrier stall 高、shared tree | warp+block 分层 | 删除必要 barrier |
| Atomic serialization 高 | 增加 block-local 聚合或 multi-pass | 增加 grid/block atomic 数 |
| Register spill | 减 ITEMS/unroll/tile | 强制 maxrregcount 后直接 keep |
| 小 waves、rows 少 | 每 block 多行或多 block/row | 假设 occupancy 越高越快 |
| 长 reduce、单 block | multi-pass/atomic 候选 | 只把 block 调到硬上限 |
| Tensor/特殊 math 为主 | 交给数学策略 | 在 reduce-opt 同时 fast-math |

NCU 只能选择候选。最终 keep 仍由相同 CUDA Event benchmark 决定。

## 18. 失败与回退矩阵

| 失败 | 状态 | 输出 |
| --- | --- | --- |
| 语义不明确 | not_applicable | input 原样 |
| baseline correctness 失败 | failed_baseline | input 原样，交 code-review |
| candidate 编译失败 | failed_compile | input 原样 + nvcc stderr |
| ptxas 资源超限/spill 恶化 | revert_resource | input 原样 |
| correctness 超阈值 | revert_accuracy | input 原样 + 失败 case |
| sanitizer error | revert_safety | input 原样 + 工具报告 |
| 无目标 RTX 3090 | not_measured | input 原样，性能 N/A |
| median 回退 | revert_performance | input 原样 + 分布 |
| 收益在噪声内 | revert_noise | input 原样 |
| 全部门禁通过 | success/keep | candidate |

无论哪种情况都生成固定产物，保证下游汇总可读取。
